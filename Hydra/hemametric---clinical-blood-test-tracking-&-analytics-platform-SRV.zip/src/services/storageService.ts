import {
  PatientProfile,
  Laboratory,
  TestSession,
  AlertHistory,
} from '../types/clinical';
import {
  INITIAL_PATIENT_PROFILES,
  INITIAL_TEST_SESSIONS,
  LABORATORIES,
  INITIAL_ALERT_HISTORY,
} from '../data/seedData';

const STORAGE_KEYS = {
  PROFILES: 'hemametric_profiles_v1',
  SESSIONS: 'hemametric_sessions_v1',
  LABS: 'hemametric_labs_v1',
  ALERTS: 'hemametric_alerts_v1',
  SELECTED_PROFILE: 'hemametric_selected_profile_v1',
};

type Listener = () => void;
const listeners = new Set<Listener>();

function notify() {
  listeners.forEach((l) => l());
}

export function subscribeToStore(listener: Listener): () => void {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

export function getProfiles(): PatientProfile[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.PROFILES);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to parse profiles', e);
  }
  // Initialize with seed data
  localStorage.setItem(STORAGE_KEYS.PROFILES, JSON.stringify(INITIAL_PATIENT_PROFILES));
  return INITIAL_PATIENT_PROFILES;
}

export function saveProfiles(profiles: PatientProfile[]) {
  localStorage.setItem(STORAGE_KEYS.PROFILES, JSON.stringify(profiles));
  notify();
}

export function getSessions(): TestSession[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SESSIONS);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to parse sessions', e);
  }
  localStorage.setItem(STORAGE_KEYS.SESSIONS, JSON.stringify(INITIAL_TEST_SESSIONS));
  return INITIAL_TEST_SESSIONS;
}

export function saveSessions(sessions: TestSession[]) {
  localStorage.setItem(STORAGE_KEYS.SESSIONS, JSON.stringify(sessions));
  notify();
}

export function getLabs(): Laboratory[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.LABS);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to parse labs', e);
  }
  localStorage.setItem(STORAGE_KEYS.LABS, JSON.stringify(LABORATORIES));
  return LABORATORIES;
}

export function getAlerts(): AlertHistory[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.ALERTS);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to parse alerts', e);
  }
  localStorage.setItem(STORAGE_KEYS.ALERTS, JSON.stringify(INITIAL_ALERT_HISTORY));
  return INITIAL_ALERT_HISTORY;
}

export function saveAlerts(alerts: AlertHistory[]) {
  localStorage.setItem(STORAGE_KEYS.ALERTS, JSON.stringify(alerts));
  notify();
}

export function getSelectedProfileId(): string {
  const saved = localStorage.getItem(STORAGE_KEYS.SELECTED_PROFILE);
  if (saved) return saved;
  const profiles = getProfiles();
  const firstId = profiles.length > 0 ? profiles[0].profileId : 'pat-eleanor-01';
  localStorage.setItem(STORAGE_KEYS.SELECTED_PROFILE, firstId);
  return firstId;
}

export function setSelectedProfileId(id: string) {
  localStorage.setItem(STORAGE_KEYS.SELECTED_PROFILE, id);
  notify();
}

export function addSession(newSession: TestSession, newAlerts: AlertHistory[] = []) {
  const sessions = getSessions();
  sessions.push(newSession);
  saveSessions(sessions);

  if (newAlerts.length > 0) {
    const alerts = getAlerts();
    alerts.unshift(...newAlerts);
    saveAlerts(alerts);
  }
}

export function deleteSession(sessionId: string) {
  const sessions = getSessions().filter((s) => s.sessionId !== sessionId);
  saveSessions(sessions);
}

export function updateSession(updatedSession: TestSession): boolean {
  const sessions = getSessions();
  const idx = sessions.findIndex((s) => s.sessionId === updatedSession.sessionId);
  if (idx !== -1) {
    sessions[idx] = updatedSession;
    saveSessions(sessions);
    return true;
  }
  return false;
}

export function updateSessionNotes(
  sessionId: string,
  notes: string,
  notesHtml?: string,
  author?: string
): boolean {
  const sessions = getSessions();
  const idx = sessions.findIndex((s) => s.sessionId === sessionId);
  if (idx !== -1) {
    sessions[idx] = {
      ...sessions[idx],
      notes,
      notesHtml: notesHtml !== undefined ? notesHtml : notes,
      notesLastEditedAt: new Date().toISOString(),
      notesAuthor: author || sessions[idx].notesAuthor || 'Clinical Reviewer',
    };
    saveSessions(sessions);
    return true;
  }
  return false;
}

export function acknowledgeAlert(alertId: string, clinicianName: string = 'Dr. Clinical Reviewer') {
  const alerts = getAlerts();
  const idx = alerts.findIndex((a) => a.alertId === alertId);
  if (idx !== -1) {
    alerts[idx].acknowledged = true;
    alerts[idx].acknowledgedBy = clinicianName;
    alerts[idx].acknowledgedAt = new Date().toISOString();
    saveAlerts(alerts);
  }
}

export function saveOrUpdateProfile(profile: PatientProfile) {
  const profiles = getProfiles();
  const idx = profiles.findIndex((p) => p.profileId === profile.profileId);
  if (idx !== -1) {
    profiles[idx] = profile;
  } else {
    profiles.push(profile);
  }
  saveProfiles(profiles);
}

export function resetToSeedData() {
  localStorage.setItem(STORAGE_KEYS.PROFILES, JSON.stringify(INITIAL_PATIENT_PROFILES));
  localStorage.setItem(STORAGE_KEYS.SESSIONS, JSON.stringify(INITIAL_TEST_SESSIONS));
  localStorage.setItem(STORAGE_KEYS.LABS, JSON.stringify(LABORATORIES));
  localStorage.setItem(STORAGE_KEYS.ALERTS, JSON.stringify(INITIAL_ALERT_HISTORY));
  localStorage.setItem(STORAGE_KEYS.SELECTED_PROFILE, INITIAL_PATIENT_PROFILES[0].profileId);
  notify();
}
