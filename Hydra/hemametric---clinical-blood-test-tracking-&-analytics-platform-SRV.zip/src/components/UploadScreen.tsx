import React, { useState } from 'react';
import {
  UploadCloud,
  FileText,
  CheckCircle2,
  AlertCircle,
  FileSpreadsheet,
  ArrowRight,
  Database,
  Building2,
  Calendar,
  Sparkles,
  RefreshCw,
  Edit2,
  Trash2,
  Check,
} from 'lucide-react';
import {
  PatientProfile,
  Laboratory,
  BiomarkerResult,
  TestSession,
} from '../types/clinical';
import { MASTER_BIOMARKER_CATALOG } from '../data/seedData';
import {
  evaluateBiomarkerStatus,
  computeDerivedMetrics,
  generateAlertsForSession,
} from '../services/calculationEngine';

interface UploadScreenProps {
  profiles: PatientProfile[];
  labs: Laboratory[];
  selectedProfileId: string;
  onSessionCommitted: (newSession: TestSession) => void;
}

interface ParsedStagedBiomarker {
  biomarkerId: string;
  name: string;
  category: string;
  rawTextFound: string;
  value: number;
  unit: string;
  refLow: number;
  refHigh: number;
  status: 'Normal' | 'Low' | 'High' | 'Critical Low' | 'Critical High';
}

export const UploadScreen: React.FC<UploadScreenProps> = ({
  profiles,
  labs,
  selectedProfileId,
  onSessionCommitted,
}) => {
  const [profileId, setProfileId] = useState(selectedProfileId);
  const [labId, setLabId] = useState(labs[0]?.labId || '');
  const [collectionDate, setCollectionDate] = useState(new Date().toISOString().split('T')[0]);
  const [fastingHours, setFastingHours] = useState(12);
  const [doctorName, setDoctorName] = useState('Dr. Rebecca Martinez, MD');
  const [notes, setNotes] = useState('Routine surveillance checkup.');

  // File & ETL Pipeline state
  const [file, setFile] = useState<{ name: string; size: string; type: string } | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [etlStep, setEtlStep] = useState<number>(0);
  const [stagedData, setStagedData] = useState<ParsedStagedBiomarker[]>([]);
  const [committedSuccess, setCommittedSuccess] = useState(false);

  const selectedProfile = profiles.find((p) => p.profileId === profileId);

  // Pre-loaded sample reports for 1-click testing
  const sampleReports = [
    {
      title: 'Quest Diagnostics Comprehensive Metabolic & Lipid PDF',
      fileName: 'Quest_Diagnostics_CMP_Lipid_Panel_2026.pdf',
      labId: 'lab-quest-01',
      date: '2026-10-05',
      data: [
        { id: 'bm-glu', val: 104, unit: 'mg/dL' },
        { id: 'bm-hba1c', val: 5.7, unit: '%' },
        { id: 'bm-chol', val: 218, unit: 'mg/dL' },
        { id: 'bm-ldl', val: 135, unit: 'mg/dL' },
        { id: 'bm-hdl', val: 48, unit: 'mg/dL' },
        { id: 'bm-tg', val: 172, unit: 'mg/dL' },
        { id: 'bm-cr', val: 0.88, unit: 'mg/dL' },
        { id: 'bm-egfr', val: 92, unit: 'mL/min/1.73m²' },
        { id: 'bm-alt', val: 36, unit: 'U/L' },
        { id: 'bm-ast', val: 30, unit: 'U/L' },
        { id: 'bm-crp', val: 3.2, unit: 'mg/L' },
      ],
    },
    {
      title: 'Labcorp Complete Blood Count (CBC) & Ferritin CSV',
      fileName: 'Labcorp_CBC_Iron_Panel_Export.csv',
      labId: 'lab-corp-02',
      date: '2026-09-28',
      data: [
        { id: 'bm-hgb', val: 13.6, unit: 'g/dL' },
        { id: 'bm-hct', val: 40.2, unit: '%' },
        { id: 'bm-wbc', val: 6.8, unit: '×10³/µL' },
        { id: 'bm-plt', val: 285, unit: '×10³/µL' },
        { id: 'bm-neut', val: 4.1, unit: '×10³/µL' },
        { id: 'bm-lymph', val: 2.1, unit: '×10³/µL' },
        { id: 'bm-mono', val: 0.45, unit: '×10³/µL' },
        { id: 'bm-ferr', val: 42.0, unit: 'ng/mL' },
        { id: 'bm-iron', val: 88, unit: 'µg/dL' },
        { id: 'bm-tsat', val: 27.5, unit: '%' },
        { id: 'bm-vitd', val: 46.0, unit: 'ng/mL' },
      ],
    },
    {
      title: 'Mayo Clinic Hepatic & Inflammatory Workup Excel',
      fileName: 'Mayo_Clinic_Liver_Enzyme_Workup.xlsx',
      labId: 'lab-mayo-03',
      date: '2026-10-02',
      data: [
        { id: 'bm-alt', val: 44, unit: 'U/L' },
        { id: 'bm-ast', val: 38, unit: 'U/L' },
        { id: 'bm-alp', val: 82, unit: 'U/L' },
        { id: 'bm-bili', val: 0.8, unit: 'mg/dL' },
        { id: 'bm-alb', val: 4.4, unit: 'g/dL' },
        { id: 'bm-crp', val: 2.4, unit: 'mg/L' },
        { id: 'bm-plt', val: 260, unit: '×10³/µL' },
      ],
    },
  ];

  const handleSimulateEtl = (sample: typeof sampleReports[0]) => {
    setFile({ name: sample.fileName, size: '284 KB', type: sample.fileName.split('.').pop()?.toUpperCase() || 'FILE' });
    setLabId(sample.labId);
    setCollectionDate(sample.date);
    setIsProcessing(true);
    setEtlStep(1);
    setCommittedSuccess(false);

    // Simulate multi-stage ETL Pipeline
    setTimeout(() => {
      setEtlStep(2); // OCR / extraction
      setTimeout(() => {
        setEtlStep(3); // Master Catalog Mapping
        setTimeout(() => {
          setEtlStep(4); // Unit Standardization & Validation
          setTimeout(() => {
            setEtlStep(5); // Derived Calculations & Complete
            setIsProcessing(false);

            // Populate staged data
            const isFemale = selectedProfile?.gender === 'Female';
            const staged: ParsedStagedBiomarker[] = sample.data.map((item) => {
              const cat = MASTER_BIOMARKER_CATALOG.find((b) => b.biomarkerId === item.id);
              const refLow = isFemale ? cat?.refLowFemale || 0 : cat?.refLowMale || 0;
              const refHigh = isFemale ? cat?.refHighFemale || 100 : cat?.refHighMale || 100;
              const evalRes = evaluateBiomarkerStatus(item.val, refLow, refHigh, cat?.criticalLow, cat?.criticalHigh);

              return {
                biomarkerId: item.id,
                name: cat?.name || item.id,
                category: cat?.category || 'General',
                rawTextFound: `${cat?.name || item.id}: ${item.val} ${item.unit}`,
                value: item.val,
                unit: item.unit,
                refLow,
                refHigh,
                status: evalRes.status,
              };
            });

            setStagedData(staged);
          }, 400);
        }, 400);
      }, 400);
    }, 400);
  };

  const handleFileDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const dropped = e.dataTransfer.files[0];
      handleSimulateEtl({
        title: dropped.name,
        fileName: dropped.name,
        labId: labId || 'lab-quest-01',
        date: collectionDate,
        data: sampleReports[0].data,
      });
    }
  };

  const handleManualValueChange = (index: number, newVal: number) => {
    const updated = [...stagedData];
    const item = updated[index];
    const cat = MASTER_BIOMARKER_CATALOG.find((b) => b.biomarkerId === item.biomarkerId);
    const evalRes = evaluateBiomarkerStatus(newVal, item.refLow, item.refHigh, cat?.criticalLow, cat?.criticalHigh);

    updated[index] = {
      ...item,
      value: newVal,
      status: evalRes.status,
    };
    setStagedData(updated);
  };

  const handleDeleteStagedItem = (index: number) => {
    setStagedData(stagedData.filter((_, i) => i !== index));
  };

  const handleCommitToDatabase = () => {
    if (stagedData.length === 0 || !selectedProfile) return;

    const sessionId = `sess-${Date.now().toString(36)}`;
    const results: BiomarkerResult[] = stagedData.map((item, idx) => ({
      resultId: `res-${sessionId}-${idx}`,
      sessionId,
      biomarkerId: item.biomarkerId,
      resultValue: item.value,
      unitMeasured: item.unit,
      refLow: item.refLow,
      refHigh: item.refHigh,
      status: item.status,
      flag: item.status !== 'Normal' ? (item.status.includes('High') ? 'H' : 'L') : undefined,
    }));

    const derived = computeDerivedMetrics(sessionId, results, selectedProfile);
    const alerts = generateAlertsForSession(sessionId, selectedProfile.profileId, results);

    const newSession: TestSession = {
      sessionId,
      profileId: selectedProfile.profileId,
      labId,
      collectionDate,
      fastingHours,
      reportFile: file?.name || 'Uploaded_Clinical_Report.pdf',
      notes,
      orderingPhysician: doctorName,
      status: 'Verified',
      results,
      derivedMetrics: derived,
      createdDate: new Date().toISOString(),
    };

    onSessionCommitted(newSession);
    setCommittedSuccess(true);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-2xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs font-semibold text-blue-700">
              <UploadCloud className="w-4 h-4" />
              <span>Laboratory Ingestion & ETL Automation Service</span>
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-slate-900">
              Laboratory Document Ingestion
            </h1>
            <p className="text-xs text-slate-600 max-w-2xl leading-relaxed">
              Upload laboratory blood test reports in PDF, Excel, or CSV formats. The automated ETL pipeline performs OCR parsing, LOINC biomarker entity resolution, unit standardization, and derived metric calculations.
            </p>
          </div>
        </div>
      </div>

      {/* Target Patient & Session Metadata Form */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-4">
        <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
          Target Session Metadata & Clinician Context
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
          <div>
            <label className="block text-slate-600 font-medium mb-1">Target Patient Profile</label>
            <select
              value={profileId}
              onChange={(e) => setProfileId(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-md p-2 text-slate-900 focus:outline-none cursor-pointer"
            >
              {profiles.map((p) => (
                <option key={p.profileId} value={p.profileId}>
                  {p.firstName} {p.lastName} ({p.mrn})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-slate-600 font-medium mb-1">Laboratory Facility</label>
            <select
              value={labId}
              onChange={(e) => setLabId(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-md p-2 text-slate-900 focus:outline-none cursor-pointer"
            >
              {labs.map((l) => (
                <option key={l.labId} value={l.labId}>
                  {l.labName} ({l.accreditation.split('&')[0]})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-slate-600 font-medium mb-1">Collection Date</label>
            <input
              type="date"
              value={collectionDate}
              onChange={(e) => setCollectionDate(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-md p-2 text-slate-900 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-slate-600 font-medium mb-1">Fasting Hours</label>
            <input
              type="number"
              min="0"
              max="48"
              value={fastingHours}
              onChange={(e) => setFastingHours(Number(e.target.value))}
              className="w-full bg-slate-50 border border-slate-200 rounded-md p-2 text-slate-900 focus:outline-none font-mono"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs pt-1">
          <div>
            <label className="block text-slate-600 font-medium mb-1">Ordering Physician</label>
            <input
              type="text"
              value={doctorName}
              onChange={(e) => setDoctorName(e.target.value)}
              placeholder="e.g. Dr. Rebecca Martinez, MD"
              className="w-full bg-slate-50 border border-slate-200 rounded-md p-2 text-slate-900 focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-slate-600 font-medium mb-1">Clinical Indication / Notes</label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Annual metabolic health panel & iron monitoring"
              className="w-full bg-slate-50 border border-slate-200 rounded-md p-2 text-slate-900 focus:outline-none"
            />
          </div>
        </div>
      </div>

      {/* Upload Dropzone & Sample Reports */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left: Drag & Drop Zone */}
        <div className="lg:col-span-7 space-y-4">
          <div
            onDragOver={(e) => e.preventDefault()}
            onDrop={handleFileDrop}
            className="border-2 border-dashed border-slate-300 hover:border-blue-500 rounded-xl p-8 text-center bg-white transition-colors cursor-pointer group"
            onClick={() => handleSimulateEtl(sampleReports[0])}
          >
            <div className="w-12 h-12 rounded-full bg-blue-50 text-blue-700 flex items-center justify-center mx-auto mb-3 group-hover:scale-105 transition-transform">
              <UploadCloud className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-bold text-slate-900">
              Drag and drop clinical blood test report
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Supports standard laboratory formats: PDF, Excel (.xlsx, .xls), or CSV (HL7 / LOINC ready).
            </p>
            <div className="mt-4 inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-blue-700 bg-blue-50 rounded-md hover:bg-blue-100 transition-colors">
              <span>Select File or Click to Ingest Sample</span>
            </div>
          </div>

          {/* ETL Pipeline Tracker */}
          {(isProcessing || etlStep > 0) && (
            <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-2xs space-y-3">
              <div className="flex items-center justify-between text-xs pb-2 border-b border-slate-100">
                <span className="font-bold text-slate-900">Power Automate ETL Processing Pipeline</span>
                <span className="font-mono text-2xs text-slate-500">
                  {file?.name} ({file?.size})
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-5 gap-2 text-2xs">
                {[
                  { step: 1, label: '1. Ingestion', desc: 'MIME & Size' },
                  { step: 2, label: '2. OCR Extract', desc: 'Table Parsed' },
                  { step: 3, label: '3. Catalog Map', desc: 'LOINC Matched' },
                  { step: 4, label: '4. Validate', desc: 'Units & Range' },
                  { step: 5, label: '5. Derived Metrics', desc: 'Calculations Done' },
                ].map((s) => (
                  <div
                    key={s.step}
                    className={`p-2 rounded-md border text-center transition-colors ${
                      etlStep >= s.step
                        ? 'border-emerald-300 bg-emerald-50/70 text-emerald-900'
                        : isProcessing && etlStep === s.step - 1
                        ? 'border-blue-300 bg-blue-50/60 text-blue-900 animate-pulse'
                        : 'border-slate-200 bg-slate-50 text-slate-400'
                    }`}
                  >
                    <div className="font-bold">{s.label}</div>
                    <div className="text-3xs text-slate-500">{s.desc}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right: 1-Click Clinical Sample Templates */}
        <div className="lg:col-span-5 space-y-3">
          <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-2xs space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                1-Click Laboratory Test Templates
              </h3>
              <Sparkles className="w-3.5 h-3.5 text-blue-600" />
            </div>
            <p className="text-2xs text-slate-500 leading-snug">
              Instantly simulate real-world OCR parsing by loading formatted clinical reports from accredited facilities:
            </p>

            <div className="space-y-2">
              {sampleReports.map((sample, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSimulateEtl(sample)}
                  className="w-full p-2.5 rounded-lg border border-slate-200 hover:border-blue-400 hover:bg-blue-50/30 transition-all text-left flex items-start justify-between group cursor-pointer"
                >
                  <div className="space-y-0.5">
                    <div className="text-xs font-semibold text-slate-900 group-hover:text-blue-700">
                      {sample.title}
                    </div>
                    <div className="text-2xs text-slate-500 flex items-center gap-1 font-mono">
                      <FileText className="w-3 h-3 text-slate-400" />
                      <span>{sample.fileName}</span>
                      <span>·</span>
                      <span>{sample.data.length} analytes</span>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-blue-600 group-hover:translate-x-0.5 transition-all mt-1" />
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Staged Data Table & Final Verification */}
      {stagedData.length > 0 && (
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Staged Extraction Verification ({stagedData.length} Analytes)
              </h2>
              <p className="text-xs text-slate-500">
                Review and modify extracted laboratory findings before committing permanently to the patient record.
              </p>
            </div>

            <button
              onClick={handleCommitToDatabase}
              disabled={committedSuccess}
              className={`px-4 py-2 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors shadow-xs cursor-pointer ${
                committedSuccess
                  ? 'bg-emerald-600 text-white cursor-default'
                  : 'bg-blue-700 hover:bg-blue-800 text-white'
              }`}
            >
              {committedSuccess ? (
                <>
                  <Check className="w-4 h-4" />
                  <span>Committed to Patient Record</span>
                </>
              ) : (
                <>
                  <Database className="w-4 h-4" />
                  <span>Commit Session to Database</span>
                </>
              )}
            </button>
          </div>

          {/* Staged Table */}
          <div className="border border-slate-200 rounded-lg overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 border-b border-slate-200">
                <tr>
                  <th className="py-2.5 px-3 font-semibold">Biomarker</th>
                  <th className="py-2.5 px-3 font-semibold">Category</th>
                  <th className="py-2.5 px-3 font-semibold text-right">Extracted Value</th>
                  <th className="py-2.5 px-3 font-semibold text-right">Standard Range</th>
                  <th className="py-2.5 px-3 font-semibold text-center">Status</th>
                  <th className="py-2.5 px-3 font-semibold text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {stagedData.map((item, idx) => {
                  const isNormal = item.status === 'Normal';
                  const isCrit = item.status.includes('Critical');

                  return (
                    <tr key={item.biomarkerId} className="hover:bg-slate-50/60 transition-colors">
                      <td className="py-2.5 px-3 font-medium text-slate-900">
                        {item.name}
                      </td>
                      <td className="py-2.5 px-3 text-2xs text-slate-500">
                        {item.category}
                      </td>
                      <td className="py-2.5 px-3 text-right">
                        <div className="inline-flex items-center gap-1 font-mono tabular-nums">
                          <input
                            type="number"
                            step="0.01"
                            value={item.value}
                            onChange={(e) => handleManualValueChange(idx, Number(e.target.value))}
                            className="w-20 px-1.5 py-0.5 border border-slate-300 rounded text-right font-semibold text-slate-900 bg-white"
                          />
                          <span className="text-2xs text-slate-500 font-sans">{item.unit}</span>
                        </div>
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-2xs text-slate-500">
                        {item.refLow} – {item.refHigh} {item.unit}
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        <span
                          className={`text-2xs font-semibold ${
                            isCrit ? 'text-rose-700' : isNormal ? 'text-emerald-700' : 'text-amber-700'
                          }`}
                        >
                          {item.status}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        <button
                          onClick={() => handleDeleteStagedItem(idx)}
                          className="text-slate-400 hover:text-rose-600 transition-colors p-1 cursor-pointer"
                          title="Remove item"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {committedSuccess && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg flex items-center justify-between text-xs text-emerald-900">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Session successfully indexed into Dataverse / Azure SQL schema. Automated derived ratios computed and active alerts logged.</span>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
