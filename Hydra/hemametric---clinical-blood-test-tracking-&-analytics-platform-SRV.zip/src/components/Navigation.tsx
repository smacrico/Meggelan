import React from 'react';
import {
  Activity,
  Users,
  UploadCloud,
  TrendingUp,
  BrainCircuit,
  BarChart3,
  Bell,
  FileCode2,
  RefreshCw,
} from 'lucide-react';
import { PatientProfile } from '../types/clinical';

export type NavTab =
  | 'home'
  | 'profiles'
  | 'upload'
  | 'session-details'
  | 'trends'
  | 'differentials'
  | 'predictive'
  | 'powerbi'
  | 'alerts';

interface NavigationProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  profiles: PatientProfile[];
  selectedProfileId: string;
  onSelectProfile: (profileId: string) => void;
  activeAlertCount: number;
  onOpenDocModal: () => void;
  onResetData: () => void;
}

export const Navigation: React.FC<NavigationProps> = ({
  currentTab,
  onSelectTab,
  profiles,
  selectedProfileId,
  onSelectProfile,
  activeAlertCount,
  onOpenDocModal,
  onResetData,
}) => {
  const selectedProfile = profiles.find((p) => p.profileId === selectedProfileId);

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-xs">
      {/* 3-Zone Top Bar Contract: Brand - 4-5 links - 1 Primary Action */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-16">
          {/* Zone 1: Single text element wordmark */}
          <button
            onClick={() => onSelectTab('home')}
            className="flex items-center gap-2.5 text-left focus:outline-none group cursor-pointer"
          >
            <div className="w-9 h-9 rounded-lg bg-blue-700 flex items-center justify-center text-white font-bold text-base shadow-xs group-hover:bg-blue-800 transition-colors">
              <Activity className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0">
              HemaMetric
            </span>
          </button>

          {/* Zone 2: Navigation Links (concise, single-line, whitespace-nowrap) */}
          <nav className="hidden md:flex items-center gap-1 lg:gap-2">
            <button
              onClick={() => onSelectTab('home')}
              className={`px-3 py-2 text-sm font-medium rounded-md whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                currentTab === 'home'
                  ? 'text-blue-700 bg-blue-50/70 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              Overview
            </button>
            <button
              onClick={() => onSelectTab('profiles')}
              className={`px-3 py-2 text-sm font-medium rounded-md whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                currentTab === 'profiles'
                  ? 'text-blue-700 bg-blue-50/70 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              Patients
            </button>
            <button
              onClick={() => onSelectTab('upload')}
              className={`px-3 py-2 text-sm font-medium rounded-md whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                currentTab === 'upload'
                  ? 'text-blue-700 bg-blue-50/70 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              Lab Ingestion
            </button>
            <button
              onClick={() => onSelectTab('trends')}
              className={`px-3 py-2 text-sm font-medium rounded-md whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                currentTab === 'trends'
                  ? 'text-blue-700 bg-blue-50/70 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              Trend Analytics
            </button>
            <button
              onClick={() => onSelectTab('differentials')}
              className={`px-3 py-2 text-sm font-medium rounded-md whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                currentTab === 'differentials'
                  ? 'text-blue-700 bg-blue-50/70 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              Differentials
            </button>
            <button
              onClick={() => onSelectTab('predictive')}
              className={`px-3 py-2 text-sm font-medium rounded-md whitespace-nowrap shrink-0 transition-colors flex items-center gap-1.5 cursor-pointer ${
                currentTab === 'predictive'
                  ? 'text-indigo-700 bg-indigo-50/70 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <BrainCircuit className="w-4 h-4 text-indigo-600" />
              <span>Predictive Models</span>
            </button>
            <button
              onClick={() => onSelectTab('powerbi')}
              className={`px-3 py-2 text-sm font-medium rounded-md whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                currentTab === 'powerbi'
                  ? 'text-blue-700 bg-blue-50/70 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              Power BI Hub
            </button>
            <button
              onClick={() => onSelectTab('alerts')}
              className={`px-3 py-2 text-sm font-medium rounded-md whitespace-nowrap shrink-0 transition-colors relative cursor-pointer ${
                currentTab === 'alerts'
                  ? 'text-blue-700 bg-blue-50/70 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <span>Alerts</span>
              {activeAlertCount > 0 && (
                <span className="ml-1.5 px-1.5 py-0.2 text-xs font-mono font-semibold bg-rose-100 text-rose-700 rounded-sm">
                  {activeAlertCount}
                </span>
              )}
            </button>
          </nav>

          {/* Zone 3: 1 Primary Action + Utility trigger */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={onOpenDocModal}
              title="View Confluence System Architecture & Dataverse ERD"
              className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-md transition-colors cursor-pointer"
            >
              <FileCode2 className="w-5 h-5" />
            </button>

            <button
              onClick={() => onSelectTab('upload')}
              className="px-3.5 py-2 text-sm font-semibold text-white bg-blue-700 rounded-lg hover:bg-blue-800 transition-colors shadow-xs flex items-center gap-2 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <UploadCloud className="w-4 h-4" />
              <span>Upload Lab Report</span>
            </button>
          </div>
        </div>
      </div>

      {/* Sub-bar: Patient Context & Quick Switcher */}
      <div className="bg-slate-50 border-t border-slate-200/80 px-4 sm:px-6 lg:px-8 py-2">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-3">
            <span className="text-slate-500 font-medium whitespace-nowrap">Active Patient Context:</span>
            <div className="flex items-center gap-1.5 bg-white border border-slate-200 px-2 py-1 rounded-md shadow-2xs">
              <Users className="w-3.5 h-3.5 text-blue-600" />
              <select
                aria-label="Active Patient Context"
                value={selectedProfileId}
                onChange={(e) => onSelectProfile(e.target.value)}
                className="bg-transparent font-medium text-slate-900 focus:outline-none cursor-pointer pr-1"
              >
                {profiles.map((p) => (
                  <option key={p.profileId} value={p.profileId}>
                    {p.firstName} {p.lastName} ({p.mrn}) · {p.gender}, {new Date().getFullYear() - new Date(p.dob).getFullYear()}y
                  </option>
                ))}
              </select>
            </div>

            {selectedProfile && (
              <div className="hidden sm:flex items-center gap-2 text-slate-500">
                <span>DOB {selectedProfile.dob}</span>
                <span aria-hidden="true">·</span>
                <span>Blood Type {selectedProfile.bloodType || 'Unknown'}</span>
                <span aria-hidden="true">·</span>
                <span className="truncate max-w-xs">{selectedProfile.medicalConditions.join(', ')}</span>
              </div>
            )}
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onResetData}
              title="Reset application to original clinical sample sessions"
              className="text-slate-500 hover:text-slate-800 flex items-center gap-1 transition-colors cursor-pointer"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Reset Sample Data</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
