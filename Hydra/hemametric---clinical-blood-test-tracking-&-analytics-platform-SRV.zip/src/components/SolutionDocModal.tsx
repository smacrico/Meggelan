import React, { useState } from 'react';
import {
  FileCode2,
  X,
  Database,
  Layers,
  Cpu,
  BrainCircuit,
  ShieldCheck,
  CheckCircle2,
  Copy,
  Check,
} from 'lucide-react';

interface SolutionDocModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SolutionDocModal: React.FC<SolutionDocModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'architecture' | 'erd' | 'etl' | 'predictive' | 'compliance'>('architecture');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCopyDoc = () => {
    navigator.clipboard.writeText(`
# Clinical Blood Test Tracking & Analytics Platform
## Confluence Solution Architecture & Technical Specification

### 1. High-Level Architecture
- User Layer: Power Apps, Web Portal, Mobile App, Power BI Reports
- API Layer: Azure API Management, Azure AD/B2C, REST APIs
- Business Services: Profile Management, Laboratory Results, Biomarker Calculation Engine, Ratio Engine, Reference Range Engine, Trend Analysis, Predictive Models
- Data Processing: Power Automate, Azure Functions, OCR (PDFs), ETL Pipelines, Validation Rules, Unit Standardization
- Data Storage: Dataverse, Azure SQL Database, Blob Storage (PDFs/Reports)
- Analytics Layer: Power BI Semantic Model, DAX Metrics, Longitudinal Predictive Models

### 2. Core Entities (ERD)
- PatientProfile (ProfileID, FirstName, LastName, DOB, Gender, MRN, CreatedDate)
- Laboratory (LabID, LabName, Country, Accreditation, LicenseNumber)
- TestSession (SessionID, ProfileID, LabID, CollectionDate, ReportFile, FastingHours, Notes)
- BiomarkerCatalog (BiomarkerID, Category, Name, Code, StandardUnit, RefLow, RefHigh)
- BiomarkerResult (ResultID, SessionID, BiomarkerID, ResultValue, UnitMeasured, Status)
- DerivedMetrics (MetricID, SessionID, MetricName, MetricValue, TargetRange, Status)
- AlertHistory (AlertID, ProfileID, SessionID, Severity, Message, ClinicalGuideline)

### 3. Predictive Analytics Module
- Linear Least-Squares Trajectory Regressions (y = mt + b)
- Rate-of-Change Velocity (dY/dt) and 12-Month Projections
- Multi-domain Risk Stratification: Cardiometabolic, Hepatic Steatosis (FIB-4), Inflammation, Iron Reserve, Renal
- Actionable Lifestyle & Clinical Decision Support Protocols
    `);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xl max-w-4xl w-full max-h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-700 text-white flex items-center justify-center">
              <FileCode2 className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Confluence Solution Blueprint
              </h2>
              <div className="text-2xs text-slate-500">
                Clinical Laboratory Blood Test Tracking & Predictive Analytics Platform
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyDoc}
              className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-md transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied Markdown' : 'Copy Confluence Doc'}</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 rounded-md cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Strip */}
        <div className="flex items-center gap-1 px-4 pt-3 border-b border-slate-200 bg-white overflow-x-auto text-xs">
          {[
            { id: 'architecture', label: '1. System Architecture' },
            { id: 'erd', label: '2. Database Schema (ERD)' },
            { id: 'etl', label: '3. ETL & Power Automate' },
            { id: 'predictive', label: '4. Predictive Models' },
            { id: 'compliance', label: '5. Regulatory & HIPAA' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-3 py-2 border-b-2 font-medium whitespace-nowrap transition-colors cursor-pointer ${
                activeTab === tab.id
                  ? 'border-blue-700 text-blue-700 font-bold'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-xs text-slate-700 leading-relaxed">
          {activeTab === 'architecture' && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-slate-900">High-Level Multi-Tier Architecture</h3>
              <p>
                The platform is architected as an enterprise-grade clinical analytics solution integrating Microsoft Power Platform (Power Apps, Power Automate, Power BI), Azure serverless microservices, and Dataverse persistent store.
              </p>

              <div className="bg-slate-900 text-slate-100 p-4 rounded-lg font-mono text-2xs space-y-2 overflow-x-auto leading-normal">
                <div>┌───────────────────────────────────────────────────────────────┐</div>
                <div>│                        User Layer                            │</div>
                <div>├───────────────────────────────────────────────────────────────┤</div>
                <div>│ Power Apps │ Web Portal │ Mobile App │ Power BI Reports      │</div>
                <div>└───────────────────────┬───────────────────────────────────────┘</div>
                <div>                        │</div>
                <div>                        ▼</div>
                <div>┌───────────────────────────────────────────────────────────────┐</div>
                <div>│                       API Layer                              │</div>
                <div>├───────────────────────────────────────────────────────────────┤</div>
                <div>│ Azure API Management │ Azure AD/B2C │ REST Endpoints         │</div>
                <div>└───────────────────────┬───────────────────────────────────────┘</div>
                <div>                        │</div>
                <div>                        ▼</div>
                <div>┌───────────────────────────────────────────────────────────────┐</div>
                <div>│                     Business Services                        │</div>
                <div>├───────────────────────────────────────────────────────────────┤</div>
                <div>│ Profile Management │ Laboratory Results │ Biomarker Engine   │</div>
                <div>│ Ratio Calculation Engine │ Alert & Notification Service       │</div>
                <div>│ Reference Range Engine │ Trend Analysis │ Predictive Models  │</div>
                <div>└───────────────────────┬───────────────────────────────────────┘</div>
                <div>                        │</div>
                <div>                        ▼</div>
                <div>┌───────────────────────────────────────────────────────────────┐</div>
                <div>│                     Data Processing                          │</div>
                <div>├───────────────────────────────────────────────────────────────┤</div>
                <div>│ Power Automate │ Azure Functions │ OCR Processing (PDFs)      │</div>
                <div>│ ETL Pipelines │ Validation Rules │ Unit Standardization      │</div>
                <div>└───────────────────────┬───────────────────────────────────────┘</div>
                <div>                        │</div>
                <div>                        ▼</div>
                <div>┌───────────────────────────────────────────────────────────────┐</div>
                <div>│                      Data Storage                            │</div>
                <div>├───────────────────────────────────────────────────────────────┤</div>
                <div>│ Dataverse │ Azure SQL Database │ Blob Storage (Reports/PDFs) │</div>
                <div>└───────────────────────────────────────────────────────────────┘</div>
              </div>
            </div>
          )}

          {activeTab === 'erd' && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-slate-900">Database Schema (Entity Relationship Diagram)</h3>
              <p>
                Relational schema normalized for longitudinal blood analytics across multiple diagnostic providers:
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-3 border border-slate-200 rounded-lg bg-slate-50 space-y-1">
                  <div className="font-bold text-slate-900">PatientProfile (Entity)</div>
                  <div className="text-2xs text-slate-600 font-mono">
                    ProfileID (PK) · FirstName · LastName · DOB · Gender · MRN · CreatedDate
                  </div>
                </div>

                <div className="p-3 border border-slate-200 rounded-lg bg-slate-50 space-y-1">
                  <div className="font-bold text-slate-900">Laboratory (Entity)</div>
                  <div className="text-2xs text-slate-600 font-mono">
                    LabID (PK) · LabName · Country · Accreditation · LicenseNumber
                  </div>
                </div>

                <div className="p-3 border border-slate-200 rounded-lg bg-slate-50 space-y-1">
                  <div className="font-bold text-slate-900">TestSession (Entity)</div>
                  <div className="text-2xs text-slate-600 font-mono">
                    SessionID (PK) · ProfileID (FK) · LabID (FK) · CollectionDate · ReportFile · FastingHours · Notes
                  </div>
                </div>

                <div className="p-3 border border-slate-200 rounded-lg bg-slate-50 space-y-1">
                  <div className="font-bold text-slate-900">BiomarkerCatalog (Master Dimension)</div>
                  <div className="text-2xs text-slate-600 font-mono">
                    BiomarkerID (PK) · Category · Name · Code (LOINC) · StandardUnit · RefLow · RefHigh
                  </div>
                </div>

                <div className="p-3 border border-slate-200 rounded-lg bg-slate-50 space-y-1">
                  <div className="font-bold text-slate-900">BiomarkerResult (Fact Table)</div>
                  <div className="text-2xs text-slate-600 font-mono">
                    ResultID (PK) · SessionID (FK) · BiomarkerID (FK) · ResultValue · UnitMeasured · Status
                  </div>
                </div>

                <div className="p-3 border border-slate-200 rounded-lg bg-slate-50 space-y-1">
                  <div className="font-bold text-slate-900">DerivedMetrics (Fact Table)</div>
                  <div className="text-2xs text-slate-600 font-mono">
                    MetricID (PK) · SessionID (FK) · MetricName · MetricValue · TargetRange · Interpretation
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'etl' && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-slate-900">Power Automate Flow Specifications</h3>

              <div className="space-y-3">
                <div className="p-4 border border-slate-200 rounded-lg space-y-2">
                  <div className="font-bold text-slate-900 text-xs">
                    Flow A – Automated Lab Document Ingestion
                  </div>
                  <p className="text-2xs text-slate-600">
                    Triggers when a PDF, Excel, or CSV report is uploaded to Azure Blob Storage or Power Apps. Calls Azure AI Document Intelligence for OCR parsing, matches detected text against the Master Biomarker Catalog, executes unit conversions, and invokes the ratio calculation engine.
                  </p>
                </div>

                <div className="p-4 border border-slate-200 rounded-lg space-y-2">
                  <div className="font-bold text-slate-900 text-xs">
                    Flow B – Clinical Alert Notification & Escalation
                  </div>
                  <p className="text-2xs text-slate-600">
                    Triggered on insertion of any BiomarkerResult where Status is 'Critical High', 'Critical Low', or where historical delta exceeds 40%. Dispatches high-priority push notifications and alerts the clinician portal.
                  </p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'predictive' && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-slate-900">Predictive Analytics & Trajectory Regressions</h3>
              <p>
                The predictive analytics engine computes longitudinal least-squares regression lines across all verified historical sessions for an individual patient profile:
              </p>
              <ul className="space-y-1.5 list-disc list-inside text-2xs">
                <li><strong>Rate-of-Change Velocity ($dY/dt$):</strong> Annualized trajectory slope determining whether a biomarker is accelerating, stable, or declining.</li>
                <li><strong>12-Month Projected Levels:</strong> Future value estimations evaluating if a marker will breach normal reference boundaries within the upcoming year.</li>
                <li><strong>Multi-Domain Risk Stratification:</strong> Evaluates cardiometabolic atherogenic risk, hepatic steatosis/fibrosis (FIB-4 score), chronic low-grade inflammation, and latent iron depletion.</li>
                <li><strong>Actionable Decision Support:</strong> Evidence-graded nutritional, exercise, and clinical follow-up recommendations to reverse negative trajectories.</li>
              </ul>
            </div>
          )}

          {activeTab === 'compliance' && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-slate-900">Regulatory, HIPAA & Security Protocols</h3>
              <p>
                Engineered to meet HIPAA Title II Security Rule and GDPR requirements:
              </p>
              <div className="space-y-2 text-2xs">
                <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-md">
                  <strong>Encryption at Rest & In Transit:</strong> AES-256 Bit storage encryption on Azure SQL / Dataverse with TLS 1.3 encrypted data conduits.
                </div>
                <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-md">
                  <strong>Role-Based Access Control (RBAC):</strong> Granular separation of clinician, laboratory technician, and patient view privileges via Azure AD.
                </div>
                <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-md">
                  <strong>Audit Trail & Provenance:</strong> Immutable logging of all result modifications, alert acknowledgments, and report exports.
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between text-2xs text-slate-500">
          <span>HemaMetric Clinical Analytics Platform · Solution Spec v3.4</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 rounded-md transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
