import React, { useState, useEffect } from 'react';
import {
  Navigation,
  NavTab,
} from './components/Navigation';
import { HomeScreen } from './components/HomeScreen';
import { ProfilesScreen } from './components/ProfilesScreen';
import { UploadScreen } from './components/UploadScreen';
import { SessionDetailsScreen } from './components/SessionDetailsScreen';
import { TrendAnalysisScreen } from './components/TrendAnalysisScreen';
import { PredictiveAnalyticsScreen } from './components/PredictiveAnalyticsScreen';
import { PowerBiAnalyticsScreen } from './components/PowerBiAnalyticsScreen';
import { AlertsScreen } from './components/AlertsScreen';
import { BiomarkerComparisonScreen } from './components/BiomarkerComparisonScreen';
import { SolutionDocModal } from './components/SolutionDocModal';
import {
  getProfiles,
  getSessions,
  getLabs,
  getAlerts,
  getSelectedProfileId,
  setSelectedProfileId,
  subscribeToStore,
  addSession,
  saveOrUpdateProfile,
  acknowledgeAlert,
  resetToSeedData,
} from './services/storageService';
import { PatientProfile, TestSession, Laboratory, AlertHistory } from './types/clinical';

export default function App() {
  const [currentTab, setCurrentTab] = useState<NavTab>('home');
  const [profiles, setProfiles] = useState<PatientProfile[]>([]);
  const [sessions, setSessions] = useState<TestSession[]>([]);
  const [labs, setLabs] = useState<Laboratory[]>([]);
  const [alerts, setAlerts] = useState<AlertHistory[]>([]);
  const [selectedProfileId, setSelectedProfileIdState] = useState<string>('');
  const [selectedSessionId, setSelectedSessionId] = useState<string>('');
  const [isDocModalOpen, setIsDocModalOpen] = useState(false);

  // Sync state with storage service
  const refreshState = () => {
    const profs = getProfiles();
    const sess = getSessions();
    const l = getLabs();
    const al = getAlerts();
    const selId = getSelectedProfileId();

    setProfiles(profs);
    setSessions(sess);
    setLabs(l);
    setAlerts(al);
    setSelectedProfileIdState(selId);
  };

  useEffect(() => {
    refreshState();
    const unsubscribe = subscribeToStore(() => {
      refreshState();
    });
    return () => unsubscribe();
  }, []);

  const handleSelectProfile = (id: string) => {
    setSelectedProfileId(id);
    setSelectedProfileIdState(id);
  };

  const handleSelectSession = (sessionId: string) => {
    setSelectedSessionId(sessionId);
    setCurrentTab('session-details');
  };

  const handleAcknowledgeAlert = (alertId: string) => {
    acknowledgeAlert(alertId, 'Dr. Clinical Reviewer');
  };

  const handleSessionCommitted = (newSession: TestSession) => {
    addSession(newSession);
    setSelectedSessionId(newSession.sessionId);
    setCurrentTab('session-details');
  };

  const handleSaveProfile = (profile: PatientProfile) => {
    saveOrUpdateProfile(profile);
    handleSelectProfile(profile.profileId);
  };

  const handleResetData = () => {
    if (window.confirm('Reset all sessions and profiles to original clinical seed data?')) {
      resetToSeedData();
      setCurrentTab('home');
    }
  };

  const currentProfile = profiles.find((p) => p.profileId === selectedProfileId) || profiles[0];
  const patientSessions = sessions.filter((s) => s.profileId === currentProfile?.profileId);
  const activeAlertCount = alerts.filter((a) => !a.acknowledged).length;

  const currentSession = sessions.find((s) => s.sessionId === selectedSessionId) || patientSessions[0] || null;
  const currentLaboratory = currentSession ? labs.find((l) => l.labId === currentSession.labId) || null : null;

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col text-slate-900 antialiased">
      {/* Top Navigation Bar */}
      <Navigation
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        profiles={profiles}
        selectedProfileId={selectedProfileId}
        onSelectProfile={handleSelectProfile}
        activeAlertCount={activeAlertCount}
        onOpenDocModal={() => setIsDocModalOpen(true)}
        onResetData={handleResetData}
      />

      {/* Main Content Workspace Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {currentProfile ? (
          <>
            {currentTab === 'home' && (
              <HomeScreen
                profile={currentProfile}
                sessions={patientSessions}
                labs={labs}
                alerts={alerts}
                onSelectTab={setCurrentTab}
                onSelectSession={handleSelectSession}
                onAcknowledgeAlert={handleAcknowledgeAlert}
              />
            )}

            {currentTab === 'profiles' && (
              <ProfilesScreen
                profiles={profiles}
                sessions={sessions}
                selectedProfileId={selectedProfileId}
                onSelectProfile={handleSelectProfile}
                onSaveProfile={handleSaveProfile}
              />
            )}

            {currentTab === 'upload' && (
              <UploadScreen
                profiles={profiles}
                labs={labs}
                selectedProfileId={selectedProfileId}
                onSessionCommitted={handleSessionCommitted}
              />
            )}

            {currentTab === 'session-details' && (
              <SessionDetailsScreen
                session={currentSession}
                laboratory={currentLaboratory}
                profile={currentProfile}
                onBack={() => setCurrentTab('home')}
                onSelectTab={setCurrentTab}
              />
            )}

            {currentTab === 'trends' && (
              <TrendAnalysisScreen
                profile={currentProfile}
                sessions={patientSessions}
              />
            )}

            {currentTab === 'differentials' && (
              <BiomarkerComparisonScreen
                profile={currentProfile}
                sessions={patientSessions}
                labs={labs}
              />
            )}

            {currentTab === 'predictive' && (
              <PredictiveAnalyticsScreen
                profile={currentProfile}
                sessions={patientSessions}
              />
            )}

            {currentTab === 'powerbi' && (
              <PowerBiAnalyticsScreen
                profile={currentProfile}
                sessions={patientSessions}
                labs={labs}
              />
            )}

            {currentTab === 'alerts' && (
              <AlertsScreen
                alerts={alerts}
                profiles={profiles}
                selectedProfileId={selectedProfileId}
                onAcknowledgeAlert={handleAcknowledgeAlert}
              />
            )}
          </>
        ) : (
          <div className="py-24 text-center text-slate-500">
            Initializing Clinical Platform...
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 mt-auto py-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-700">HemaMetric</span>
            <span>·</span>
            <span>Clinical Pathology Analytics Platform</span>
            <span>·</span>
            <span>CLIA / CAP & ISO 15189 Standards</span>
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={() => setIsDocModalOpen(true)}
              className="text-slate-600 hover:text-slate-900 underline cursor-pointer"
            >
              System Architecture & ERD Blueprint
            </button>
            <span aria-hidden="true">·</span>
            <span>Local Clinical Sandbox</span>
          </div>
        </div>
      </footer>

      {/* Confluence Architecture Document Modal */}
      <SolutionDocModal
        isOpen={isDocModalOpen}
        onClose={() => setIsDocModalOpen(false)}
      />
    </div>
  );
}
