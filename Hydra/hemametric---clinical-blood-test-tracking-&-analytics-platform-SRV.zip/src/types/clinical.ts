export type Gender = 'Male' | 'Female' | 'Other';

export type BiomarkerCategory =
  | 'Hematology & CBC'
  | 'Lipid Profile'
  | 'Metabolic & Glycemic'
  | 'Liver Function'
  | 'Renal & Electrolytes'
  | 'Iron Status'
  | 'Inflammatory Markers'
  | 'Vitamins & Minerals'
  | 'Hormonal & Thyroid';

export type ResultStatus = 'Normal' | 'Low' | 'High' | 'Critical Low' | 'Critical High';
export type AlertSeverity = 'Critical' | 'Warning' | 'Informational';

export interface PatientProfile {
  profileId: string;
  firstName: string;
  lastName: string;
  dob: string;
  gender: Gender;
  bloodType?: string;
  mrn: string; // Medical Record Number
  email: string;
  phone: string;
  medicalConditions: string[];
  medications: string[];
  createdDate: string;
}

export interface Laboratory {
  labId: string;
  labName: string;
  country: string;
  city: string;
  accreditation: string; // e.g. CAP / CLIA / ISO 15189
  licenseNumber: string;
}

export interface BiomarkerCatalogItem {
  biomarkerId: string;
  category: BiomarkerCategory;
  name: string;
  code: string; // LOINC code
  standardUnit: string;
  refLowMale: number;
  refHighMale: number;
  refLowFemale: number;
  refHighFemale: number;
  criticalLow?: number;
  criticalHigh?: number;
  description: string;
  clinicalSignificance: string;
}

export interface BiomarkerResult {
  resultId: string;
  sessionId: string;
  biomarkerId: string;
  resultValue: number;
  unitMeasured: string;
  refLow: number;
  refHigh: number;
  status: ResultStatus;
  flag?: string; // L, H, CL, CH
  notes?: string;
}

export interface DerivedMetric {
  metricId: string;
  sessionId: string;
  metricName: string;
  metricValue: number;
  unit: string;
  status: 'Optimal' | 'Borderline' | 'Elevated' | 'High Risk';
  targetOptimalRange: string;
  formulaDescription: string;
  clinicalInterpretation: string;
  referenceCutoff: string;
}

export interface TestSession {
  sessionId: string;
  profileId: string;
  labId: string;
  collectionDate: string;
  fastingHours: number;
  reportFile?: string;
  notes: string;
  notesHtml?: string;
  notesLastEditedAt?: string;
  notesAuthor?: string;
  orderingPhysician: string;
  status: 'Verified' | 'Pending Review' | 'Archived';
  results: BiomarkerResult[];
  derivedMetrics: DerivedMetric[];
  createdDate: string;
}

export interface AlertHistory {
  alertId: string;
  profileId: string;
  sessionId: string;
  resultId?: string;
  severity: AlertSeverity;
  biomarkerName: string;
  valueRecorded?: number;
  referenceInterval?: string;
  message: string;
  clinicalGuideline: string;
  generatedOn: string;
  acknowledged: boolean;
  acknowledgedBy?: string;
  acknowledgedAt?: string;
}

// Predictive Analytics Types
export type TrajectoryDirection = 'Rapidly Rising' | 'Gradually Rising' | 'Stable' | 'Gradually Declining' | 'Rapidly Declining';
export type HealthRiskCategory = 'Cardiometabolic Risk' | 'Hepatic Steatosis & Fibrosis' | 'Systemic Inflammation' | 'Iron & Hematologic Reserve' | 'Renal Filtration';
export type RiskLevel = 'Low' | 'Moderate' | 'Elevated' | 'Critical';

export interface BiomarkerTrajectory {
  biomarkerId: string;
  biomarkerName: string;
  unit: string;
  dataPointsCount: number;
  historicalValues: { date: string; value: number }[];
  currentValue: number;
  annualRateOfChange: number; // change per year
  percentChangeOverall: number;
  direction: TrajectoryDirection;
  projected6Months: number;
  projected12Months: number;
  projectedStatus12Months: ResultStatus;
  thresholdCrossingWarning?: string;
  confidenceScore: number; // 0 - 100% based on sample density and linearity
}

export interface LifestyleRecommendation {
  id: string;
  category: 'Nutrition' | 'Physical Activity' | 'Sleep & Recovery' | 'Supplementation' | 'Clinical Follow-up';
  title: string;
  summary: string;
  targetBiomarkers: string[];
  expectedImpact: string;
  evidenceGrade: 'Grade A (RCT)' | 'Grade B (Cohort)' | 'Grade C (Consensus)';
  actionSteps: string[];
}

export interface PredictiveHealthRiskAssessment {
  category: HealthRiskCategory;
  currentRiskLevel: RiskLevel;
  projected12MonthRiskLevel: RiskLevel;
  riskScore: number; // 0 - 100
  trendDirection: 'Worsening' | 'Stable' | 'Improving';
  primaryDrivingBiomarkers: string[];
  clinicalSummary: string;
  recommendations: LifestyleRecommendation[];
}

export interface BiomarkerVolatilityItem {
  biomarkerId: string;
  biomarkerName: string;
  category: string;
  meanValue: number;
  standardDeviation: number;
  coefficientOfVariation: number; // CV%
  volatilityTier: 'Low' | 'Moderate' | 'Elevated' | 'High';
  unit: string;
}

export interface ProjectedVolatilityRiskAssessment {
  projectedRiskScore: number; // 0 - 100
  riskTier: 'Nominal' | 'Moderate' | 'Elevated' | 'High Strain';
  averageCoefficientOfVariation: number;
  topVolatileMarkers: BiomarkerVolatilityItem[];
  clinicalInterpretation: string;
}

export interface SystemicInflammatoryGaugeData {
  score: number; // 0 - 100
  riskTier: 'Low / Quiescent' | 'Moderate' | 'Elevated' | 'Critical';
  crpValue?: number;
  nlrValue?: number;
  plrValue?: number;
  wbcValue?: number;
  clinicalSummary: string;
}

export interface PredictiveReport {
  profileId: string;
  generatedDate: string;
  sessionsAnalyzed: number;
  spanDays: number;
  riskAssessments: PredictiveHealthRiskAssessment[];
  trajectories: BiomarkerTrajectory[];
  keyTrajectoryTakeaways: string[];
  volatilityAssessment?: ProjectedVolatilityRiskAssessment;
  systemicInflammatoryGauge?: SystemicInflammatoryGaugeData;
}

export interface FilterState {
  profileId?: string;
  dateRange: 'all' | '1m' | '6m' | '1y' | '3y';
  category?: BiomarkerCategory | 'All';
  biomarkerId?: string;
  severity?: AlertSeverity | 'All';
}
