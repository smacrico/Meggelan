import { BiomarkerDefinition } from '../types/clinical';

export const BIOMARKER_DICTIONARY: Record<string, BiomarkerDefinition> = {
  // --- LIPIDEMIC ---
  total_cholesterol: {
    code: 'total_cholesterol',
    name: 'Total Cholesterol',
    shortName: 'TC',
    category: 'lipid',
    standardUnit: 'mg/dL',
    refRange: { low: 125, high: 200, optimalLow: 140, optimalHigh: 180, unit: 'mg/dL' },
    description: 'Sum of all circulating cholesterol fractions including HDL, LDL, and VLDL.',
    clinicalSignificance: 'Primary screening marker for dyslipidemia and atherosclerotic cardiovascular risk.',
    aliases: ['cholesterol', 'total cholesterol', 'chol', 't-chol', 'chol total', 'cholesterol, total', 'serum cholesterol']
  },
  hdl: {
    code: 'hdl',
    name: 'HDL Cholesterol',
    shortName: 'HDL-C',
    category: 'lipid',
    standardUnit: 'mg/dL',
    refRange: { low: 40, high: 90, optimalLow: 50, optimalHigh: 80, unit: 'mg/dL' },
    description: 'High-Density Lipoprotein, mediates reverse cholesterol transport.',
    clinicalSignificance: 'Higher levels (>50 mg/dL) are generally cardioprotective; low HDL is a metabolic syndrome component.',
    aliases: ['hdl', 'hdl-c', 'hdl cholesterol', 'high density lipoprotein', 'cholesterol, hdl', 'hdl direct']
  },
  ldl: {
    code: 'ldl',
    name: 'LDL Cholesterol',
    shortName: 'LDL-C',
    category: 'lipid',
    standardUnit: 'mg/dL',
    refRange: { low: 50, high: 100, optimalLow: 50, optimalHigh: 70, unit: 'mg/dL' },
    description: 'Low-Density Lipoprotein, the primary atherogenic particle driver of plaque formation.',
    clinicalSignificance: 'Key target for cardiovascular prevention. Values >130 mg/dL elevate plaque accumulation risk.',
    aliases: ['ldl', 'ldl-c', 'ldl cholesterol', 'low density lipoprotein', 'ldl calculated', 'ldl direct', 'cholesterol, ldl']
  },
  triglycerides: {
    code: 'triglycerides',
    name: 'Triglycerides',
    shortName: 'TG',
    category: 'lipid',
    standardUnit: 'mg/dL',
    refRange: { low: 40, high: 150, optimalLow: 50, optimalHigh: 100, unit: 'mg/dL' },
    description: 'Circulating neutral fats carried primarily in chylomicrons and VLDL particles.',
    clinicalSignificance: 'Elevations signal insulin resistance, high carbohydrate intake, and increased atherogenic remnants.',
    aliases: ['triglycerides', 'trig', 'tg', 'triglyceride', 'serum triglycerides', 'triglycerides, serum']
  },
  non_hdl: {
    code: 'non_hdl',
    name: 'Non-HDL Cholesterol',
    shortName: 'Non-HDL',
    category: 'lipid',
    standardUnit: 'mg/dL',
    refRange: { low: 70, high: 130, optimalLow: 70, optimalHigh: 100, unit: 'mg/dL' },
    description: 'Calculated as Total Cholesterol minus HDL. Represents all atherogenic apolipoprotein B particles.',
    clinicalSignificance: 'Superior risk predictor over LDL alone in patients with elevated triglycerides or metabolic syndrome.',
    aliases: ['non hdl', 'non-hdl', 'non-hdl cholesterol', 'cholesterol, non-hdl']
  },

  // --- ENDOCRINOLOGY & METABOLIC ---
  glucose: {
    code: 'glucose',
    name: 'Fasting Glucose',
    shortName: 'Glucose',
    category: 'endocrine',
    standardUnit: 'mg/dL',
    refRange: { low: 70, high: 99, optimalLow: 75, optimalHigh: 88, unit: 'mg/dL', criticalLow: 55, criticalHigh: 200 },
    description: 'Primary energy substrate for cellular metabolism in the overnight fasting state.',
    clinicalSignificance: 'Impaired fasting glucose (100–125 mg/dL) denotes prediabetes; ≥126 mg/dL indicates diabetes.',
    aliases: ['glucose', 'fasting glucose', 'glucose, fasting', 'fbs', 'blood glucose', 'serum glucose', 'gluc']
  },
  fasting_insulin: {
    code: 'fasting_insulin',
    name: 'Fasting Insulin',
    shortName: 'Insulin',
    category: 'endocrine',
    standardUnit: 'uIU/mL',
    refRange: { low: 2.0, high: 19.6, optimalLow: 2.0, optimalHigh: 6.0, unit: 'uIU/mL' },
    description: 'Pancreatic beta-cell hormone required for cellular glucose uptake and lipolysis regulation.',
    clinicalSignificance: 'Early marker for metabolic dysfunction; rises years before fasting glucose elevates.',
    aliases: ['fasting insulin', 'insulin', 'insulin, fasting', 'serum insulin', 'insulin, serum']
  },
  hba1c: {
    code: 'hba1c',
    name: 'Hemoglobin A1c',
    shortName: 'HbA1c',
    category: 'endocrine',
    standardUnit: '%',
    refRange: { low: 4.5, high: 5.6, optimalLow: 4.8, optimalHigh: 5.3, unit: '%' },
    description: 'Glycated hemoglobin reflecting mean blood glucose over the erythrocyte lifespan (approx. 90 days).',
    clinicalSignificance: '5.7%–6.4% indicates prediabetes; ≥6.5% establishes diabetes diagnostic threshold.',
    aliases: ['hba1c', 'a1c', 'hemoglobin a1c', 'glycated hemoglobin', 'glycohemoglobin', 'hgb a1c']
  },
  tsh: {
    code: 'tsh',
    name: 'TSH (Thyroid Stimulating Hormone)',
    shortName: 'TSH',
    category: 'endocrine',
    standardUnit: 'uIU/mL',
    refRange: { low: 0.45, high: 4.5, optimalLow: 1.0, optimalHigh: 2.5, unit: 'uIU/mL' },
    description: 'Pituitary glycoprotein regulating thyroid glandular synthesis of thyroxine.',
    clinicalSignificance: 'Most sensitive marker for primary thyroid axis disorders (hypo- and hyperthyroidism).',
    aliases: ['tsh', 'thyroid stimulating hormone', 'tsh 3rd gen', 'tsh w/reflex', 'thyrotropin']
  },
  free_t4: {
    code: 'free_t4',
    name: 'Free T4 (Thyroxine)',
    shortName: 'FT4',
    category: 'endocrine',
    standardUnit: 'ng/dL',
    refRange: { low: 0.82, high: 1.77, optimalLow: 1.1, optimalHigh: 1.5, unit: 'ng/dL' },
    description: 'Unbound, biologically active fraction of the primary circulating thyroid prohormone.',
    clinicalSignificance: 'Evaluated in tandem with TSH to distinguish overt vs subclinical thyroid dysfunction.',
    aliases: ['free t4', 't4 free', 'ft4', 'free thyroxine', 'thyroxine, free']
  },
  vitamin_d: {
    code: 'vitamin_d',
    name: 'Vitamin D, 25-Hydroxy',
    shortName: 'Vit D (25-OH)',
    category: 'vitamins',
    standardUnit: 'ng/mL',
    refRange: { low: 30, high: 100, optimalLow: 45, optimalHigh: 70, unit: 'ng/mL' },
    description: 'Circulating prehormone critical for bone mineral density, immune competence, and gene expression.',
    clinicalSignificance: '<20 ng/mL is overt deficiency; 20–29 ng/mL insufficiency; optimal health range is 40–60 ng/mL.',
    aliases: ['vitamin d', 'vit d', '25-hydroxy vitamin d', 'vitamin d, 25-hydroxy', '25-oh vitamin d', 'vitamin d total', 'calcidiol']
  },

  // --- CBC & HEMATOLOGY ---
  wbc: {
    code: 'wbc',
    name: 'White Blood Cell Count',
    shortName: 'WBC',
    category: 'cbc',
    standardUnit: 'K/uL',
    refRange: { low: 4.0, high: 11.0, optimalLow: 4.5, optimalHigh: 7.5, unit: 'K/uL' },
    description: 'Total leukocyte count reflecting immune activation, infection, or bone marrow production.',
    clinicalSignificance: 'Elevations suggest acute infection, inflammation, or leukemoid reaction; low levels imply marrow suppression.',
    aliases: ['wbc', 'white blood cell count', 'leukocytes', 'white blood cells', 'wbc count']
  },
  rbc: {
    code: 'rbc',
    name: 'Red Blood Cell Count',
    shortName: 'RBC',
    category: 'cbc',
    standardUnit: 'M/uL',
    refRange: { low: 4.3, high: 5.9, optimalLow: 4.5, optimalHigh: 5.5, unit: 'M/uL' },
    description: 'Total circulating erythrocyte count carrying oxygen to peripheral tissues.',
    clinicalSignificance: 'Decreased in anemias; increased in erythrocytosis, dehydration, or chronic hypoxia.',
    aliases: ['rbc', 'red blood cell count', 'erythrocytes', 'rbc count']
  },
  hemoglobin: {
    code: 'hemoglobin',
    name: 'Hemoglobin',
    shortName: 'Hgb',
    category: 'cbc',
    standardUnit: 'g/dL',
    refRange: { low: 13.5, high: 17.5, optimalLow: 14.0, optimalHigh: 16.5, unit: 'g/dL' },
    description: 'Iron-containing metalloprotein in erythrocytes responsible for systemic oxygen delivery.',
    clinicalSignificance: 'Definitive diagnostic parameter for anemia diagnosis and severity grading.',
    aliases: ['hemoglobin', 'hgb', 'hb', 'haemoglobin']
  },
  hematocrit: {
    code: 'hematocrit',
    name: 'Hematocrit',
    shortName: 'Hct',
    category: 'cbc',
    standardUnit: '%',
    refRange: { low: 38.8, high: 50.0, optimalLow: 41.0, optimalHigh: 48.0, unit: '%' },
    description: 'Percentage of whole blood volume composed of packed red blood cells.',
    clinicalSignificance: 'Reflects blood viscosity and red cell mass; tightly tracks with hemoglobin.',
    aliases: ['hematocrit', 'hct', 'pcv', 'packed cell volume']
  },
  platelets: {
    code: 'platelets',
    name: 'Platelet Count',
    shortName: 'PLT',
    category: 'cbc',
    standardUnit: 'K/uL',
    refRange: { low: 150, high: 450, optimalLow: 180, optimalHigh: 350, unit: 'K/uL' },
    description: 'Thrombocytes essential for initial primary hemostasis and vascular wall integrity.',
    clinicalSignificance: 'Thrombocytopenia increases bleeding hazard; thrombocytosis can indicate reactive inflammation or MPN.',
    aliases: ['platelets', 'plt', 'platelet count', 'thrombocytes']
  },
  mcv: {
    code: 'mcv',
    name: 'Mean Corpuscular Volume',
    shortName: 'MCV',
    category: 'cbc',
    standardUnit: 'fL',
    refRange: { low: 80, high: 100, optimalLow: 84, optimalHigh: 94, unit: 'fL' },
    description: 'Average volume/size of individual red blood cells.',
    clinicalSignificance: '<80 fL classifies microcytic anemia (iron deficiency); >100 fL macrocytic (B12/folate/alcohol).',
    aliases: ['mcv', 'mean corpuscular volume']
  },
  mch: {
    code: 'mch',
    name: 'Mean Corpuscular Hemoglobin',
    shortName: 'MCH',
    category: 'cbc',
    standardUnit: 'pg',
    refRange: { low: 27.0, high: 33.0, optimalLow: 28.0, optimalHigh: 32.0, unit: 'pg' },
    description: 'Average mass of hemoglobin per red blood cell.',
    clinicalSignificance: 'Correlates with hypochromasia and microcytosis.',
    aliases: ['mch', 'mean corpuscular hemoglobin']
  },
  rdw: {
    code: 'rdw',
    name: 'Red Cell Distribution Width',
    shortName: 'RDW',
    category: 'cbc',
    standardUnit: '%',
    refRange: { low: 11.5, high: 14.5, optimalLow: 11.8, optimalHigh: 13.5, unit: '%' },
    description: 'Measure of the range of variation of erythrocyte volume (anisocytosis).',
    clinicalSignificance: 'Early indicator of evolving nutritional iron or vitamin deficiency before MCV changes.',
    aliases: ['rdw', 'rdw-cv', 'red cell distribution width']
  },

  // --- LIVER & METABOLIC ---
  alt: {
    code: 'alt',
    name: 'ALT (Alanine Aminotransferase)',
    shortName: 'ALT / SGPT',
    category: 'liver',
    standardUnit: 'U/L',
    refRange: { low: 7, high: 45, optimalLow: 10, optimalHigh: 26, unit: 'U/L' },
    description: 'Cytosolic enzyme highly specific to hepatocytes.',
    clinicalSignificance: 'Most sensitive indicator of hepatocellular injury, NAFLD/MASLD, and hepatic steatosis.',
    aliases: ['alt', 'sgpt', 'alanine aminotransferase', 'alt (sgpt)', 'alt/sgpt']
  },
  ast: {
    code: 'ast',
    name: 'AST (Aspartate Aminotransferase)',
    shortName: 'AST / SGOT',
    category: 'liver',
    standardUnit: 'U/L',
    refRange: { low: 8, high: 40, optimalLow: 12, optimalHigh: 28, unit: 'U/L' },
    description: 'Enzyme found in liver, cardiac myocytes, and skeletal muscle tissue.',
    clinicalSignificance: 'Evaluated with ALT via the De Ritis ratio (AST/ALT) to differentiate liver injury etiologies.',
    aliases: ['ast', 'sgot', 'aspartate aminotransferase', 'ast (sgot)', 'ast/sgot']
  },
  alp: {
    code: 'alp',
    name: 'Alkaline Phosphatase',
    shortName: 'ALP',
    category: 'liver',
    standardUnit: 'U/L',
    refRange: { low: 44, high: 147, optimalLow: 50, optimalHigh: 100, unit: 'U/L' },
    description: 'Hydrolase enzyme concentrated in bile duct epithelium and bone osteoblasts.',
    clinicalSignificance: 'Elevated in cholestatic liver diseases, biliary obstruction, or high bone turnover states.',
    aliases: ['alp', 'alk phos', 'alkaline phosphatase', 'alkaline phos']
  },
  ggt: {
    code: 'ggt',
    name: 'Gamma-Glutamyl Transferase',
    shortName: 'GGT',
    category: 'liver',
    standardUnit: 'U/L',
    refRange: { low: 9, high: 48, optimalLow: 10, optimalHigh: 30, unit: 'U/L' },
    description: 'Microsomal enzyme sensitive to biliary ductal irritation, alcohol intake, and oxidative stress.',
    clinicalSignificance: 'Confirms hepatic origin when ALP is elevated; sensitive early marker of metabolic liver stress.',
    aliases: ['ggt', 'gamma glutamyl transferase', 'gamma-glutamyl transferase', 'ggtp']
  },
  total_bilirubin: {
    code: 'total_bilirubin',
    name: 'Total Bilirubin',
    shortName: 'T-Bili',
    category: 'liver',
    standardUnit: 'mg/dL',
    refRange: { low: 0.2, high: 1.2, optimalLow: 0.3, optimalHigh: 0.9, unit: 'mg/dL' },
    description: 'Catabolic breakdown product of heme pigment metabolized by the liver.',
    clinicalSignificance: 'Hyperbilirubinemia causes jaundice; mild isolated unconjugated elevation often indicates benign Gilbert syndrome.',
    aliases: ['total bilirubin', 'bilirubin, total', 't-bili', 'bili total', 'bilirubin total']
  },
  albumin: {
    code: 'albumin',
    name: 'Albumin',
    shortName: 'Albumin',
    category: 'liver',
    standardUnit: 'g/dL',
    refRange: { low: 3.5, high: 5.2, optimalLow: 4.0, optimalHigh: 4.8, unit: 'g/dL' },
    description: 'Major circulating protein maintaining colloid oncotic pressure and carrying hormones/drugs.',
    clinicalSignificance: 'Synthesized exclusively by hepatocytes; reflects hepatic synthetic reserve and nutritional status.',
    aliases: ['albumin', 'serum albumin', 'alb']
  },

  // --- IRON & ANEMIA ---
  serum_iron: {
    code: 'serum_iron',
    name: 'Serum Iron',
    shortName: 'Iron',
    category: 'iron',
    standardUnit: 'ug/dL',
    refRange: { low: 60, high: 170, optimalLow: 80, optimalHigh: 140, unit: 'ug/dL' },
    description: 'Total circulating iron bound to transferrin in the serum.',
    clinicalSignificance: 'Fluctuates diurnally; interpreted alongside Ferritin and TIBC for comprehensive assessment.',
    aliases: ['iron', 'serum iron', 'iron, serum', 'fe']
  },
  ferritin: {
    code: 'ferritin',
    name: 'Ferritin',
    shortName: 'Ferritin',
    category: 'iron',
    standardUnit: 'ng/mL',
    refRange: { low: 30, high: 300, optimalLow: 50, optimalHigh: 150, unit: 'ng/mL' },
    description: 'Intracellular protein that stores iron; serum concentration reflects total body iron stores.',
    clinicalSignificance: 'Most sensitive marker for iron deficiency (<30 ng/mL); also an acute phase inflammatory reactant.',
    aliases: ['ferritin', 'serum ferritin', 'ferritin, serum']
  },
  tibc: {
    code: 'tibc',
    name: 'Total Iron Binding Capacity',
    shortName: 'TIBC',
    category: 'iron',
    standardUnit: 'ug/dL',
    refRange: { low: 250, high: 450, optimalLow: 280, optimalHigh: 380, unit: 'ug/dL' },
    description: 'Indirect measure of transferrin saturation capacity.',
    clinicalSignificance: 'Rises in iron deficiency state as the liver ramps up transferrin production.',
    aliases: ['tibc', 'total iron binding capacity', 'iron binding capacity']
  },

  // --- INFLAMMATION & LONGEVITY ---
  hs_crp: {
    code: 'hs_crp',
    name: 'High-Sensitivity C-Reactive Protein',
    shortName: 'hs-CRP',
    category: 'inflammation',
    standardUnit: 'mg/L',
    refRange: { low: 0.1, high: 3.0, optimalLow: 0.1, optimalHigh: 0.8, unit: 'mg/L' },
    description: 'Hepatic acute-phase reactant synthesized in response to IL-6 and inflammatory cytokines.',
    clinicalSignificance: '<1.0 mg/L low cardiovascular risk; 1.0–3.0 moderate risk; >3.0 high relative atherogenic risk.',
    aliases: ['hs-crp', 'crp', 'c-reactive protein', 'high sensitivity crp', 'crp, high sensitivity', 'hscrp']
  },
  esr: {
    code: 'esr',
    name: 'Erythrocyte Sedimentation Rate',
    shortName: 'ESR',
    category: 'inflammation',
    standardUnit: 'mm/hr',
    refRange: { low: 0, high: 20, optimalLow: 0, optimalHigh: 10, unit: 'mm/hr' },
    description: 'Rate at which red blood cells precipitate in anticoagulated whole blood over one hour.',
    clinicalSignificance: 'Nonspecific systemic inflammation marker driven by fibrinogen and immunoglobulin concentrations.',
    aliases: ['esr', 'erythrocyte sedimentation rate', 'sed rate', 'sedimentation rate']
  },

  // --- VITAMINS & MICRONUTRIENTS ---
  vitamin_b12: {
    code: 'vitamin_b12',
    name: 'Vitamin B12 (Cobalamin)',
    shortName: 'B12',
    category: 'vitamins',
    standardUnit: 'pg/mL',
    refRange: { low: 200, high: 1100, optimalLow: 450, optimalHigh: 900, unit: 'pg/mL' },
    description: 'Essential cobalt-containing vitamin required for DNA synthesis, methylation, and neuro-myelin maintenance.',
    clinicalSignificance: 'Deficiency leads to megaloblastic anemia and irreversible peripheral/central neuropathy.',
    aliases: ['vitamin b12', 'vit b12', 'b12', 'cobalamin', 'cyanocobalamin']
  },
  magnesium: {
    code: 'magnesium',
    name: 'Serum Magnesium',
    shortName: 'Magnesium',
    category: 'vitamins',
    standardUnit: 'mg/dL',
    refRange: { low: 1.8, high: 2.6, optimalLow: 2.1, optimalHigh: 2.5, unit: 'mg/dL' },
    description: 'Intracellular mineral cation acting as enzymatic cofactor in >300 biochemical reactions including ATP synthesis.',
    clinicalSignificance: 'Subclinical insufficiency correlates with arrhythmias, muscle cramps, and insulin resistance.',
    aliases: ['magnesium', 'serum magnesium', 'mg']
  }
};
