import { jsPDF } from 'jspdf';
import { ExamRecord, PatientRecord } from '../types/clinical';
import { BIOMARKER_DICTIONARY } from './biomarkerDictionary';

interface BiomarkerRow {
  analyte: string;
  value: string;
  unit: string;
  referenceRange: string;
  flag: string;
  isAbnormal: boolean;
}

/**
 * Generates an executive, hospital-grade clinical pathology PDF report
 * formatted for medical records, physician reviews, and institutional archiving.
 */
export function generateClinicalPDFReport(patient: PatientRecord, exam: ExamRecord) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = 210;
  const pageHeight = 297;
  const marginLeft = 14;
  const marginRight = 14;
  const contentWidth = pageWidth - marginLeft - marginRight;

  let y = 14;

  const checkPageBreak = (neededSpace: number) => {
    if (y + neededSpace > pageHeight - 18) {
      doc.addPage();
      y = 16;
      drawPageHeaderMini();
    }
  };

  const drawPageHeaderMini = () => {
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(140, 150, 165);
    doc.text(`CONFIDENTIAL MEDICAL RECORD · ${patient.name.toUpperCase()} (ID: ${patient.id}) · EXAM: ${exam.examDate}`, marginLeft, y);
    doc.setDrawColor(226, 232, 240);
    doc.line(marginLeft, y + 2, marginLeft + contentWidth, y + 2);
    y += 7;
  };

  // 1. TOP HEADER BANNER
  doc.setFillColor(15, 23, 42); // slate-900
  doc.rect(marginLeft, y, contentWidth, 22, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.setTextColor(255, 255, 255);
  doc.text('CLINICAL PATHOLOGY LABORATORY REPORT', marginLeft + 6, y + 9);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(203, 213, 225);
  doc.text('COMPREHENSIVE MULTI-PROFILE LONGITUDINAL BIOMARKER ANALYSIS', marginLeft + 6, y + 16);

  // Institution / Facility badge on right
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(255, 255, 255);
  doc.text(exam.labFacility.toUpperCase(), marginLeft + contentWidth - 6, y + 9, { align: 'right' });

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(148, 163, 184);
  doc.text('CLIA # 99D0874521 · CAP ACCREDITED', marginLeft + contentWidth - 6, y + 16, { align: 'right' });

  y += 26;

  // 2. PATIENT DEMOGRAPHICS & SPECIMEN METADATA BLOCK
  doc.setFillColor(248, 250, 252); // slate-50
  doc.setDrawColor(226, 232, 240); // slate-200
  doc.rect(marginLeft, y, contentWidth, 26, 'FD');

  const col1 = marginLeft + 5;
  const col2 = marginLeft + 60;
  const col3 = marginLeft + 120;

  // Row 1
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text('PATIENT NAME:', col1, y + 6);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(15, 23, 42);
  doc.text(patient.name, col1 + 25, y + 6);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text('PATIENT ID:', col2, y + 6);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(15, 23, 42);
  doc.text(patient.id, col2 + 20, y + 6);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text('EXAM DATE:', col3, y + 6);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(15, 23, 42);
  doc.text(exam.examDate, col3 + 22, y + 6);

  // Row 2
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text('AGE / GENDER:', col1, y + 13);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(15, 23, 42);
  doc.text(`${patient.age} YRS / ${patient.gender.toUpperCase()}`, col1 + 25, y + 13);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text('BIRTH DATE:', col2, y + 13);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(15, 23, 42);
  doc.text(patient.birthDate, col2 + 20, y + 13);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text('REPORT ISSUED:', col3, y + 13);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(15, 23, 42);
  doc.text(new Date().toISOString().split('T')[0], col3 + 28, y + 13);

  // Row 3
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text('ORDERING DR:', col1, y + 20);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(15, 23, 42);
  doc.text(exam.orderingPhysician || 'Attending Physician, MD', col1 + 25, y + 20);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text('SPECIMEN:', col2, y + 20);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(15, 23, 42);
  doc.text('Venous Blood (Serum / Whole Blood)', col2 + 20, y + 20);

  y += 31;

  // 3. EXECUTIVE CLINICAL SUMMARY BOX
  doc.setFillColor(241, 245, 249);
  doc.setDrawColor(203, 213, 225);
  doc.rect(marginLeft, y, contentWidth, 16, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(15, 23, 42);
  doc.text('EXECUTIVE RISK PROFILE & CLINICAL INDICES:', marginLeft + 4, y + 5);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(51, 65, 85);

  const aipText = `Atherogenic Index (AIP): ${exam.lipidMetrics?.aip ?? 'N/A'} [${exam.lipidMetrics?.risk_category ?? 'Normal'}]`;
  const homaText = `HOMA-IR Score: ${exam.endoMetrics?.homa_ir ?? 'N/A'} [${exam.endoMetrics?.homa_ir_status ?? 'Normal'}]`;
  const deRitisText = `De Ritis (AST/ALT): ${exam.liverMetrics?.de_ritis_ratio ?? 'N/A'}`;
  const crpText = `hs-CRP: ${exam.inflammationMetrics?.hs_crp ?? 'N/A'} mg/L`;

  doc.text(`${aipText}   |   ${homaText}`, marginLeft + 4, y + 10);
  doc.text(`${deRitisText}   |   ${crpText}`, marginLeft + 4, y + 14);

  y += 21;

  // HELPER: DRAW TABLE SECTION
  const renderSectionTable = (
    title: string,
    rows: BiomarkerRow[],
    commentary?: string
  ) => {
    checkPageBreak(25 + rows.length * 6);

    // Section title bar
    doc.setFillColor(226, 232, 240); // slate-200
    doc.rect(marginLeft, y, contentWidth, 6.5, 'F');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.setTextColor(15, 23, 42);
    doc.text(title.toUpperCase(), marginLeft + 3, y + 4.5);

    y += 7.5;

    // Table Header
    doc.setFillColor(248, 250, 252);
    doc.rect(marginLeft, y, contentWidth, 5.5, 'F');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(100, 116, 139);
    doc.text('TEST ANALYTE', marginLeft + 3, y + 4);
    doc.text('OBSERVED VALUE', marginLeft + 75, y + 4);
    doc.text('UNITS', marginLeft + 115, y + 4);
    doc.text('REFERENCE INTERVAL', marginLeft + 140, y + 4);
    doc.text('FLAG', marginLeft + contentWidth - 14, y + 4, { align: 'right' });

    y += 6;

    // Table Rows
    rows.forEach((row, idx) => {
      checkPageBreak(6);

      const isEven = idx % 2 === 0;
      if (isEven) {
        doc.setFillColor(255, 255, 255);
      } else {
        doc.setFillColor(250, 250, 252);
      }
      doc.rect(marginLeft, y, contentWidth, 5.5, 'F');

      doc.setFont('helvetica', row.isAbnormal ? 'bold' : 'normal');
      doc.setFontSize(8);
      doc.setTextColor(row.isAbnormal ? 185 : 30, row.isAbnormal ? 28 : 41, row.isAbnormal ? 28 : 59);
      doc.text(row.analyte, marginLeft + 3, y + 4);

      // Value
      doc.setFont('helvetica', row.isAbnormal ? 'bold' : 'bold');
      doc.setFontSize(8.5);
      if (row.isAbnormal) {
        doc.setTextColor(220, 38, 38); // red
      } else {
        doc.setTextColor(15, 23, 42);
      }
      doc.text(row.value, marginLeft + 75, y + 4);

      // Units
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7.5);
      doc.setTextColor(100, 116, 139);
      doc.text(row.unit, marginLeft + 115, y + 4);

      // Ref Interval
      doc.text(row.referenceRange, marginLeft + 140, y + 4);

      // Flag
      if (row.flag && row.flag !== 'NORMAL') {
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(7.5);
        if (row.flag === 'HIGH' || row.flag === 'CRITICAL') {
          doc.setTextColor(220, 38, 38);
        } else if (row.flag === 'LOW') {
          doc.setTextColor(217, 119, 6);
        } else {
          doc.setTextColor(5, 150, 105);
        }
        doc.text(row.flag, marginLeft + contentWidth - 14, y + 4, { align: 'right' });
      } else {
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(7.5);
        doc.setTextColor(148, 163, 184);
        doc.text('NORMAL', marginLeft + contentWidth - 14, y + 4, { align: 'right' });
      }

      y += 5.5;
    });

    // Optional Commentary Note
    if (commentary) {
      checkPageBreak(8);
      doc.setFont('helvetica', 'italic');
      doc.setFontSize(7);
      doc.setTextColor(100, 116, 139);
      doc.text(`* ${commentary}`, marginLeft + 3, y + 4);
      y += 6;
    }

    y += 3.5;
  };

  // --- SECTION 1: LIPIDEMIC PROFILE ---
  const lipid = exam.lipidMetrics;
  const lipidRows: BiomarkerRow[] = [
    {
      analyte: 'Total Cholesterol',
      value: `${lipid?.total_cholesterol ?? '—'}`,
      unit: 'mg/dL',
      referenceRange: '125 – 200',
      flag: (lipid?.total_cholesterol ?? 0) > 200 ? 'HIGH' : 'NORMAL',
      isAbnormal: (lipid?.total_cholesterol ?? 0) > 200,
    },
    {
      analyte: 'HDL Cholesterol',
      value: `${lipid?.hdl ?? '—'}`,
      unit: 'mg/dL',
      referenceRange: '40 – 90',
      flag: (lipid?.hdl ?? 0) < 40 ? 'LOW' : 'NORMAL',
      isAbnormal: (lipid?.hdl ?? 0) < 40,
    },
    {
      analyte: `LDL Cholesterol (${lipid?.ldl_source === 'calculated' ? 'Calculated' : 'Reported'})`,
      value: `${lipid?.ldl_final ?? '—'}`,
      unit: 'mg/dL',
      referenceRange: '50 – 100',
      flag: (lipid?.ldl_final ?? 0) > 100 ? 'HIGH' : 'NORMAL',
      isAbnormal: (lipid?.ldl_final ?? 0) > 100,
    },
    {
      analyte: 'Triglycerides',
      value: `${lipid?.triglycerides ?? '—'}`,
      unit: 'mg/dL',
      referenceRange: '40 – 150',
      flag: (lipid?.triglycerides ?? 0) > 150 ? 'HIGH' : 'NORMAL',
      isAbnormal: (lipid?.triglycerides ?? 0) > 150,
    },
    {
      analyte: 'Non-HDL Cholesterol',
      value: `${lipid?.non_hdl_final ?? '—'}`,
      unit: 'mg/dL',
      referenceRange: '< 130',
      flag: (lipid?.non_hdl_final ?? 0) > 130 ? 'HIGH' : 'NORMAL',
      isAbnormal: (lipid?.non_hdl_final ?? 0) > 130,
    },
    {
      analyte: 'Remnant Cholesterol',
      value: `${lipid?.remnant_cholesterol ?? '—'}`,
      unit: 'mg/dL',
      referenceRange: '< 24',
      flag: (lipid?.remnant_cholesterol ?? 0) > 24 ? 'HIGH' : 'NORMAL',
      isAbnormal: (lipid?.remnant_cholesterol ?? 0) > 24,
    },
    {
      analyte: 'Atherogenic Index of Plasma (AIP)',
      value: `${lipid?.aip ?? '—'}`,
      unit: 'index',
      referenceRange: '< 0.11 (Low Risk)',
      flag: (lipid?.aip ?? 0) > 0.21 ? 'HIGH' : (lipid?.aip ?? 0) > 0.11 ? 'BORDERLINE' : 'NORMAL',
      isAbnormal: (lipid?.aip ?? 0) > 0.11,
    },
    {
      analyte: 'Triglyceride to HDL Ratio',
      value: `${lipid?.trig_hdl_ratio ?? '—'}`,
      unit: 'ratio',
      referenceRange: '< 2.0 (Optimal)',
      flag: (lipid?.trig_hdl_ratio ?? 0) > 3.0 ? 'HIGH' : 'NORMAL',
      isAbnormal: (lipid?.trig_hdl_ratio ?? 0) > 3.0,
    },
  ];
  renderSectionTable(
    '1. Lipidemic Profile & Atherogenic Calculations',
    lipidRows,
    `Calculated LDL derived via Friedewald formula (TC - HDL - TG/5). AIP calculated as log10(TG/HDL molar). ${lipid?.record_quality_note || ''}`
  );

  // --- SECTION 2: ENDOCRINOLOGY & METABOLIC ---
  const endo = exam.endoMetrics;
  const endoRows: BiomarkerRow[] = [
    {
      analyte: 'Fasting Glucose',
      value: `${endo?.glucose ?? '—'}`,
      unit: 'mg/dL',
      referenceRange: '70 – 99',
      flag: (endo?.glucose ?? 0) > 99 ? 'HIGH' : (endo?.glucose ?? 0) < 70 ? 'LOW' : 'NORMAL',
      isAbnormal: (endo?.glucose ?? 0) > 99 || (endo?.glucose ?? 0) < 70,
    },
    {
      analyte: 'Fasting Insulin',
      value: `${endo?.fasting_insulin ?? '—'}`,
      unit: 'uIU/mL',
      referenceRange: '2.0 – 19.6',
      flag: (endo?.fasting_insulin ?? 0) > 15 ? 'HIGH' : 'NORMAL',
      isAbnormal: (endo?.fasting_insulin ?? 0) > 15,
    },
    {
      analyte: 'Hemoglobin A1c',
      value: `${endo?.hba1c ?? '—'}`,
      unit: '%',
      referenceRange: '4.5 – 5.6',
      flag: (endo?.hba1c ?? 0) > 5.6 ? 'HIGH' : 'NORMAL',
      isAbnormal: (endo?.hba1c ?? 0) > 5.6,
    },
    {
      analyte: 'HOMA-IR Score',
      value: `${endo?.homa_ir ?? '—'}`,
      unit: 'index',
      referenceRange: '< 1.0 (Optimal)',
      flag: (endo?.homa_ir ?? 0) >= 2.0 ? 'HIGH' : (endo?.homa_ir ?? 0) >= 1.0 ? 'BORDERLINE' : 'NORMAL',
      isAbnormal: (endo?.homa_ir ?? 0) >= 1.9,
    },
    {
      analyte: 'QUICKI Insulin Sensitivity',
      value: `${endo?.quicki ?? '—'}`,
      unit: 'index',
      referenceRange: '> 0.382 (Normal)',
      flag: (endo?.quicki ?? 1) < 0.33 ? 'LOW' : 'NORMAL',
      isAbnormal: (endo?.quicki ?? 1) < 0.33,
    },
    {
      analyte: 'Estimated Average Glucose (eAG)',
      value: `${endo?.eag_mgdl ?? '—'}`,
      unit: 'mg/dL',
      referenceRange: '70 – 114',
      flag: (endo?.eag_mgdl ?? 0) > 114 ? 'HIGH' : 'NORMAL',
      isAbnormal: (endo?.eag_mgdl ?? 0) > 114,
    },
    {
      analyte: 'TSH (Thyroid Stimulating Hormone)',
      value: `${endo?.tsh ?? '—'}`,
      unit: 'uIU/mL',
      referenceRange: '0.45 – 4.50',
      flag: (endo?.tsh ?? 0) > 4.5 ? 'HIGH' : (endo?.tsh ?? 0) < 0.45 ? 'LOW' : 'NORMAL',
      isAbnormal: (endo?.tsh ?? 0) > 4.5 || (endo?.tsh ?? 0) < 0.45,
    },
    {
      analyte: 'Free Thyroxine (FT4)',
      value: `${endo?.free_t4 ?? '—'}`,
      unit: 'ng/dL',
      referenceRange: '0.82 – 1.77',
      flag: (endo?.free_t4 ?? 0) > 1.77 ? 'HIGH' : (endo?.free_t4 ?? 0) < 0.82 ? 'LOW' : 'NORMAL',
      isAbnormal: (endo?.free_t4 ?? 0) > 1.77 || (endo?.free_t4 ?? 0) < 0.82,
    },
    {
      analyte: 'Vitamin D, 25-Hydroxy',
      value: `${endo?.vitamin_d ?? '—'}`,
      unit: 'ng/mL',
      referenceRange: '30 – 100',
      flag: (endo?.vitamin_d ?? 50) < 30 ? 'LOW' : 'NORMAL',
      isAbnormal: (endo?.vitamin_d ?? 50) < 30,
    },
  ];
  renderSectionTable(
    '2. Endocrinology & Glycemic Dynamics',
    endoRows,
    `HOMA-IR = (Glucose * Insulin) / 405. Classifies beta-cell secretory demand vs peripheral resistance.`
  );

  // --- SECTION 3: CBC & HEMATOLOGY ---
  const cbc = exam.cbcMetrics;
  const cbcRows: BiomarkerRow[] = [
    {
      analyte: 'White Blood Cell Count (WBC)',
      value: `${cbc?.wbc ?? '—'}`,
      unit: 'K/uL',
      referenceRange: '4.0 – 11.0',
      flag: (cbc?.wbc ?? 0) > 11.0 ? 'HIGH' : (cbc?.wbc ?? 0) < 4.0 ? 'LOW' : 'NORMAL',
      isAbnormal: (cbc?.wbc ?? 0) > 11.0 || (cbc?.wbc ?? 0) < 4.0,
    },
    {
      analyte: 'Red Blood Cell Count (RBC)',
      value: `${cbc?.rbc ?? '—'}`,
      unit: 'M/uL',
      referenceRange: '4.3 – 5.9',
      flag: 'NORMAL',
      isAbnormal: false,
    },
    {
      analyte: 'Hemoglobin',
      value: `${cbc?.hemoglobin ?? '—'}`,
      unit: 'g/dL',
      referenceRange: '13.5 – 17.5',
      flag: (cbc?.hemoglobin ?? 15) < 13.5 ? 'LOW' : 'NORMAL',
      isAbnormal: (cbc?.hemoglobin ?? 15) < 13.5,
    },
    {
      analyte: 'Hematocrit',
      value: `${cbc?.hematocrit ?? '—'}`,
      unit: '%',
      referenceRange: '38.8 – 50.0',
      flag: 'NORMAL',
      isAbnormal: false,
    },
    {
      analyte: 'Mean Corpuscular Volume (MCV)',
      value: `${cbc?.mcv ?? '—'}`,
      unit: 'fL',
      referenceRange: '80 – 100',
      flag: (cbc?.mcv ?? 90) < 80 ? 'LOW' : (cbc?.mcv ?? 90) > 100 ? 'HIGH' : 'NORMAL',
      isAbnormal: (cbc?.mcv ?? 90) < 80 || (cbc?.mcv ?? 90) > 100,
    },
    {
      analyte: 'Platelet Count',
      value: `${cbc?.platelets ?? '—'}`,
      unit: 'K/uL',
      referenceRange: '150 – 450',
      flag: 'NORMAL',
      isAbnormal: false,
    },
    {
      analyte: 'Neutrophil to Lymphocyte Ratio (NLR)',
      value: `${cbc?.nlr ?? '—'}`,
      unit: 'ratio',
      referenceRange: '< 2.0 (Low Stress)',
      flag: (cbc?.nlr ?? 0) > 3.0 ? 'HIGH' : 'NORMAL',
      isAbnormal: (cbc?.nlr ?? 0) > 3.0,
    },
  ];
  renderSectionTable(
    '3. Complete Blood Count & Red Cell Morphology',
    cbcRows,
    `Classification: ${cbc?.anemia_classification ?? 'Normal'}. Evaluated via automated laser flow cytometry.`
  );

  // --- SECTION 4: HEPATIC & METABOLIC ---
  const liver = exam.liverMetrics;
  const liverRows: BiomarkerRow[] = [
    {
      analyte: 'ALT (Alanine Aminotransferase)',
      value: `${liver?.alt ?? '—'}`,
      unit: 'U/L',
      referenceRange: '7 – 45',
      flag: (liver?.alt ?? 0) > 45 ? 'HIGH' : 'NORMAL',
      isAbnormal: (liver?.alt ?? 0) > 45,
    },
    {
      analyte: 'AST (Aspartate Aminotransferase)',
      value: `${liver?.ast ?? '—'}`,
      unit: 'U/L',
      referenceRange: '8 – 40',
      flag: (liver?.ast ?? 0) > 40 ? 'HIGH' : 'NORMAL',
      isAbnormal: (liver?.ast ?? 0) > 40,
    },
    {
      analyte: 'De Ritis Ratio (AST / ALT)',
      value: `${liver?.de_ritis_ratio ?? '—'}`,
      unit: 'ratio',
      referenceRange: '< 1.0 (Metabolic)',
      flag: (liver?.de_ritis_ratio ?? 0) > 2.0 ? 'HIGH' : 'NORMAL',
      isAbnormal: (liver?.de_ritis_ratio ?? 0) > 2.0,
    },
    {
      analyte: 'Gamma-Glutamyl Transferase (GGT)',
      value: `${liver?.ggt ?? '—'}`,
      unit: 'U/L',
      referenceRange: '9 – 48',
      flag: (liver?.ggt ?? 0) > 48 ? 'HIGH' : 'NORMAL',
      isAbnormal: (liver?.ggt ?? 0) > 48,
    },
    {
      analyte: 'Alkaline Phosphatase (ALP)',
      value: `${liver?.alp ?? '—'}`,
      unit: 'U/L',
      referenceRange: '44 – 147',
      flag: 'NORMAL',
      isAbnormal: false,
    },
    {
      analyte: 'Total Bilirubin',
      value: `${liver?.total_bilirubin ?? '—'}`,
      unit: 'mg/dL',
      referenceRange: '0.2 – 1.2',
      flag: 'NORMAL',
      isAbnormal: false,
    },
    {
      analyte: 'Serum Albumin',
      value: `${liver?.albumin ?? '—'}`,
      unit: 'g/dL',
      referenceRange: '3.5 – 5.2',
      flag: 'NORMAL',
      isAbnormal: false,
    },
  ];
  renderSectionTable(
    '4. Hepatic Transaminases & Synthetic Function',
    liverRows,
    `De Ritis Ratio evaluates parenchymal vs toxic injury patterns. Current tier: ${liver?.liver_stress_tier ?? 'Nominal'}.`
  );

  // --- SECTION 5: IRON & INFLAMMATION ---
  const iron = exam.ironMetrics;
  const inflam = exam.inflammationMetrics;
  const vit = exam.vitaminsMetrics;
  const ironRows: BiomarkerRow[] = [
    {
      analyte: 'Serum Iron',
      value: `${iron?.serum_iron ?? '—'}`,
      unit: 'ug/dL',
      referenceRange: '60 – 170',
      flag: 'NORMAL',
      isAbnormal: false,
    },
    {
      analyte: 'Ferritin (Total Iron Stores)',
      value: `${iron?.ferritin ?? '—'}`,
      unit: 'ng/mL',
      referenceRange: '30 – 300',
      flag: (iron?.ferritin ?? 100) < 30 ? 'LOW' : (iron?.ferritin ?? 100) > 350 ? 'HIGH' : 'NORMAL',
      isAbnormal: (iron?.ferritin ?? 100) < 30,
    },
    {
      analyte: 'Total Iron Binding Capacity (TIBC)',
      value: `${iron?.tibc ?? '—'}`,
      unit: 'ug/dL',
      referenceRange: '250 – 450',
      flag: 'NORMAL',
      isAbnormal: false,
    },
    {
      analyte: 'Transferrin Saturation (TSAT)',
      value: `${iron?.tsat ?? '—'}`,
      unit: '%',
      referenceRange: '20 – 45',
      flag: (iron?.tsat ?? 30) < 20 ? 'LOW' : (iron?.tsat ?? 30) > 45 ? 'HIGH' : 'NORMAL',
      isAbnormal: (iron?.tsat ?? 30) < 20,
    },
    {
      analyte: 'hs-CRP (High-Sensitivity CRP)',
      value: `${inflam?.hs_crp ?? '—'}`,
      unit: 'mg/L',
      referenceRange: '< 1.0 (Low CVD Risk)',
      flag: (inflam?.hs_crp ?? 0) > 3.0 ? 'HIGH' : (inflam?.hs_crp ?? 0) > 1.0 ? 'AVERAGE' : 'NORMAL',
      isAbnormal: (inflam?.hs_crp ?? 0) > 3.0,
    },
    {
      analyte: 'Sedimentation Rate (ESR)',
      value: `${inflam?.esr ?? '—'}`,
      unit: 'mm/hr',
      referenceRange: '0 – 20',
      flag: 'NORMAL',
      isAbnormal: false,
    },
    {
      analyte: 'Vitamin B12 (Cobalamin)',
      value: `${vit?.vitamin_b12 ?? '—'}`,
      unit: 'pg/mL',
      referenceRange: '200 – 1100',
      flag: 'NORMAL',
      isAbnormal: false,
    },
  ];
  renderSectionTable(
    '5. Iron Kinetics, Micronutrients, & Cardiovascular Inflammation',
    ironRows,
    `hs-CRP < 1.0 mg/L indicates low cardiovascular inflammation risk; values > 3.0 mg/L reflect high relative risk.`
  );

  // 6. CLINICAL SIGNATURE & LEGAL DISCLAIMER
  checkPageBreak(25);
  doc.setDrawColor(226, 232, 240);
  doc.line(marginLeft, y + 2, marginLeft + contentWidth, y + 2);
  y += 6;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(15, 23, 42);
  doc.text('ELECTRONIC SIGNATURE & VALIDATION:', marginLeft, y + 2);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(100, 116, 139);
  doc.text(
    `Validated by Clinical Laboratory Director · Electronically certified on ${new Date().toISOString()} · All assay methodologies conform to CLIA/CAP reference standards.`,
    marginLeft,
    y + 6
  );
  doc.text(
    'NOTICE: This document is an official medical laboratory test record. It contains privileged, confidential health information intended strictly for authorized patient care and medical record archive.',
    marginLeft,
    y + 10
  );

  // Page numbering in footer across all pages
  const totalPages = doc.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(148, 163, 184);
    doc.text(
      `Blood Analysis & Clinical Laboratory Platform · Page ${i} of ${totalPages}`,
      pageWidth / 2,
      pageHeight - 8,
      { align: 'center' }
    );
  }

  // Trigger download
  const cleanName = patient.name.replace(/\s+/g, '_');
  const filename = `Clinical_Lab_Report_${cleanName}_${exam.examDate}.pdf`;
  doc.save(filename);
}
