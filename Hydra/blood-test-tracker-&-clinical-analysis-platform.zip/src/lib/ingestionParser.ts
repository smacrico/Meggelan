import { ExamRecord, LegacyTestResult } from '../types/clinical';
import { BIOMARKER_DICTIONARY } from './biomarkerDictionary';
import { buildExamRecord } from './sampleData';

export interface ParseResult {
  success: boolean;
  examRecord?: ExamRecord;
  matchedCount: number;
  extractedMarkers: Array<{
    code: string;
    name: string;
    value: number;
    unit: string;
    rawLine: string;
  }>;
  warnings: string[];
}

/**
 * Intelligent Lab Report Text & CSV Parser
 * Bridges legacy lab reports into structured profile tables and derived metrics.
 */
export function parseLabReportText(
  inputText: string,
  params: {
    patientId: string;
    examDate: string;
    labFacility: string;
    sourceFile?: string;
  }
): ParseResult {
  const lines = inputText.split(/\r?\n/);
  const warnings: string[] = [];
  const extractedMarkers: ParseResult['extractedMarkers'] = [];
  const mappedValues: Record<string, number> = {};

  // Build lookup index of aliases
  const aliasToCodeMap: Map<string, string> = new Map();
  Object.values(BIOMARKER_DICTIONARY).forEach((def) => {
    aliasToCodeMap.set(def.name.toLowerCase(), def.code);
    aliasToCodeMap.set(def.code.toLowerCase(), def.code);
    aliasToCodeMap.set(def.shortName.toLowerCase(), def.code);
    def.aliases.forEach((alias) => {
      aliasToCodeMap.set(alias.toLowerCase(), def.code);
    });
  });

  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;

    // Check CSV line or tab-separated / space-delimited
    let parts: string[] = [];
    if (trimmed.includes(',')) {
      parts = trimmed.split(',').map((p) => p.trim().replace(/^["']|["']$/g, ''));
    } else if (trimmed.includes('\t')) {
      parts = trimmed.split('\t').map((p) => p.trim());
    } else {
      // Delimited by multiple spaces or colon
      if (trimmed.includes(':')) {
        const splitColon = trimmed.split(':');
        parts = [splitColon[0].trim(), splitColon[1].trim()];
      } else {
        parts = trimmed.split(/\s{2,}|\s*\|\s*/).map((p) => p.trim());
      }
    }

    // Try finding analyte name and numeric value
    let matchedCode: string | null = null;
    let foundValue: number | null = null;
    let foundUnit = '';

    // Strategy A: Multi-part match
    for (let i = 0; i < parts.length; i++) {
      const seg = parts[i].toLowerCase();
      // Check exact or substring match in alias map
      for (const [alias, code] of aliasToCodeMap.entries()) {
        if (seg === alias || seg.startsWith(alias) || seg.includes(alias)) {
          // Verify it's a genuine marker
          matchedCode = code;
          break;
        }
      }
      if (matchedCode) {
        // Look for number in subsequent parts or same part
        for (let j = 0; j < parts.length; j++) {
          if (j === i) continue;
          const numMatch = parts[j].match(/[-+]?\d*\.?\d+/);
          if (numMatch) {
            const parsed = parseFloat(numMatch[0]);
            if (!isNaN(parsed)) {
              foundValue = parsed;
              foundUnit = parts[j].replace(/[-+]?\d*\.?\d+/, '').trim() || parts[j + 1] || '';
              break;
            }
          }
        }
        break;
      }
    }

    // Strategy B: Regex search on the entire raw line
    if (!matchedCode || foundValue === null) {
      const lowerLine = trimmed.toLowerCase();
      for (const [alias, code] of aliasToCodeMap.entries()) {
        // require word boundary or distinct presence
        const regex = new RegExp(`\\b${alias.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i');
        if (regex.test(lowerLine)) {
          matchedCode = code;
          // Extract first numeric token after alias
          const afterAlias = lowerLine.slice(lowerLine.indexOf(alias) + alias.length);
          const numMatch = afterAlias.match(/[:=\s]+([-+]?\d*\.?\d+)/);
          if (numMatch && numMatch[1]) {
            const val = parseFloat(numMatch[1]);
            if (!isNaN(val)) {
              foundValue = val;
            }
          }
          break;
        }
      }
    }

    if (matchedCode && foundValue !== null) {
      mappedValues[matchedCode] = foundValue;
      const def = BIOMARKER_DICTIONARY[matchedCode];
      extractedMarkers.push({
        code: matchedCode,
        name: def ? def.name : matchedCode,
        value: foundValue,
        unit: foundUnit || (def ? def.standardUnit : ''),
        rawLine: trimmed,
      });
    }
  }

  if (extractedMarkers.length === 0) {
    return {
      success: false,
      matchedCount: 0,
      extractedMarkers: [],
      warnings: ['No recognized clinical laboratory markers found in the provided text. Please verify formatting.'],
    };
  }

  // Construct raw profile inputs
  const examId = `exam-import-${Date.now()}`;
  const examRecord = buildExamRecord({
    id: examId,
    patientId: params.patientId,
    examDate: params.examDate || new Date().toISOString().split('T')[0],
    labFacility: params.labFacility || 'Ingested Laboratory Report',
    sourceType: 'pdf',
    sourceFile: params.sourceFile || 'Imported_Lab_Report.txt',
    notes: `Ingested from clinical report. Successfully mapped ${extractedMarkers.length} biomarker analytes.`,
    lipid: {
      exam_date: params.examDate,
      total_cholesterol: mappedValues['total_cholesterol'] ?? null,
      hdl: mappedValues['hdl'] ?? null,
      ldl: mappedValues['ldl'] ?? null,
      triglycerides: mappedValues['triglycerides'] ?? null,
    },
    endo: {
      exam_date: params.examDate,
      glucose_for_calc: mappedValues['glucose'] ?? null,
      fasting_insulin: mappedValues['fasting_insulin'] ?? null,
      hba1c: mappedValues['hba1c'] ?? null,
      tsh: mappedValues['tsh'] ?? null,
      free_t4: mappedValues['free_t4'] ?? null,
      vitamin_d: mappedValues['vitamin_d'] ?? null,
    },
    cbc: {
      exam_date: params.examDate,
      wbc: mappedValues['wbc'] ?? null,
      rbc: mappedValues['rbc'] ?? null,
      hemoglobin: mappedValues['hemoglobin'] ?? null,
      hematocrit: mappedValues['hematocrit'] ?? null,
      platelets: mappedValues['platelets'] ?? null,
      mcv: mappedValues['mcv'] ?? null,
      mch: mappedValues['mch'] ?? null,
      mchc: null,
      rdw: mappedValues['rdw'] ?? null,
      neutrophils_pct: null,
      lymphocytes_pct: null,
      monocytes_pct: null,
      eosinophils_pct: null,
      basophils_pct: null,
    },
    liver: {
      exam_date: params.examDate,
      alt: mappedValues['alt'] ?? null,
      ast: mappedValues['ast'] ?? null,
      alp: mappedValues['alp'] ?? null,
      ggt: mappedValues['ggt'] ?? null,
      total_bilirubin: mappedValues['total_bilirubin'] ?? null,
      direct_bilirubin: null,
      albumin: mappedValues['albumin'] ?? null,
      total_protein: null,
    },
    iron: {
      exam_date: params.examDate,
      serum_iron: mappedValues['serum_iron'] ?? null,
      ferritin: mappedValues['ferritin'] ?? null,
      tibc: mappedValues['tibc'] ?? null,
      uibc: null,
    },
    inflammation: {
      exam_date: params.examDate,
      hs_crp: mappedValues['hs_crp'] ?? null,
      esr: mappedValues['esr'] ?? null,
      ferritin: mappedValues['ferritin'] ?? null,
    },
    vitamins: {
      exam_date: params.examDate,
      vitamin_b12: mappedValues['vitamin_b12'] ?? null,
      folate: null,
      vitamin_d: mappedValues['vitamin_d'] ?? null,
      magnesium: mappedValues['magnesium'] ?? null,
      zinc: null,
      calcium: null,
    },
  });

  return {
    success: true,
    examRecord,
    matchedCount: extractedMarkers.length,
    extractedMarkers,
    warnings,
  };
}
