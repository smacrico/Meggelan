import {
  LipidRaw,
  LipidMetrics,
  EndoRaw,
  EndoMetrics,
  CBCRaw,
  CBCMetrics,
  LiverRaw,
  LiverMetrics,
  IronRaw,
  IronMetrics,
  InflammationRaw,
  InflammationMetrics,
  VitaminsRaw,
  VitaminsMetrics,
  SeverityLevel,
} from '../types/clinical';
import { BIOMARKER_DICTIONARY } from './biomarkerDictionary';

// Helper rounding utility
export function round2(num: number | null | undefined): number | null {
  if (num === null || num === undefined || isNaN(num)) return null;
  return Math.round(num * 100) / 100;
}

export function round1(num: number | null | undefined): number | null {
  if (num === null || num === undefined || isNaN(num)) return null;
  return Math.round(num * 10) / 10;
}

// Evaluate severity of a given biomarker against its reference and optimal ranges
export function evaluateSeverity(code: string, value: number | null | undefined): {
  severity: SeverityLevel;
  flag: 'Normal' | 'High' | 'Low' | 'Critical';
  label: string;
} {
  if (value === null || value === undefined) {
    return { severity: 'normal', flag: 'Normal', label: 'Not Measured' };
  }

  const def = BIOMARKER_DICTIONARY[code];
  if (!def) {
    return { severity: 'normal', flag: 'Normal', label: 'Normal' };
  }

  const { low, high, optimalLow, optimalHigh, criticalLow, criticalHigh } = def.refRange;

  if (criticalLow !== undefined && value <= criticalLow) {
    return { severity: 'critical', flag: 'Critical', label: 'Critical Low' };
  }
  if (criticalHigh !== undefined && value >= criticalHigh) {
    return { severity: 'critical', flag: 'Critical', label: 'Critical High' };
  }
  if (value < low) {
    return { severity: 'abnormal_low', flag: 'Low', label: 'Low' };
  }
  if (value > high) {
    return { severity: 'abnormal_high', flag: 'High', label: 'High' };
  }
  if (optimalLow !== undefined && optimalHigh !== undefined) {
    if (value >= optimalLow && value <= optimalHigh) {
      return { severity: 'optimal', flag: 'Normal', label: 'Optimal' };
    }
    return { severity: 'borderline', flag: 'Normal', label: 'Borderline' };
  }

  return { severity: 'normal', flag: 'Normal', label: 'Normal' };
}

// =========================================================================
// 1. LIPIDEMIC PROFILE PIPELINE
// =========================================================================
export function transformLipidProfile(raw: LipidRaw): LipidMetrics {
  const { exam_date, total_cholesterol, hdl, ldl: ldl_reported, triglycerides } = raw;
  const qualityNotes: string[] = [];

  // Check completeness
  const is_complete = Boolean(
    total_cholesterol !== null &&
    hdl !== null &&
    triglycerides !== null
  );

  if (!is_complete) {
    qualityNotes.push('Missing essential core lipid fractions for Friedewald / AIP evaluation.');
  }

  // Friedewald Calculation: LDL = TC - HDL - (TG / 5) (valid when TG < 400 mg/dL)
  let ldl_calc: number | null = null;
  if (total_cholesterol !== null && hdl !== null && triglycerides !== null) {
    if (triglycerides < 400) {
      ldl_calc = round1(total_cholesterol - hdl - (triglycerides / 5));
    } else {
      qualityNotes.push('Triglycerides ≥ 400 mg/dL: Friedewald equation invalid, direct LDL measurement required.');
    }
  }

  // Determine LDL final & source
  let ldl_final: number | null = null;
  let ldl_source: 'reported' | 'calculated' | 'unavailable' = 'unavailable';

  if (ldl_reported !== null) {
    ldl_final = ldl_reported;
    ldl_source = 'reported';
  } else if (ldl_calc !== null) {
    ldl_final = ldl_calc;
    ldl_source = 'calculated';
  }

  // Non-HDL = TC - HDL
  const non_hdl_final = (total_cholesterol !== null && hdl !== null)
    ? round1(total_cholesterol - hdl)
    : null;

  // Remnant Cholesterol = TC - HDL - LDL_final
  const remnant_cholesterol = (total_cholesterol !== null && hdl !== null && ldl_final !== null)
    ? round1(total_cholesterol - hdl - ldl_final)
    : null;

  // Estimated VLDL = TG / 5
  const vldl_est = triglycerides !== null ? round1(triglycerides / 5) : null;

  // Ratios
  const chol_hdl_ratio = (total_cholesterol !== null && hdl !== null && hdl > 0)
    ? round2(total_cholesterol / hdl)
    : null;

  const trig_hdl_ratio = (triglycerides !== null && hdl !== null && hdl > 0)
    ? round2(triglycerides / hdl)
    : null;

  const ldl_hdl_ratio = (ldl_final !== null && hdl !== null && hdl > 0)
    ? round2(ldl_final / hdl)
    : null;

  // AIP = log10( (TG/88.57) / (HDL/38.67) )
  let aip: number | null = null;
  let risk_category: LipidMetrics['risk_category'] = 'Undetermined';

  if (triglycerides !== null && hdl !== null && hdl > 0 && triglycerides > 0) {
    const tg_mmol = triglycerides / 88.57;
    const hdl_mmol = hdl / 38.67;
    const ratio_molar = tg_mmol / hdl_mmol;
    aip = round2(Math.log10(ratio_molar));

    if (aip !== null) {
      if (aip < 0.11) {
        risk_category = 'Low / Optimal';
      } else if (aip <= 0.21) {
        risk_category = 'Intermediate Risk';
      } else {
        risk_category = 'High Atherogenic Risk';
      }
    }
  }

  return {
    exam_date,
    total_cholesterol,
    hdl,
    ldl_reported,
    ldl_calc,
    ldl_final,
    ldl_source,
    triglycerides,
    non_hdl_final,
    remnant_cholesterol,
    vldl_est,
    chol_hdl_ratio,
    trig_hdl_ratio,
    ldl_hdl_ratio,
    aip,
    risk_category,
    record_quality_note: qualityNotes.join(' '),
    is_complete,
  };
}

// =========================================================================
// 2. ENDOCRINOLOGY PROFILE PIPELINE
// =========================================================================
export function transformEndoProfile(raw: EndoRaw): EndoMetrics {
  const { exam_date, glucose_for_calc, fasting_insulin, hba1c, tsh, free_t4, vitamin_d } = raw;
  const qualityNotes: string[] = [];

  const is_complete = Boolean(glucose_for_calc !== null && fasting_insulin !== null && hba1c !== null);
  if (!is_complete) {
    qualityNotes.push('Partial endocrine record; either glucose, fasting insulin, or HbA1c omitted.');
  }

  // HOMA-IR = (Glucose * Insulin) / 405
  let homa_ir: number | null = null;
  let homa_ir_status: EndoMetrics['homa_ir_status'] = 'Unavailable';

  if (glucose_for_calc !== null && fasting_insulin !== null && glucose_for_calc > 0 && fasting_insulin > 0) {
    homa_ir = round2((glucose_for_calc * fasting_insulin) / 405);
    if (homa_ir !== null) {
      if (homa_ir < 1.0) homa_ir_status = 'Optimal Sensitivity (<1.0)';
      else if (homa_ir < 2.0) homa_ir_status = 'Early Insulin Resistance (1.0-1.9)';
      else if (homa_ir < 2.9) homa_ir_status = 'Significant IR (2.0-2.8)';
      else homa_ir_status = 'Severe Insulin Resistance (≥2.9)';
    }
  }

  // QUICKI = 1 / (log10(glucose) + log10(insulin))
  let quicki: number | null = null;
  let quicki_status: EndoMetrics['quicki_status'] = 'Unavailable';

  if (glucose_for_calc !== null && fasting_insulin !== null && glucose_for_calc > 0 && fasting_insulin > 0) {
    const denom = Math.log10(glucose_for_calc) + Math.log10(fasting_insulin);
    if (denom > 0) {
      quicki = round2(1 / denom);
      if (quicki !== null) {
        if (quicki > 0.382) quicki_status = 'Normal Insulin Sensitivity (>0.382)';
        else if (quicki > 0.33) quicki_status = 'Moderate Resistance';
        else quicki_status = 'Marked Insulin Resistance (≤0.33)';
      }
    }
  }

  // Estimated Average Glucose (eAG) = 28.7 * HbA1c - 46.7
  let eag_mgdl: number | null = null;
  if (hba1c !== null && hba1c > 0) {
    eag_mgdl = round1(28.7 * hba1c - 46.7);
  }

  // TSH / Free T4 ratio
  let tsh_free_t4_ratio: number | null = null;
  if (tsh !== null && free_t4 !== null && free_t4 > 0) {
    tsh_free_t4_ratio = round2(tsh / free_t4);
  }

  // Vitamin D interpretation
  let vitamin_d_status: EndoMetrics['vitamin_d_status'] = 'Unavailable';
  if (vitamin_d !== null && vitamin_d !== undefined) {
    if (vitamin_d < 20) vitamin_d_status = 'Deficiency (<20)';
    else if (vitamin_d < 30) vitamin_d_status = 'Insufficiency (20-29)';
    else if (vitamin_d <= 100) vitamin_d_status = 'Optimal (30-60)';
    else vitamin_d_status = 'Excess (>100)';
  }

  return {
    exam_date,
    glucose: glucose_for_calc,
    fasting_insulin,
    hba1c,
    tsh,
    free_t4,
    vitamin_d: vitamin_d ?? null,
    homa_ir,
    homa_ir_status,
    quicki,
    quicki_status,
    eag_mgdl,
    tsh_free_t4_ratio,
    vitamin_d_status,
    record_quality_note: qualityNotes.join(' '),
    is_complete,
  };
}

// =========================================================================
// 3. CBC & HEMATOLOGY PROFILE PIPELINE
// =========================================================================
export function transformCBCProfile(raw: CBCRaw): CBCMetrics {
  const {
    exam_date,
    wbc,
    rbc,
    hemoglobin,
    hematocrit,
    platelets,
    mcv,
    mch,
    mchc,
    rdw,
    neutrophils_pct,
    lymphocytes_pct,
    monocytes_pct,
    eosinophils_pct,
    basophils_pct,
  } = raw;

  // NLR = Neutrophils % / Lymphocytes %
  let nlr: number | null = null;
  let nlr_status: CBCMetrics['nlr_status'] = 'Unavailable';

  if (neutrophils_pct !== null && lymphocytes_pct !== null && lymphocytes_pct > 0) {
    nlr = round2(neutrophils_pct / lymphocytes_pct);
    if (nlr !== null) {
      if (nlr < 2.0) nlr_status = 'Low / Normal (<2.0)';
      else if (nlr <= 3.0) nlr_status = 'Mild Immune Stress (2.0-3.0)';
      else nlr_status = 'Elevated Stress (>3.0)';
    }
  }

  // Anemia Classification
  let anemia_classification: CBCMetrics['anemia_classification'] = 'None / Normal RBC Indices';
  if (hemoglobin !== null) {
    if (hemoglobin < 13.0) {
      if (mcv !== null && mcv < 80) {
        anemia_classification = 'Microcytic (Iron/Thal concern)';
      } else if (mcv !== null && mcv > 100) {
        anemia_classification = 'Macrocytic (B12/Folate concern)';
      } else {
        anemia_classification = 'Normocytic Anemia';
      }
    } else if (hemoglobin > 17.5) {
      anemia_classification = 'High Hemoglobin / Polycythemia';
    }
  }

  return {
    exam_date,
    wbc,
    rbc,
    hemoglobin,
    hematocrit,
    platelets,
    mcv,
    mch,
    mchc,
    rdw,
    neutrophils_pct,
    lymphocytes_pct,
    monocytes_pct,
    eosinophils_pct,
    basophils_pct,
    nlr,
    nlr_status,
    anemia_classification,
    record_quality_note: '',
  };
}

// =========================================================================
// 4. LIVER & METABOLIC PROFILE PIPELINE
// =========================================================================
export function transformLiverProfile(raw: LiverRaw): LiverMetrics {
  const {
    exam_date,
    alt,
    ast,
    alp,
    ggt,
    total_bilirubin,
    direct_bilirubin,
    albumin,
    total_protein,
  } = raw;

  // De Ritis Ratio = AST / ALT
  let de_ritis_ratio: number | null = null;
  let de_ritis_status: LiverMetrics['de_ritis_status'] = 'Unavailable';

  if (ast !== null && alt !== null && alt > 0) {
    de_ritis_ratio = round2(ast / alt);
    if (de_ritis_ratio !== null) {
      if (de_ritis_ratio < 1.0) de_ritis_status = 'Normal / Metabolic pattern (<1.0)';
      else if (de_ritis_ratio <= 2.0) de_ritis_status = 'Intermediate / Active Injury (1.0-2.0)';
      else de_ritis_status = 'Marked Cirrhotic / Alcoholic Pattern (>2.0)';
    }
  }

  // Albumin to Globulin (A/G) ratio: Globulin = Total Protein - Albumin
  let ag_ratio: number | null = null;
  if (albumin !== null && total_protein !== null) {
    const globulin = total_protein - albumin;
    if (globulin > 0) {
      ag_ratio = round2(albumin / globulin);
    }
  }

  // Hepatic Stress Tier
  let liver_stress_tier: LiverMetrics['liver_stress_tier'] = 'Low / Normal';
  if ((alt !== null && alt > 80) || (ast !== null && ast > 80) || (ggt !== null && ggt > 100)) {
    liver_stress_tier = 'High / Severe Stress';
  } else if ((alt !== null && alt > 45) || (ast !== null && ast > 40) || (ggt !== null && ggt > 50)) {
    liver_stress_tier = 'Elevated Hepatic Stress';
  } else if ((alt !== null && alt > 28) || (ast !== null && ast > 30)) {
    liver_stress_tier = 'Mild Hepatic Inflammation';
  }

  return {
    exam_date,
    alt,
    ast,
    alp,
    ggt,
    total_bilirubin,
    direct_bilirubin,
    albumin,
    total_protein,
    de_ritis_ratio,
    de_ritis_status,
    ag_ratio,
    liver_stress_tier,
    record_quality_note: '',
  };
}

// =========================================================================
// 5. IRON & ANEMIA PROFILE PIPELINE
// =========================================================================
export function transformIronProfile(raw: IronRaw): IronMetrics {
  const { exam_date, serum_iron, ferritin, tibc, uibc } = raw;

  // Transferrin Saturation = (Serum Iron / TIBC) * 100
  let tsat: number | null = null;
  let tsat_status: IronMetrics['tsat_status'] = 'Unavailable';

  if (serum_iron !== null && tibc !== null && tibc > 0) {
    tsat = round1((serum_iron / tibc) * 100);
    if (tsat !== null) {
      if (tsat < 20) tsat_status = 'Deficiency (<20%)';
      else if (tsat <= 45) tsat_status = 'Normal Replete (20-45%)';
      else tsat_status = 'Iron Overload Warning (>45%)';
    }
  }

  // Classification
  let iron_status_classification: IronMetrics['iron_status_classification'] = 'Optimal';
  if (ferritin !== null && ferritin < 30) {
    iron_status_classification = 'Iron Deficiency without Anemia';
  } else if (tsat !== null && tsat < 18 && ferritin !== null && ferritin < 20) {
    iron_status_classification = 'Iron Deficiency Anemia';
  } else if ((ferritin !== null && ferritin > 350) || (tsat !== null && tsat > 50)) {
    iron_status_classification = 'Iron Overload / Hemochromatosis Concern';
  }

  return {
    exam_date,
    serum_iron,
    ferritin,
    tibc,
    uibc,
    tsat,
    tsat_status,
    iron_status_classification,
    record_quality_note: '',
  };
}

// =========================================================================
// 6. INFLAMMATION PROFILE PIPELINE
// =========================================================================
export function transformInflammationProfile(raw: InflammationRaw): InflammationMetrics {
  const { exam_date, hs_crp, esr, ferritin } = raw;

  let cvd_risk_tier: InflammationMetrics['cvd_risk_tier'] = 'Unavailable';
  if (hs_crp !== null) {
    if (hs_crp < 1.0) cvd_risk_tier = 'Low Risk (<1.0 mg/L)';
    else if (hs_crp <= 3.0) cvd_risk_tier = 'Average Risk (1.0-3.0 mg/L)';
    else if (hs_crp <= 10.0) cvd_risk_tier = 'High CVD Risk (>3.0 mg/L)';
    else cvd_risk_tier = 'Acute Phase / Active Infection (>10 mg/L)';
  }

  let chronic_inflammation_score: InflammationMetrics['chronic_inflammation_score'] = 'Low / Quiescent';
  if ((hs_crp !== null && hs_crp > 3.0) || (esr !== null && esr > 25)) {
    chronic_inflammation_score = 'Elevated Chronic Inflammation';
  } else if ((hs_crp !== null && hs_crp > 1.2) || (esr !== null && esr > 15)) {
    chronic_inflammation_score = 'Moderate Subclinical';
  }

  return {
    exam_date,
    hs_crp,
    esr,
    ferritin,
    cvd_risk_tier,
    chronic_inflammation_score,
    record_quality_note: '',
  };
}

// =========================================================================
// 7. VITAMINS PROFILE PIPELINE
// =========================================================================
export function transformVitaminsProfile(raw: VitaminsRaw): VitaminsMetrics {
  const { exam_date, vitamin_b12, folate, vitamin_d, magnesium, zinc, calcium } = raw;

  let b12_status: VitaminsMetrics['b12_status'] = 'Unavailable';
  if (vitamin_b12 !== null) {
    if (vitamin_b12 < 200) b12_status = 'Deficient (<200)';
    else if (vitamin_b12 <= 350) b12_status = 'Borderline (200-300)';
    else if (vitamin_b12 <= 950) b12_status = 'Optimal (300-900)';
    else b12_status = 'Elevated (>900)';
  }

  let folate_status: VitaminsMetrics['folate_status'] = 'Unavailable';
  if (folate !== null) {
    folate_status = folate < 4.0 ? 'Deficient (<4.0)' : 'Optimal (≥4.0)';
  }

  let vitamin_d_status = 'Unavailable';
  if (vitamin_d !== null) {
    if (vitamin_d < 20) vitamin_d_status = 'Deficient (<20)';
    else if (vitamin_d < 30) vitamin_d_status = 'Insufficient (20-30)';
    else vitamin_d_status = 'Optimal (30-60)';
  }

  let magnesium_status: VitaminsMetrics['magnesium_status'] = 'Unavailable';
  if (magnesium !== null) {
    magnesium_status = magnesium < 1.8 ? 'Deficient (<1.8)' : 'Optimal (2.0-2.6)';
  }

  return {
    exam_date,
    vitamin_b12,
    folate,
    vitamin_d,
    magnesium,
    zinc,
    calcium,
    b12_status,
    folate_status,
    vitamin_d_status,
    magnesium_status,
    record_quality_note: '',
  };
}

// =========================================================================
// LONGITUDINAL TRAJECTORY & DELTA CALCULATION
// =========================================================================
export function computeLongitudinalVelocities<T extends { exam_date: string }>(
  items: T[],
  keyExtractor: (item: T) => number | null
): Array<{
  item: T;
  prior: number | null;
  delta: number | null;
  pctChange: number | null;
  rolling3: number | null;
}> {
  // Sort chronologically
  const sorted = [...items].sort((a, b) => new Date(a.exam_date).getTime() - new Date(b.exam_date).getTime());

  return sorted.map((current, idx) => {
    const val = keyExtractor(current);
    if (val === null) {
      return { item: current, prior: null, delta: null, pctChange: null, rolling3: null };
    }

    const priorVal = idx > 0 ? keyExtractor(sorted[idx - 1]) : null;
    let delta: number | null = null;
    let pctChange: number | null = null;

    if (priorVal !== null && priorVal !== undefined) {
      delta = round2(val - priorVal);
      if (priorVal !== 0) {
        pctChange = round1(((val - priorVal) / Math.abs(priorVal)) * 100);
      }
    }

    // Rolling 3
    const windowVals: number[] = [];
    for (let k = Math.max(0, idx - 2); k <= idx; k++) {
      const v = keyExtractor(sorted[k]);
      if (v !== null) windowVals.push(v);
    }
    const rolling3 = windowVals.length > 0
      ? round2(windowVals.reduce((acc, curr) => acc + curr, 0) / windowVals.length)
      : null;

    return {
      item: current,
      prior: priorVal,
      delta,
      pctChange,
      rolling3,
    };
  });
}
