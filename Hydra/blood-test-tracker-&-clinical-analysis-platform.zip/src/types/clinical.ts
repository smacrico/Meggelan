/**
 * Clinical Blood Analysis & Laboratory Data Models
 * Reflects profile ETL architecture and legacy database compatibility.
 */

export type SeverityLevel = 'optimal' | 'normal' | 'borderline' | 'abnormal_low' | 'abnormal_high' | 'critical';

export interface BiomarkerRefRange {
  low: number;
  high: number;
  optimalLow?: number;
  optimalHigh?: number;
  unit: string;
  criticalLow?: number;
  criticalHigh?: number;
}

export interface BiomarkerDefinition {
  code: string;
  name: string;
  shortName: string;
  category: 'lipid' | 'endocrine' | 'cbc' | 'liver' | 'iron' | 'inflammation' | 'vitamins' | 'general';
  standardUnit: string;
  refRange: BiomarkerRefRange;
  description: string;
  clinicalSignificance: string;
  aliases: string[];
}

export interface PatientRecord {
  id: string;
  name: string;
  gender: 'male' | 'female';
  age: number;
  birthDate: string;
  notes: string;
}

// =================== PROFILE 1: LIPIDEMIC ===================
export interface LipidRaw {
  exam_date: string;
  total_cholesterol: number | null;
  hdl: number | null;
  ldl: number | null; // reported
  triglycerides: number | null;
  non_hdl?: number | null;
  lpa?: number | null;
}

export interface LipidMetrics {
  metric_id?: number;
  exam_date: string;
  total_cholesterol: number | null;
  hdl: number | null;
  ldl_reported: number | null;
  ldl_calc: number | null;
  ldl_final: number | null;
  ldl_source: 'reported' | 'calculated' | 'unavailable';
  triglycerides: number | null;
  non_hdl_final: number | null;
  remnant_cholesterol: number | null;
  vldl_est: number | null;
  chol_hdl_ratio: number | null;
  trig_hdl_ratio: number | null;
  ldl_hdl_ratio: number | null;
  aip: number | null; // Atherogenic Index of Plasma
  risk_category: 'Low / Optimal' | 'Intermediate Risk' | 'High Atherogenic Risk' | 'Undetermined';
  
  // Longitudinal velocity
  prior_total_cholesterol?: number | null;
  delta_total_cholesterol?: number | null;
  pct_change_total_cholesterol?: number | null;
  rolling_three_total_cholesterol?: number | null;

  prior_ldl_final?: number | null;
  delta_ldl_final?: number | null;
  pct_change_ldl_final?: number | null;
  rolling_three_ldl_final?: number | null;

  record_quality_note: string;
  is_complete: boolean;
}

// =================== PROFILE 2: ENDOCRINOLOGY ===================
export interface EndoRaw {
  exam_date: string;
  glucose_for_calc: number | null; // mg/dL
  fasting_insulin: number | null; // uIU/mL
  hba1c: number | null; // %
  tsh: number | null; // uIU/mL
  free_t4: number | null; // ng/dL
  vitamin_d?: number | null; // ng/mL
}

export interface EndoMetrics {
  exam_date: string;
  glucose: number | null;
  fasting_insulin: number | null;
  hba1c: number | null;
  tsh: number | null;
  free_t4: number | null;
  vitamin_d: number | null;

  homa_ir: number | null;
  homa_ir_status: 'Optimal Sensitivity (<1.0)' | 'Early Insulin Resistance (1.0-1.9)' | 'Significant IR (2.0-2.8)' | 'Severe Insulin Resistance (≥2.9)' | 'Unavailable';
  quicki: number | null;
  quicki_status: 'Normal Insulin Sensitivity (>0.382)' | 'Moderate Resistance' | 'Marked Insulin Resistance (≤0.33)' | 'Unavailable';
  eag_mgdl: number | null; // Estimated Average Glucose
  tsh_free_t4_ratio: number | null;
  vitamin_d_status: 'Deficiency (<20)' | 'Insufficiency (20-29)' | 'Optimal (30-60)' | 'Excess (>100)' | 'Unavailable';

  prior_glucose?: number | null;
  delta_glucose?: number | null;
  rolling_three_glucose?: number | null;

  prior_hba1c?: number | null;
  delta_hba1c?: number | null;

  record_quality_note: string;
  is_complete: boolean;
}

// =================== PROFILE 3: CBC & HEMATOLOGY ===================
export interface CBCRaw {
  exam_date: string;
  wbc: number | null; // K/uL
  rbc: number | null; // M/uL
  hemoglobin: number | null; // g/dL
  hematocrit: number | null; // %
  platelets: number | null; // K/uL
  mcv: number | null; // fL
  mch: number | null; // pg
  mchc: number | null; // g/dL
  rdw: number | null; // %
  neutrophils_pct: number | null;
  lymphocytes_pct: number | null;
  monocytes_pct: number | null;
  eosinophils_pct: number | null;
  basophils_pct: number | null;
}

export interface CBCMetrics {
  exam_date: string;
  wbc: number | null;
  rbc: number | null;
  hemoglobin: number | null;
  hematocrit: number | null;
  platelets: number | null;
  mcv: number | null;
  mch: number | null;
  mchc: number | null;
  rdw: number | null;
  neutrophils_pct: number | null;
  lymphocytes_pct: number | null;
  monocytes_pct: number | null;
  eosinophils_pct: number | null;
  basophils_pct: number | null;

  nlr: number | null; // Neutrophil to Lymphocyte ratio
  nlr_status: 'Low / Normal (<2.0)' | 'Mild Immune Stress (2.0-3.0)' | 'Elevated Stress (>3.0)' | 'Unavailable';
  anemia_classification: 'None / Normal RBC Indices' | 'Microcytic (Iron/Thal concern)' | 'Macrocytic (B12/Folate concern)' | 'Normocytic Anemia' | 'High Hemoglobin / Polycythemia' | 'Undetermined';
  record_quality_note: string;
}

// =================== PROFILE 4: LIVER & METABOLIC ===================
export interface LiverRaw {
  exam_date: string;
  alt: number | null; // U/L
  ast: number | null; // U/L
  alp: number | null; // U/L
  ggt: number | null; // U/L
  total_bilirubin: number | null; // mg/dL
  direct_bilirubin: number | null; // mg/dL
  albumin: number | null; // g/dL
  total_protein: number | null; // g/dL
}

export interface LiverMetrics {
  exam_date: string;
  alt: number | null;
  ast: number | null;
  alp: number | null;
  ggt: number | null;
  total_bilirubin: number | null;
  direct_bilirubin: number | null;
  albumin: number | null;
  total_protein: number | null;

  de_ritis_ratio: number | null; // AST / ALT
  de_ritis_status: 'Normal / Metabolic pattern (<1.0)' | 'Intermediate / Active Injury (1.0-2.0)' | 'Marked Cirrhotic / Alcoholic Pattern (>2.0)' | 'Unavailable';
  ag_ratio: number | null; // Albumin to Globulin ratio
  liver_stress_tier: 'Low / Normal' | 'Mild Hepatic Inflammation' | 'Elevated Hepatic Stress' | 'High / Severe Stress';
  record_quality_note: string;
}

// =================== PROFILE 5: IRON & ANEMIA ===================
export interface IronRaw {
  exam_date: string;
  serum_iron: number | null; // ug/dL
  ferritin: number | null; // ng/mL
  tibc: number | null; // ug/dL
  uibc: number | null; // ug/dL
}

export interface IronMetrics {
  exam_date: string;
  serum_iron: number | null;
  ferritin: number | null;
  tibc: number | null;
  uibc: number | null;
  tsat: number | null; // % saturation
  tsat_status: 'Deficiency (<20%)' | 'Normal Replete (20-45%)' | 'Iron Overload Warning (>45%)' | 'Unavailable';
  iron_status_classification: 'Optimal' | 'Iron Deficiency without Anemia' | 'Iron Deficiency Anemia' | 'Iron Overload / Hemochromatosis Concern' | 'Undetermined';
  record_quality_note: string;
}

// =================== PROFILE 6: INFLAMMATION & IMMUNE ===================
export interface InflammationRaw {
  exam_date: string;
  hs_crp: number | null; // mg/L
  esr: number | null; // mm/hr
  ferritin: number | null;
}

export interface InflammationMetrics {
  exam_date: string;
  hs_crp: number | null;
  esr: number | null;
  ferritin: number | null;
  cvd_risk_tier: 'Low Risk (<1.0 mg/L)' | 'Average Risk (1.0-3.0 mg/L)' | 'High CVD Risk (>3.0 mg/L)' | 'Acute Phase / Active Infection (>10 mg/L)' | 'Unavailable';
  chronic_inflammation_score: 'Low / Quiescent' | 'Moderate Subclinical' | 'Elevated Chronic Inflammation';
  record_quality_note: string;
}

// =================== PROFILE 7: VITAMINS & NUTRITIONAL ===================
export interface VitaminsRaw {
  exam_date: string;
  vitamin_b12: number | null; // pg/mL
  folate: number | null; // ng/mL
  vitamin_d: number | null; // ng/mL
  magnesium: number | null; // mg/dL
  zinc: number | null; // ug/dL
  calcium: number | null; // mg/dL
}

export interface VitaminsMetrics {
  exam_date: string;
  vitamin_b12: number | null;
  folate: number | null;
  vitamin_d: number | null;
  magnesium: number | null;
  zinc: number | null;
  calcium: number | null;
  b12_status: 'Deficient (<200)' | 'Borderline (200-300)' | 'Optimal (300-900)' | 'Elevated (>900)' | 'Unavailable';
  folate_status: 'Deficient (<4.0)' | 'Optimal (≥4.0)' | 'Unavailable';
  vitamin_d_status: string;
  magnesium_status: 'Deficient (<1.8)' | 'Optimal (2.0-2.6)' | 'Unavailable';
  record_quality_note: string;
}

// =================== UNIFIED EXAM RECORD ===================
export interface ExamRecord {
  id: string;
  patientId: string;
  examDate: string;
  labFacility: string;
  orderingPhysician?: string;
  sourceType: 'manual' | 'pdf' | 'csv' | 'legacy_import';
  sourceFile?: string;
  notes?: string;

  // Raw tables
  lipidRaw: LipidRaw;
  endoRaw: EndoRaw;
  cbcRaw: CBCRaw;
  liverRaw: LiverRaw;
  ironRaw: IronRaw;
  inflammationRaw: InflammationRaw;
  vitaminsRaw: VitaminsRaw;

  // Derived metrics calculated by ETL pipelines
  lipidMetrics?: LipidMetrics;
  endoMetrics?: EndoMetrics;
  cbcMetrics?: CBCMetrics;
  liverMetrics?: LiverMetrics;
  ironMetrics?: IronMetrics;
  inflammationMetrics?: InflammationMetrics;
  vitaminsMetrics?: VitaminsMetrics;

  // All extracted test entries (legacy compatibility table)
  rawTestEntries: LegacyTestResult[];
}

// Legacy schema records (for 100% architectural bridge compatibility)
export interface LegacyTestResult {
  result_id: string;
  patient_name: string;
  test_date: string;
  test_name: string;
  result_value: string;
  numeric_value: number | null;
  unit: string;
  reference_range: string;
  flag: 'Normal' | 'High' | 'Low' | 'Critical' | '';
  category_code: string;
  pdf_filename?: string;
}

export interface ClinicalAbnormalAlert {
  markerName: string;
  category: string;
  value: number;
  unit: string;
  refRange: string;
  flag: 'High' | 'Low' | 'Critical';
  severity: SeverityLevel;
  interpretation: string;
}
