import React, { useState } from 'react';
import { ExamRecord } from '../types/clinical';
import { VisualizerChart } from './VisualizerChart';
import { round2 } from '../lib/clinicalCalculations';
import { ShieldCheck, AlertTriangle, Info, CheckCircle2 } from 'lucide-react';

interface ProfileLipidProps {
  currentExam: ExamRecord;
  allExams: ExamRecord[];
  patientId: string;
}

export const ProfileLipid: React.FC<ProfileLipidProps> = ({
  currentExam,
  allExams,
  patientId,
}) => {
  const [activeSeries, setActiveSeries] = useState('ldl');
  const metrics = currentExam.lipidMetrics;

  const patientExamsSorted = [...allExams]
    .filter((e) => e.patientId === patientId)
    .sort((a, b) => new Date(a.examDate).getTime() - new Date(b.examDate).getTime());

  // Chart series definitions
  const chartSeries = [
    {
      id: 'ldl',
      label: 'LDL-C Final',
      color: '#DC2626',
      unit: 'mg/dL',
      data: patientExamsSorted.map((e) => ({
        date: e.examDate,
        value: e.lipidMetrics?.ldl_final ?? null,
      })),
      refHigh: 100,
      optimalHigh: 70,
    },
    {
      id: 'tc',
      label: 'Total Cholesterol',
      color: '#4F46E5',
      unit: 'mg/dL',
      data: patientExamsSorted.map((e) => ({
        date: e.examDate,
        value: e.lipidMetrics?.total_cholesterol ?? null,
      })),
      refHigh: 200,
      optimalHigh: 180,
    },
    {
      id: 'hdl',
      label: 'HDL-C',
      color: '#059669',
      unit: 'mg/dL',
      data: patientExamsSorted.map((e) => ({
        date: e.examDate,
        value: e.lipidMetrics?.hdl ?? null,
      })),
      refLow: 40,
      optimalLow: 50,
    },
    {
      id: 'tg',
      label: 'Triglycerides',
      color: '#D97706',
      unit: 'mg/dL',
      data: patientExamsSorted.map((e) => ({
        date: e.examDate,
        value: e.lipidMetrics?.triglycerides ?? null,
      })),
      refHigh: 150,
      optimalHigh: 100,
    },
    {
      id: 'nonhdl',
      label: 'Non-HDL',
      color: '#7C3AED',
      unit: 'mg/dL',
      data: patientExamsSorted.map((e) => ({
        date: e.examDate,
        value: e.lipidMetrics?.non_hdl_final ?? null,
      })),
      refHigh: 130,
      optimalHigh: 100,
    },
    {
      id: 'aip',
      label: 'AIP Index',
      color: '#EA580C',
      unit: 'index',
      data: patientExamsSorted.map((e) => ({
        date: e.examDate,
        value: e.lipidMetrics?.aip ?? null,
      })),
      refHigh: 0.21,
      optimalHigh: 0.11,
    },
  ];

  return (
    <div className="space-y-6">
      {/* Risk Banner & Status */}
      <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="font-mono text-xs uppercase tracking-wider text-slate-400">
              Profile Pipeline: Lipidemic
            </span>
            <span className="inline-flex items-center gap-1 rounded bg-slate-100 px-2 py-0.5 text-[11px] font-medium text-slate-700">
              Exam: {currentExam.examDate}
            </span>
          </div>
          <h2 className="mt-1 text-lg font-bold tracking-tight text-slate-900">
            Atherogenic Risk Tier: {metrics?.risk_category}
          </h2>
          <p className="text-xs text-slate-500">
            AIP computed as log₁₀((TG / 88.57) / (HDL / 38.67)). Evaluates particle size distribution and atherogenicity.
          </p>
        </div>

        <div className="flex items-center gap-6">
          <div className="text-right">
            <div className="text-[10px] font-medium uppercase text-slate-400">AIP Index</div>
            <div className="font-mono text-2xl font-bold text-slate-900 tabular-nums">
              {metrics?.aip !== null ? metrics?.aip : '—'}
            </div>
          </div>
          <div className="text-right">
            <div className="text-[10px] font-medium uppercase text-slate-400">Trig / HDL Ratio</div>
            <div className="font-mono text-2xl font-bold text-slate-900 tabular-nums">
              {metrics?.trig_hdl_ratio !== null ? metrics?.trig_hdl_ratio : '—'}
            </div>
          </div>
        </div>
      </div>

      {/* Primary Lipid Metrics Grid */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
        <div className="rounded-xl border border-slate-200 bg-white p-3.5">
          <div className="text-[11px] font-medium text-slate-500">Total Cholesterol</div>
          <div className="mt-1 font-mono text-xl font-bold text-slate-900 tabular-nums">
            {metrics?.total_cholesterol ?? '—'}
          </div>
          <div className="mt-1 text-[10px] text-slate-400">Ref: 125–200 mg/dL</div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-3.5">
          <div className="text-[11px] font-medium text-slate-500">HDL Cholesterol</div>
          <div className="mt-1 font-mono text-xl font-bold text-slate-900 tabular-nums">
            {metrics?.hdl ?? '—'}
          </div>
          <div className="mt-1 text-[10px] text-slate-400">Ref: 40–90 mg/dL</div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-3.5">
          <div className="text-[11px] font-medium text-slate-500">
            LDL Final ({metrics?.ldl_source})
          </div>
          <div className="mt-1 font-mono text-xl font-bold text-slate-900 tabular-nums">
            {metrics?.ldl_final ?? '—'}
          </div>
          <div className="mt-1 text-[10px] text-slate-400">
            Calc: {metrics?.ldl_calc ?? '—'} mg/dL
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-3.5">
          <div className="text-[11px] font-medium text-slate-500">Triglycerides</div>
          <div className="mt-1 font-mono text-xl font-bold text-slate-900 tabular-nums">
            {metrics?.triglycerides ?? '—'}
          </div>
          <div className="mt-1 text-[10px] text-slate-400">Ref: 40–150 mg/dL</div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-3.5">
          <div className="text-[11px] font-medium text-slate-500">Non-HDL Cholesterol</div>
          <div className="mt-1 font-mono text-xl font-bold text-slate-900 tabular-nums">
            {metrics?.non_hdl_final ?? '—'}
          </div>
          <div className="mt-1 text-[10px] text-slate-400">Target: &lt; 130 mg/dL</div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-3.5">
          <div className="text-[11px] font-medium text-slate-500">Remnant Cholesterol</div>
          <div className="mt-1 font-mono text-xl font-bold text-slate-900 tabular-nums">
            {metrics?.remnant_cholesterol ?? '—'}
          </div>
          <div className="mt-1 text-[10px] text-slate-400">Optimal: &lt; 24 mg/dL</div>
        </div>
      </div>

      {/* Main Longitudinal Trend Visualizer */}
      <VisualizerChart
        title="Lipid Profile Longitudinal Trajectory"
        subtitle="Tracking atherogenic particles, cardioprotective HDL, and calculated clinical ratios"
        series={chartSeries}
        activeSeriesId={activeSeries}
        onSelectSeries={setActiveSeries}
        height={320}
      />

      {/* Deep-Dive Formulas & Interpretation Table */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Derived Calculations Summary */}
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
          <h3 className="text-sm font-semibold text-slate-900">
            Derived Clinical Indices & Equations
          </h3>
          <div className="mt-4 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2 text-xs">
              <span className="text-slate-600">Total / HDL Ratio</span>
              <div className="text-right">
                <span className="font-mono font-bold text-slate-900 tabular-nums">
                  {metrics?.chol_hdl_ratio ?? '—'}
                </span>
                <span className="ml-2 text-slate-400">(Ideal: &lt; 3.5)</span>
              </div>
            </div>

            <div className="flex items-center justify-between border-b border-slate-100 pb-2 text-xs">
              <span className="text-slate-600">Triglycerides / HDL Ratio</span>
              <div className="text-right">
                <span className="font-mono font-bold text-slate-900 tabular-nums">
                  {metrics?.trig_hdl_ratio ?? '—'}
                </span>
                <span className="ml-2 text-slate-400">(Ideal: &lt; 2.0; surrogate for small dense LDL)</span>
              </div>
            </div>

            <div className="flex items-center justify-between border-b border-slate-100 pb-2 text-xs">
              <span className="text-slate-600">LDL / HDL Ratio</span>
              <div className="text-right">
                <span className="font-mono font-bold text-slate-900 tabular-nums">
                  {metrics?.ldl_hdl_ratio ?? '—'}
                </span>
                <span className="ml-2 text-slate-400">(Ideal: &lt; 2.5)</span>
              </div>
            </div>

            <div className="flex items-center justify-between border-b border-slate-100 pb-2 text-xs">
              <span className="text-slate-600">Estimated VLDL (TG / 5)</span>
              <div className="text-right">
                <span className="font-mono font-bold text-slate-900 tabular-nums">
                  {metrics?.vldl_est ?? '—'} mg/dL
                </span>
                <span className="ml-2 text-slate-400">(Ref: 5–30 mg/dL)</span>
              </div>
            </div>

            <div className="flex items-center justify-between text-xs pt-1">
              <span className="text-slate-600">Friedewald Validation</span>
              <div className="flex items-center gap-1.5 text-emerald-700 font-medium">
                <CheckCircle2 className="h-3.5 w-3.5" />
                <span>
                  {metrics?.triglycerides && metrics.triglycerides < 400
                    ? 'Valid (TG < 400 mg/dL)'
                    : 'Requires Direct LDL'}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Quality Audit & Longitudinal History */}
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
          <h3 className="text-sm font-semibold text-slate-900">
            Longitudinal Velocity & Data Quality
          </h3>
          <div className="mt-4 space-y-3">
            <div className="rounded-lg border border-slate-100 bg-slate-50 p-3 text-xs">
              <div className="font-medium text-slate-800">Quality Note:</div>
              <div className="mt-0.5 text-slate-600">
                {metrics?.record_quality_note || 'Complete panel: all primary parameters verified for Friedewald and AIP index generation.'}
              </div>
            </div>

            <div className="mt-3">
              <div className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">
                Exam History ({patientExamsSorted.length} records)
              </div>
              <div className="mt-2 divide-y divide-slate-100 max-h-40 overflow-y-auto">
                {patientExamsSorted.map((e) => (
                  <div key={e.id} className="flex items-center justify-between py-1.5 text-xs">
                    <span className="font-mono text-slate-600 tabular-nums">{e.examDate}</span>
                    <div className="flex items-center gap-3">
                      <span>LDL: <strong className="font-mono text-slate-800">{e.lipidMetrics?.ldl_final ?? '—'}</strong></span>
                      <span>HDL: <strong className="font-mono text-slate-800">{e.lipidMetrics?.hdl ?? '—'}</strong></span>
                      <span>TG: <strong className="font-mono text-slate-800">{e.lipidMetrics?.triglycerides ?? '—'}</strong></span>
                      <span className="rounded bg-slate-100 px-1.5 py-0.5 text-[10px] font-medium text-slate-700">
                        AIP: {e.lipidMetrics?.aip ?? '—'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
