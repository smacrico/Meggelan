import React, { useState } from 'react';
import { ExamRecord } from '../types/clinical';
import { VisualizerChart } from './VisualizerChart';

interface ProfileLiverIronProps {
  currentExam: ExamRecord;
  allExams: ExamRecord[];
  patientId: string;
}

export const ProfileLiverIron: React.FC<ProfileLiverIronProps> = ({
  currentExam,
  allExams,
  patientId,
}) => {
  const [activeSeries, setActiveSeries] = useState('alt');
  const liver = currentExam.liverMetrics;
  const iron = currentExam.ironMetrics;
  const inflammation = currentExam.inflammationMetrics;
  const vitamins = currentExam.vitaminsMetrics;

  const patientExamsSorted = [...allExams]
    .filter((e) => e.patientId === patientId)
    .sort((a, b) => new Date(a.examDate).getTime() - new Date(b.examDate).getTime());

  const chartSeries = [
    {
      id: 'alt',
      label: 'ALT (SGPT)',
      color: '#DC2626',
      unit: 'U/L',
      data: patientExamsSorted.map((e) => ({
        date: e.examDate,
        value: e.liverMetrics?.alt ?? null,
      })),
      refHigh: 45,
      optimalHigh: 26,
    },
    {
      id: 'ast',
      label: 'AST (SGOT)',
      color: '#D97706',
      unit: 'U/L',
      data: patientExamsSorted.map((e) => ({
        date: e.examDate,
        value: e.liverMetrics?.ast ?? null,
      })),
      refHigh: 40,
      optimalHigh: 28,
    },
    {
      id: 'deritis',
      label: 'De Ritis (AST/ALT)',
      color: '#7C3AED',
      unit: 'ratio',
      data: patientExamsSorted.map((e) => ({
        date: e.examDate,
        value: e.liverMetrics?.de_ritis_ratio ?? null,
      })),
      refHigh: 2.0,
      optimalHigh: 1.0,
    },
    {
      id: 'ferritin',
      label: 'Ferritin',
      color: '#2563EB',
      unit: 'ng/mL',
      data: patientExamsSorted.map((e) => ({
        date: e.examDate,
        value: e.ironMetrics?.ferritin ?? null,
      })),
      refLow: 30,
      refHigh: 300,
      optimalLow: 50,
      optimalHigh: 150,
    },
    {
      id: 'tsat',
      label: 'TSAT (%)',
      color: '#059669',
      unit: '%',
      data: patientExamsSorted.map((e) => ({
        date: e.examDate,
        value: e.ironMetrics?.tsat ?? null,
      })),
      refLow: 20,
      refHigh: 45,
      optimalLow: 25,
      optimalHigh: 40,
    },
    {
      id: 'hscrp',
      label: 'hs-CRP',
      color: '#E11D48',
      unit: 'mg/L',
      data: patientExamsSorted.map((e) => ({
        date: e.examDate,
        value: e.inflammationMetrics?.hs_crp ?? null,
      })),
      refHigh: 3.0,
      optimalHigh: 0.8,
    },
  ];

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="font-mono text-xs uppercase tracking-wider text-slate-400">
              Profile Pipelines: Hepatic, Iron, & Systemic Inflammation
            </span>
            <span className="inline-flex items-center gap-1 rounded bg-slate-100 px-2 py-0.5 text-[11px] font-medium text-slate-700">
              Exam: {currentExam.examDate}
            </span>
          </div>
          <h2 className="mt-1 text-lg font-bold tracking-tight text-slate-900">
            Hepatic Classification: {liver?.liver_stress_tier}
          </h2>
          <p className="text-xs text-slate-500">
            De Ritis ratio (AST/ALT) {liver?.de_ritis_ratio} · TSAT {iron?.tsat}% ({iron?.tsat_status}) · hs-CRP {inflammation?.hs_crp} mg/L
          </p>
        </div>

        <div className="flex items-center gap-6">
          <div className="text-right">
            <div className="text-[10px] font-medium uppercase text-slate-400">De Ritis Ratio</div>
            <div className="font-mono text-2xl font-bold text-slate-900 tabular-nums">
              {liver?.de_ritis_ratio !== null ? liver?.de_ritis_ratio : '—'}
            </div>
            <div className="text-[11px] text-slate-500">AST / ALT</div>
          </div>
          <div className="text-right">
            <div className="text-[10px] font-medium uppercase text-slate-400">Transferrin Sat</div>
            <div className="font-mono text-2xl font-bold text-slate-900 tabular-nums">
              {iron?.tsat !== null ? `${iron?.tsat}%` : '—'}
            </div>
            <div className="text-[11px] text-slate-500">Iron / TIBC</div>
          </div>
        </div>
      </div>

      {/* Primary Metrics Grid */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
        <div className="rounded-xl border border-slate-200 bg-white p-3.5">
          <div className="text-[11px] font-medium text-slate-500">ALT (SGPT)</div>
          <div className="mt-1 font-mono text-xl font-bold text-slate-900 tabular-nums">
            {liver?.alt ?? '—'}
          </div>
          <div className="mt-1 text-[10px] text-slate-400">Ref: 7–45 U/L</div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-3.5">
          <div className="text-[11px] font-medium text-slate-500">AST (SGOT)</div>
          <div className="mt-1 font-mono text-xl font-bold text-slate-900 tabular-nums">
            {liver?.ast ?? '—'}
          </div>
          <div className="mt-1 text-[10px] text-slate-400">Ref: 8–40 U/L</div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-3.5">
          <div className="text-[11px] font-medium text-slate-500">GGT Enzyme</div>
          <div className="mt-1 font-mono text-xl font-bold text-slate-900 tabular-nums">
            {liver?.ggt ?? '—'}
          </div>
          <div className="mt-1 text-[10px] text-slate-400">Ref: 9–48 U/L</div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-3.5">
          <div className="text-[11px] font-medium text-slate-500">Ferritin (Stores)</div>
          <div className="mt-1 font-mono text-xl font-bold text-slate-900 tabular-nums">
            {iron?.ferritin ?? '—'}
          </div>
          <div className="mt-1 text-[10px] text-slate-400">Ref: 30–300 ng/mL</div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-3.5">
          <div className="text-[11px] font-medium text-slate-500">hs-CRP</div>
          <div className="mt-1 font-mono text-xl font-bold text-slate-900 tabular-nums">
            {inflammation?.hs_crp ?? '—'}
          </div>
          <div className="mt-1 text-[10px] text-slate-400">{inflammation?.cvd_risk_tier?.split(' ')[0]}</div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-3.5">
          <div className="text-[11px] font-medium text-slate-500">Vitamin B12</div>
          <div className="mt-1 font-mono text-xl font-bold text-slate-900 tabular-nums">
            {vitamins?.vitamin_b12 ?? '—'}
          </div>
          <div className="mt-1 text-[10px] text-slate-400">Ref: 200–1100 pg/mL</div>
        </div>
      </div>

      {/* Visualizer Chart */}
      <VisualizerChart
        title="Hepatic, Iron, & Inflammatory Trajectory"
        subtitle="Longitudinal progression of liver transaminases, ferritin stores, and cardiovascular inflammation"
        series={chartSeries}
        activeSeriesId={activeSeries}
        onSelectSeries={setActiveSeries}
        height={320}
      />

      {/* Diagnostic Panels & Tables */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Liver Panel Details */}
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
          <h3 className="text-sm font-semibold text-slate-900">Hepatic Synthetic Function</h3>
          <div className="mt-4 space-y-2.5">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2 text-xs">
              <span className="text-slate-600">Alkaline Phosphatase (ALP)</span>
              <span className="font-mono font-bold text-slate-900 tabular-nums">{liver?.alp ?? '—'} U/L</span>
            </div>
            <div className="flex items-center justify-between border-b border-slate-100 pb-2 text-xs">
              <span className="text-slate-600">Total Bilirubin</span>
              <span className="font-mono font-bold text-slate-900 tabular-nums">{liver?.total_bilirubin ?? '—'} mg/dL</span>
            </div>
            <div className="flex items-center justify-between border-b border-slate-100 pb-2 text-xs">
              <span className="text-slate-600">Serum Albumin</span>
              <span className="font-mono font-bold text-slate-900 tabular-nums">{liver?.albumin ?? '—'} g/dL</span>
            </div>
            <div className="flex items-center justify-between border-b border-slate-100 pb-2 text-xs">
              <span className="text-slate-600">Total Protein</span>
              <span className="font-mono font-bold text-slate-900 tabular-nums">{liver?.total_protein ?? '—'} g/dL</span>
            </div>
            <div className="flex items-center justify-between text-xs pt-1">
              <span className="text-slate-600">A / G Ratio</span>
              <span className="font-mono font-bold text-slate-900 tabular-nums">{liver?.ag_ratio ?? '—'}</span>
            </div>
          </div>
        </div>

        {/* Iron Panel Details */}
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
          <h3 className="text-sm font-semibold text-slate-900">Iron Kinetics & Capacity</h3>
          <div className="mt-4 space-y-2.5">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2 text-xs">
              <span className="text-slate-600">Serum Iron</span>
              <span className="font-mono font-bold text-slate-900 tabular-nums">{iron?.serum_iron ?? '—'} ug/dL</span>
            </div>
            <div className="flex items-center justify-between border-b border-slate-100 pb-2 text-xs">
              <span className="text-slate-600">Total Iron Binding (TIBC)</span>
              <span className="font-mono font-bold text-slate-900 tabular-nums">{iron?.tibc ?? '—'} ug/dL</span>
            </div>
            <div className="flex items-center justify-between border-b border-slate-100 pb-2 text-xs">
              <span className="text-slate-600">Transferrin Saturation (TSAT)</span>
              <span className="font-mono font-bold text-slate-900 tabular-nums">{iron?.tsat ?? '—'}%</span>
            </div>
            <div className="flex items-center justify-between border-b border-slate-100 pb-2 text-xs">
              <span className="text-slate-600">Ferritin Level</span>
              <span className="font-mono font-bold text-slate-900 tabular-nums">{iron?.ferritin ?? '—'} ng/mL</span>
            </div>
            <div className="flex items-center justify-between text-xs pt-1">
              <span className="text-slate-600">Clinical Staging</span>
              <span className="font-medium text-slate-900">{iron?.iron_status_classification}</span>
            </div>
          </div>
        </div>

        {/* Inflammation & Micronutrients */}
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
          <h3 className="text-sm font-semibold text-slate-900">Inflammation & Micronutrients</h3>
          <div className="mt-4 space-y-2.5">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2 text-xs">
              <span className="text-slate-600">hs-CRP</span>
              <span className="font-mono font-bold text-slate-900 tabular-nums">{inflammation?.hs_crp ?? '—'} mg/L</span>
            </div>
            <div className="flex items-center justify-between border-b border-slate-100 pb-2 text-xs">
              <span className="text-slate-600">Sedimentation Rate (ESR)</span>
              <span className="font-mono font-bold text-slate-900 tabular-nums">{inflammation?.esr ?? '—'} mm/hr</span>
            </div>
            <div className="flex items-center justify-between border-b border-slate-100 pb-2 text-xs">
              <span className="text-slate-600">Serum Magnesium</span>
              <span className="font-mono font-bold text-slate-900 tabular-nums">{vitamins?.magnesium ?? '—'} mg/dL</span>
            </div>
            <div className="flex items-center justify-between border-b border-slate-100 pb-2 text-xs">
              <span className="text-slate-600">Serum Calcium</span>
              <span className="font-mono font-bold text-slate-900 tabular-nums">{vitamins?.calcium ?? '—'} mg/dL</span>
            </div>
            <div className="flex items-center justify-between text-xs pt-1">
              <span className="text-slate-600">Chronic Burden Score</span>
              <span className="font-medium text-slate-900">{inflammation?.chronic_inflammation_score}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
