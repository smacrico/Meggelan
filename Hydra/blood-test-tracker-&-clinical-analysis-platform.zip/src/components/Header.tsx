import React from 'react';
import { UploadCloud } from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  onOpenIngestModal: () => void;
  onOpenAddModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onTabChange,
  onOpenIngestModal,
}) => {
  return (
    <header className="sticky top-0 z-30 flex items-center justify-between gap-8 border-b border-slate-200 bg-white/95 px-6 py-3.5 backdrop-blur-md">
      {/* Zone 1: Single text element wordmark */}
      <a
        href="#dashboard"
        onClick={(e) => {
          e.preventDefault();
          onTabChange('summary');
        }}
        className="text-base font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0 hover:text-blue-700 transition-colors"
      >
        BloodTest Analytics
      </a>

      {/* Zone 2: 4-5 clean single-line text navigation links */}
      <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
        <button
          onClick={() => onTabChange('summary')}
          className={`whitespace-nowrap shrink-0 pb-0.5 text-xs transition-colors ${
            activeTab === 'summary'
              ? 'text-slate-900 font-semibold border-b-2 border-slate-900'
              : 'hover:text-slate-900'
          }`}
        >
          Executive Summary
        </button>

        <button
          onClick={() => onTabChange('lipid')}
          className={`whitespace-nowrap shrink-0 pb-0.5 text-xs transition-colors ${
            activeTab === 'lipid'
              ? 'text-slate-900 font-semibold border-b-2 border-slate-900'
              : 'hover:text-slate-900'
          }`}
        >
          Lipidemic Profile
        </button>

        <button
          onClick={() => onTabChange('endo')}
          className={`whitespace-nowrap shrink-0 pb-0.5 text-xs transition-colors ${
            activeTab === 'endo'
              ? 'text-slate-900 font-semibold border-b-2 border-slate-900'
              : 'hover:text-slate-900'
          }`}
        >
          Endocrinology
        </button>

        <button
          onClick={() => onTabChange('cbc')}
          className={`whitespace-nowrap shrink-0 pb-0.5 text-xs transition-colors ${
            activeTab === 'cbc'
              ? 'text-slate-900 font-semibold border-b-2 border-slate-900'
              : 'hover:text-slate-900'
          }`}
        >
          CBC & Hematology
        </button>

        <button
          onClick={() => onTabChange('organs')}
          className={`whitespace-nowrap shrink-0 pb-0.5 text-xs transition-colors ${
            activeTab === 'organs'
              ? 'text-slate-900 font-semibold border-b-2 border-slate-900'
              : 'hover:text-slate-900'
          }`}
        >
          Liver & Iron
        </button>

        <button
          onClick={() => onTabChange('compare')}
          className={`whitespace-nowrap shrink-0 pb-0.5 text-xs transition-colors ${
            activeTab === 'compare'
              ? 'text-slate-900 font-semibold border-b-2 border-slate-900'
              : 'hover:text-slate-900'
          }`}
        >
          Exam Comparison
        </button>
      </nav>

      {/* Zone 3: 1 primary action */}
      <div className="flex items-center gap-3 shrink-0">
        <button
          onClick={onOpenIngestModal}
          className="flex items-center gap-2 rounded-lg bg-slate-900 px-3.5 py-2 text-xs font-medium text-white transition-colors hover:bg-slate-800 whitespace-nowrap shrink-0"
        >
          <UploadCloud className="h-3.5 w-3.5" />
          <span>Ingest Lab Report</span>
        </button>
      </div>
    </header>
  );
};
