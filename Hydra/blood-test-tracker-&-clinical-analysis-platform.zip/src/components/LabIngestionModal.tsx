import React, { useState } from 'react';
import { parseLabReportText } from '../lib/ingestionParser';
import { ExamRecord, PatientRecord } from '../types/clinical';
import { X, UploadCloud, CheckCircle2, AlertCircle, FileText } from 'lucide-react';

interface LabIngestionModalProps {
  isOpen: boolean;
  onClose: () => void;
  patients: PatientRecord[];
  activePatientId: string;
  onIngestSuccess: (newExam: ExamRecord) => void;
}

const SAMPLE_PRESET_QUEST = `QUEST DIAGNOSTICS LABORATORY REPORT
PATIENT: Marcus Vance
SPECIMEN DATE: 2026-09-15
ORDERING PHYSICIAN: Dr. Aris Thorne, MD

LIPID PANEL WITH CALCULATED LDL:
Cholesterol, Total: 158 mg/dL (Reference: 125-200)
HDL Cholesterol: 56 mg/dL (Reference: >40)
Triglycerides: 88 mg/dL (Reference: <150)
LDL-Cholesterol: 84 mg/dL (Reference: <100)

ENDOCRINE & METABOLIC:
Fasting Glucose: 84 mg/dL (Reference: 70-99)
Fasting Insulin: 4.2 uIU/mL (Reference: 2.0-19.6)
Hemoglobin A1c: 5.0 % (Reference: <5.7)
TSH, 3rd Generation: 1.65 uIU/mL (Reference: 0.45-4.5)
Free T4: 1.34 ng/dL (Reference: 0.82-1.77)
Vitamin D, 25-Hydroxy: 62 ng/mL (Reference: 30-100)

COMPREHENSIVE METABOLIC & LIVER:
ALT (SGPT): 18 U/L (Reference: 7-45)
AST (SGOT): 20 U/L (Reference: 8-40)
Alkaline Phosphatase: 56 U/L (Reference: 44-147)
Gamma-Glutamyl Transferase (GGT): 16 U/L (Reference: 9-48)
Total Bilirubin: 0.5 mg/dL (Reference: 0.2-1.2)
Albumin, Serum: 4.7 g/dL (Reference: 3.5-5.2)

INFLAMMATION & IRON:
hs-CRP: 0.4 mg/L (Reference: <1.0)
Ferritin: 118 ng/mL (Reference: 30-300)
Iron, Serum: 112 ug/dL (Reference: 60-170)
Total Iron Binding Capacity: 320 ug/dL (Reference: 250-450)
`;

const SAMPLE_PRESET_CSV = `# CSV Format Lab Ingestion
Total Cholesterol, 215, mg/dL
HDL, 44, mg/dL
Triglycerides, 185, mg/dL
LDL, 134, mg/dL
Fasting Glucose, 102, mg/dL
Insulin, 14.5, uIU/mL
HbA1c, 5.8, %
ALT, 42, U/L
AST, 34, U/L
hs-CRP, 2.8, mg/L
Ferritin, 240, ng/mL
WBC, 6.8, K/uL
Hemoglobin, 15.1, g/dL
`;

export const LabIngestionModal: React.FC<LabIngestionModalProps> = ({
  isOpen,
  onClose,
  patients,
  activePatientId,
  onIngestSuccess,
}) => {
  const [patientId, setPatientId] = useState(activePatientId);
  const [examDate, setExamDate] = useState('2026-09-15');
  const [labFacility, setLabFacility] = useState('Quest Diagnostics Metro Lab');
  const [rawText, setRawText] = useState(SAMPLE_PRESET_QUEST);
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const handleParseAndIngest = () => {
    setErrorMsg('');
    const result = parseLabReportText(rawText, {
      patientId,
      examDate,
      labFacility,
      sourceFile: 'Pasted_Lab_Report.txt',
    });

    if (!result.success || !result.examRecord) {
      setErrorMsg(result.warnings.join(' ') || 'Could not parse any valid biomarkers from text.');
      return;
    }

    onIngestSuccess(result.examRecord);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
      <div className="w-full max-w-2xl rounded-2xl border border-slate-200 bg-white p-6 shadow-xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="rounded-lg bg-blue-50 p-2 text-blue-700">
              <UploadCloud className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Smart Lab Report ETL & Ingestion Bridge
              </h3>
              <p className="text-xs text-slate-500">
                Bridges legacy PDF/text/CSV results into profile tables and automatically runs clinical pipelines.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-600 transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Configuration Bar */}
        <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-3">
          <div>
            <label className="text-[11px] font-medium uppercase tracking-wider text-slate-400">
              Assign to Patient
            </label>
            <select
              value={patientId}
              onChange={(e) => setPatientId(e.target.value)}
              className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs text-slate-800"
            >
              {patients.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} ({p.gender}, {p.age}y)
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[11px] font-medium uppercase tracking-wider text-slate-400">
              Exam Date
            </label>
            <input
              type="date"
              value={examDate}
              onChange={(e) => setExamDate(e.target.value)}
              className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 font-mono text-xs text-slate-800"
            />
          </div>

          <div>
            <label className="text-[11px] font-medium uppercase tracking-wider text-slate-400">
              Lab Facility
            </label>
            <input
              type="text"
              value={labFacility}
              onChange={(e) => setLabFacility(e.target.value)}
              className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs text-slate-800"
            />
          </div>
        </div>

        {/* Preset quick buttons */}
        <div className="mt-3 flex items-center gap-2 text-xs">
          <span className="text-slate-400">Quick Presets:</span>
          <button
            type="button"
            onClick={() => setRawText(SAMPLE_PRESET_QUEST)}
            className="rounded-md border border-slate-200 bg-slate-50 px-2 py-0.5 text-[11px] font-medium text-slate-700 hover:bg-slate-100"
          >
            Quest Full Panel (Text)
          </button>
          <button
            type="button"
            onClick={() => setRawText(SAMPLE_PRESET_CSV)}
            className="rounded-md border border-slate-200 bg-slate-50 px-2 py-0.5 text-[11px] font-medium text-slate-700 hover:bg-slate-100"
          >
            Metabolic Panel (CSV)
          </button>
        </div>

        {/* Raw Text Box */}
        <div className="mt-3">
          <label className="text-[11px] font-medium uppercase tracking-wider text-slate-400">
            Paste Lab Results Text, OCR Output, or CSV
          </label>
          <textarea
            rows={9}
            value={rawText}
            onChange={(e) => setRawText(e.target.value)}
            className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-3 font-mono text-xs text-slate-800 focus:bg-white focus:outline-hidden"
            placeholder="Paste text from lab report PDF or raw tabular CSV..."
          />
        </div>

        {/* Error message if any */}
        {errorMsg && (
          <div className="mt-3 flex items-center gap-2 rounded-lg bg-rose-50 p-2.5 text-xs text-rose-700">
            <AlertCircle className="h-4 w-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Actions */}
        <div className="mt-5 flex items-center justify-end gap-3 border-t border-slate-100 pt-4">
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg border border-slate-200 px-4 py-2 text-xs font-medium text-slate-600 hover:bg-slate-50 transition-colors"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleParseAndIngest}
            className="flex items-center gap-2 rounded-lg bg-slate-900 px-4 py-2 text-xs font-medium text-white hover:bg-slate-800 transition-colors"
          >
            <CheckCircle2 className="h-3.5 w-3.5" />
            <span>Run ETL & Ingest into Platform</span>
          </button>
        </div>
      </div>
    </div>
  );
};
