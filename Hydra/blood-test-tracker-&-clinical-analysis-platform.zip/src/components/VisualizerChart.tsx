import React, { useState } from 'react';
import { round2 } from '../lib/clinicalCalculations';

export interface ChartSeries {
  id: string;
  label: string;
  color: string;
  unit: string;
  data: Array<{
    date: string;
    value: number | null;
  }>;
  refLow?: number;
  refHigh?: number;
  optimalLow?: number;
  optimalHigh?: number;
}

interface VisualizerChartProps {
  title: string;
  subtitle?: string;
  series: ChartSeries[];
  activeSeriesId?: string;
  onSelectSeries?: (id: string) => void;
  height?: number;
}

export const VisualizerChart: React.FC<VisualizerChartProps> = ({
  title,
  subtitle,
  series,
  activeSeriesId,
  onSelectSeries,
  height = 280,
}) => {
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);

  // Active series
  const currentSeries = series.find((s) => s.id === (activeSeriesId || series[0]?.id)) || series[0];
  if (!currentSeries || currentSeries.data.length === 0) {
    return (
      <div className="flex h-48 items-center justify-center rounded-xl border border-dashed border-slate-200 bg-slate-50 text-xs text-slate-400">
        No longitudinal data available for {title}
      </div>
    );
  }

  // Filter valid numeric points
  const points = currentSeries.data;
  const validVals = points.map((p) => p.value).filter((v): v is number => v !== null && !isNaN(v));

  // Determine Min and Max with padding
  let minVal = validVals.length ? Math.min(...validVals) : 0;
  let maxVal = validVals.length ? Math.max(...validVals) : 100;

  if (currentSeries.refLow !== undefined) minVal = Math.min(minVal, currentSeries.refLow * 0.9);
  if (currentSeries.refHigh !== undefined) maxVal = Math.max(maxVal, currentSeries.refHigh * 1.1);
  if (currentSeries.optimalLow !== undefined) minVal = Math.min(minVal, currentSeries.optimalLow * 0.9);
  if (currentSeries.optimalHigh !== undefined) maxVal = Math.max(maxVal, currentSeries.optimalHigh * 1.1);

  const range = maxVal - minVal || 1;
  const paddingBottom = 40;
  const paddingTop = 24;
  const paddingLeft = 52;
  const paddingRight = 24;
  const chartWidth = 700;
  const chartHeight = height;

  const innerWidth = chartWidth - paddingLeft - paddingRight;
  const innerHeight = chartHeight - paddingTop - paddingBottom;

  const getX = (index: number) => {
    if (points.length <= 1) return paddingLeft + innerWidth / 2;
    return paddingLeft + (index / (points.length - 1)) * innerWidth;
  };

  const getY = (val: number | null) => {
    if (val === null) return chartHeight - paddingBottom;
    const normalized = (val - minVal) / range;
    return chartHeight - paddingBottom - normalized * innerHeight;
  };

  // Build SVG path
  const linePoints = points
    .map((p, i) => (p.value !== null ? `${getX(i)},${getY(p.value)}` : null))
    .filter(Boolean);
  const pathD = linePoints.length > 1 ? `M ${linePoints.join(' L ')}` : '';

  // Area under line
  const firstPoint = points.findIndex((p) => p.value !== null);
  const lastPoint = points.length - 1 - [...points].reverse().findIndex((p) => p.value !== null);
  let areaD = '';
  if (linePoints.length > 1 && firstPoint !== -1 && lastPoint !== -1) {
    areaD = `${pathD} L ${getX(lastPoint)},${chartHeight - paddingBottom} L ${getX(firstPoint)},${chartHeight - paddingBottom} Z`;
  }

  // Active hover point
  const hovered = hoverIndex !== null ? points[hoverIndex] : null;

  return (
    <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
      {/* Header with Title and Series Switcher */}
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h4 className="text-sm font-semibold tracking-tight text-slate-900">{title}</h4>
          {subtitle && <p className="text-xs text-slate-500">{subtitle}</p>}
        </div>

        {/* Series Pill / Switcher */}
        {series.length > 1 && (
          <div className="flex items-center gap-1 rounded-lg border border-slate-200 bg-slate-50 p-1">
            {series.map((s) => {
              const active = s.id === currentSeries.id;
              return (
                <button
                  key={s.id}
                  onClick={() => onSelectSeries && onSelectSeries(s.id)}
                  className={`rounded-md px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap ${
                    active ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <span
                    className="mr-1.5 inline-block h-2 w-2 rounded-full"
                    style={{ backgroundColor: s.color }}
                  />
                  {s.label}
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* Main SVG Visualization */}
      <div className="relative w-full overflow-hidden">
        <svg
          viewBox={`0 0 ${chartWidth} ${chartHeight}`}
          className="w-full select-none"
          style={{ height }}
          onMouseLeave={() => setHoverIndex(null)}
        >
          <defs>
            <linearGradient id={`gradient-${currentSeries.id}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={currentSeries.color} stopOpacity="0.18" />
              <stop offset="100%" stopColor={currentSeries.color} stopOpacity="0.01" />
            </linearGradient>
          </defs>

          {/* Reference range shading (Optimal or Normal Zone) */}
          {currentSeries.refLow !== undefined && currentSeries.refHigh !== undefined && (
            <rect
              x={paddingLeft}
              y={getY(currentSeries.refHigh)}
              width={innerWidth}
              height={Math.max(0, getY(currentSeries.refLow) - getY(currentSeries.refHigh))}
              fill="#F8FAFC"
              stroke="#E2E8F0"
              strokeDasharray="2 2"
              className="opacity-70"
            />
          )}

          {currentSeries.optimalLow !== undefined && currentSeries.optimalHigh !== undefined && (
            <rect
              x={paddingLeft}
              y={getY(currentSeries.optimalHigh)}
              width={innerWidth}
              height={Math.max(0, getY(currentSeries.optimalLow) - getY(currentSeries.optimalHigh))}
              fill="#ECFDF5"
              fillOpacity="0.6"
            />
          )}

          {/* Optimal target line */}
          {currentSeries.optimalHigh !== undefined && (
            <line
              x1={paddingLeft}
              x2={paddingLeft + innerWidth}
              y1={getY(currentSeries.optimalHigh)}
              y2={getY(currentSeries.optimalHigh)}
              stroke="#059669"
              strokeWidth="1"
              strokeDasharray="3 3"
              opacity="0.6"
            />
          )}

          {/* Upper threshold reference line */}
          {currentSeries.refHigh !== undefined && (
            <line
              x1={paddingLeft}
              x2={paddingLeft + innerWidth}
              y1={getY(currentSeries.refHigh)}
              y2={getY(currentSeries.refHigh)}
              stroke="#DC2626"
              strokeWidth="1"
              strokeDasharray="4 3"
              opacity="0.4"
            />
          )}

          {/* Grid lines horizontal */}
          {[0, 0.33, 0.66, 1].map((pct, idx) => {
            const val = minVal + pct * range;
            const y = chartHeight - paddingBottom - pct * innerHeight;
            return (
              <g key={idx}>
                <line
                  x1={paddingLeft}
                  x2={paddingLeft + innerWidth}
                  y1={y}
                  y2={y}
                  stroke="#F1F5F9"
                  strokeWidth="1"
                />
                <text
                  x={paddingLeft - 8}
                  y={y + 3}
                  textAnchor="end"
                  className="font-mono text-[10px] fill-slate-400 tabular-nums"
                >
                  {round2(val)}
                </text>
              </g>
            );
          })}

          {/* Area under curve */}
          {areaD && <path d={areaD} fill={`url(#gradient-${currentSeries.id})`} />}

          {/* Line curve */}
          {pathD && (
            <path
              d={pathD}
              fill="none"
              stroke={currentSeries.color}
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          )}

          {/* Points & Interactive Hover Columns */}
          {points.map((p, i) => {
            if (p.value === null) return null;
            const cx = getX(i);
            const cy = getY(p.value);
            const isHovered = hoverIndex === i;

            return (
              <g key={i}>
                {/* Invisible hover slice */}
                <rect
                  x={cx - innerWidth / (points.length * 2)}
                  y={paddingTop}
                  width={innerWidth / points.length}
                  height={innerHeight}
                  fill="transparent"
                  className="cursor-crosshair"
                  onMouseEnter={() => setHoverIndex(i)}
                />

                {/* Vertical hover crosshair indicator */}
                {isHovered && (
                  <line
                    x1={cx}
                    x2={cx}
                    y1={paddingTop}
                    y2={chartHeight - paddingBottom}
                    stroke="#94A3B8"
                    strokeWidth="1"
                    strokeDasharray="2 2"
                  />
                )}

                {/* Dot */}
                <circle
                  cx={cx}
                  cy={cy}
                  r={isHovered ? 6 : 4}
                  fill="#FFFFFF"
                  stroke={currentSeries.color}
                  strokeWidth={isHovered ? 3 : 2}
                  className="transition-all duration-100"
                />

                {/* X-axis date label */}
                <text
                  x={cx}
                  y={chartHeight - paddingBottom + 16}
                  textAnchor="middle"
                  className={`font-mono text-[10px] tabular-nums ${
                    isHovered ? 'fill-slate-900 font-semibold' : 'fill-slate-400'
                  }`}
                >
                  {p.date.slice(2)}
                </text>
              </g>
            );
          })}
        </svg>

        {/* Hover Monospace HUD Card */}
        {hovered && hoverIndex !== null && hovered.value !== null && (
          <div
            className="pointer-events-none absolute top-2 rounded-lg border border-slate-200 bg-white/95 px-3 py-2 text-xs shadow-md backdrop-blur-xs"
            style={{
              left: Math.min(Math.max(16, getX(hoverIndex) - 60), chartWidth - 160),
            }}
          >
            <div className="font-mono text-[10px] text-slate-400 tabular-nums">{hovered.date}</div>
            <div className="mt-0.5 flex items-baseline gap-1 font-mono">
              <span className="text-base font-bold text-slate-900 tabular-nums">
                {hovered.value}
              </span>
              <span className="text-[10px] uppercase text-slate-500">{currentSeries.unit}</span>
            </div>
            {hoverIndex > 0 && points[hoverIndex - 1]?.value !== null && (
              <div className="mt-0.5 text-[10px] text-slate-500 font-mono tabular-nums">
                Δ:{' '}
                <span
                  className={
                    hovered.value >= (points[hoverIndex - 1]?.value ?? 0)
                      ? 'text-amber-600'
                      : 'text-emerald-600'
                  }
                >
                  {round2(hovered.value - (points[hoverIndex - 1]?.value ?? 0))}
                </span>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Legend / Range Guide */}
      <div className="mt-2 flex flex-wrap items-center justify-between border-t border-slate-100 pt-2 text-[11px] text-slate-500">
        <div className="flex items-center gap-4">
          {currentSeries.refHigh !== undefined && (
            <div className="flex items-center gap-1.5">
              <span className="inline-block h-0.5 w-3 bg-red-400 border-t border-dashed" />
              <span>Reference Limit: {currentSeries.refHigh} {currentSeries.unit}</span>
            </div>
          )}
          {currentSeries.optimalHigh !== undefined && (
            <div className="flex items-center gap-1.5">
              <span className="inline-block h-0.5 w-3 bg-emerald-500 border-t border-dashed" />
              <span>Optimal Target: {currentSeries.optimalHigh} {currentSeries.unit}</span>
            </div>
          )}
        </div>
        <div className="font-mono text-[10px] text-slate-400">
          Showing {points.length} longitudinal exams
        </div>
      </div>
    </div>
  );
};
