import React, { useState } from 'react';
import { ExamRecord } from '../types/clinical';
import { VisualizerChart } from './VisualizerChart';
import { round2 } from '../lib/clinicalCalculations';
import { Activity, Zap, CheckCircle2, AlertCircle } from 'lucide-react';

interface ProfileEndoProps {
  currentExam: ExamRecord;
  allExams: ExamRecord[];
  patientId: string;
}

export const ProfileEndo: React.FC<ProfileEndoProps> = ({
  currentExam,
  allExams,
  patientId,
}) => {
  const [activeSeries, setActiveSeries] = useState('homa');
  const metrics = currentExam.endoMetrics;

  const patientExamsSorted = [...allExams]
    .filter((e) => e.patientId === patientId)
    .sort((a, b) => new Date(a.examDate).getTime() - new Date(b.examDate).getTime());

  const chartSeries = [
    {
      id: 'homa',
      label: 'HOMA-IR Score',
      color: '#EA580C',
      unit: 'index',
      data: patientExamsSorted.map((e) => ({
        date: e.examDate,
        value: e.endoMetrics?.homa_ir ?? null,
      })),
      refHigh: 2.0,
      optimalHigh: 1.0,
    },
    {
      id: 'glucose',
      label: 'Fasting Glucose',
      color: '#2563EB',
      unit: 'mg/dL',
      data: patientExamsSorted.map((e) => ({
        date: e.examDate,
        value: e.endoMetrics?.glucose ?? null,
      })),
      refHigh: 99,
      optimalHigh: 88,
    },
    {
      id: 'insulin',
      label: 'Fasting Insulin',
      color: '#7C3AED',
      unit: 'uIU/mL',
      data: patientExamsSorted.map((e) => ({
        date: e.examDate,
        value: e.endoMetrics?.fasting_insulin ?? null,
      })),
      refHigh: 15,
      optimalHigh: 6,
    },
    {
      id: 'hba1c',
      label: 'Hemoglobin A1c',
      color: '#DC2626',
      unit: '%',
      data: patientExamsSorted.map((e) => ({
        date: e.examDate,
        value: e.endoMetrics?.hba1c ?? null,
      })),
      refHigh: 5.6,
      optimalHigh: 5.3,
    },
    {
      id: 'vitd',
      label: 'Vitamin D (25-OH)',
      color: '#059669',
      unit: 'ng/mL',
      data: patientExamsSorted.map((e) => ({
        date: e.examDate,
        value: e.endoMetrics?.vitamin_d ?? null,
      })),
      refLow: 30,
      optimalLow: 45,
    },
    {
      id: 'tsh',
      label: 'TSH',
      color: '#0891B2',
      unit: 'uIU/mL',
      data: patientExamsSorted.map((e) => ({
        date: e.examDate,
        value: e.endoMetrics?.tsh ?? null,
      })),
      refHigh: 4.5,
      optimalHigh: 2.5,
    },
  ];

  return (
    <div className="space-y-6">
      {/* Overview Banner */}
      <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="font-mono text-xs uppercase tracking-wider text-slate-400">
              Profile Pipeline: Endocrinology & Metabolism
            </span>
            <span className="inline-flex items-center gap-1 rounded bg-slate-100 px-2 py-0.5 text-[11px] font-medium text-slate-700">
              Exam: {currentExam.examDate}
            </span>
          </div>
          <h2 className="mt-1 text-lg font-bold tracking-tight text-slate-900">
            Insulin Sensitivity: {metrics?.homa_ir_status}
          </h2>
          <p className="text-xs text-slate-500">
            HOMA-IR = (Glucose × Insulin) / 405. Evaluates beta-cell compensatory response and peripheral glucose disposal.
          </p>
        </div>

        <div className="flex items-center gap-6">
          <div className="text-right">
            <div className="text-[10px] font-medium uppercase text-slate-400">HOMA-IR Score</div>
            <div className="font-mono text-2xl font-bold text-slate-900 tabular-nums">
              {metrics?.homa_ir !== null ? metrics?.homa_ir : '—'}
            </div>
          </div>
          <div className="text-right">
            <div className="text-[10px] font-medium uppercase text-slate-400">QUICKI Index</div>
            <div className="font-mono text-2xl font-bold text-slate-900 tabular-nums">
              {metrics?.quicki !== null ? metrics?.quicki : '—'}
            </div>
          </div>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
        <div className="rounded-xl border border-slate-200 bg-white p-3.5">
          <div className="text-[11px] font-medium text-slate-500">Fasting Glucose</div>
          <div className="mt-1 font-mono text-xl font-bold text-slate-900 tabular-nums">
            {metrics?.glucose ?? '—'}
          </div>
          <div className="mt-1 text-[10px] text-slate-400">Ref: 70–99 mg/dL</div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-3.5">
          <div className="text-[11px] font-medium text-slate-500">Fasting Insulin</div>
          <div className="mt-1 font-mono text-xl font-bold text-slate-900 tabular-nums">
            {metrics?.fasting_insulin ?? '—'}
          </div>
          <div className="mt-1 text-[10px] text-slate-400">Optimal: 2–6 uIU/mL</div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-3.5">
          <div className="text-[11px] font-medium text-slate-500">Hemoglobin A1c</div>
          <div className="mt-1 font-mono text-xl font-bold text-slate-900 tabular-nums">
            {metrics?.hba1c ?? '—'}%
          </div>
          <div className="mt-1 text-[10px] text-slate-400">Ref: 4.5–5.6 %</div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-3.5">
          <div className="text-[11px] font-medium text-slate-500">Estimated Avg Glucose</div>
          <div className="mt-1 font-mono text-xl font-bold text-slate-900 tabular-nums">
            {metrics?.eag_mgdl ?? '—'}
          </div>
          <div className="mt-1 text-[10px] text-slate-400">eAG = 28.7×A1c - 46.7</div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-3.5">
          <div className="text-[11px] font-medium text-slate-500">TSH / FT4 Axis</div>
          <div className="mt-1 font-mono text-xl font-bold text-slate-900 tabular-nums">
            {metrics?.tsh ?? '—'}
          </div>
          <div className="mt-1 text-[10px] text-slate-400">FT4: {metrics?.free_t4 ?? '—'} ng/dL</div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-3.5">
          <div className="text-[11px] font-medium text-slate-500">Vitamin D (25-OH)</div>
          <div className="mt-1 font-mono text-xl font-bold text-slate-900 tabular-nums">
            {metrics?.vitamin_d ?? '—'}
          </div>
          <div className="mt-1 text-[10px] text-slate-400">{metrics?.vitamin_d_status}</div>
        </div>
      </div>

      {/* Main Longitudinal Visualizer */}
      <VisualizerChart
        title="Endocrine & Glycemic Dynamics Trajectory"
        subtitle="Longitudinal progression of insulin resistance, fasting glycemic levels, and thyroid parameters"
        series={chartSeries}
        activeSeriesId={activeSeries}
        onSelectSeries={setActiveSeries}
        height={320}
      />

      {/* Calculations & Interpretation Breakdown */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
          <h3 className="text-sm font-semibold text-slate-900">
            Metabolic & Insulin Dynamics Interpretation
          </h3>
          <div className="mt-4 space-y-3">
            <div className="rounded-lg border border-slate-100 bg-slate-50 p-3 text-xs">
              <div className="font-semibold text-slate-800">HOMA-IR Interpretation Tier</div>
              <div className="mt-1 text-slate-600">
                Current score <strong className="font-mono text-slate-900">{metrics?.homa_ir ?? '—'}</strong> is classified as <em>{metrics?.homa_ir_status}</em>.
                Values &lt; 1.0 denote prime insulin sensitivity; &gt; 2.0 indicates compensatory hyperinsulinemia.
              </div>
            </div>

            <div className="rounded-lg border border-slate-100 bg-slate-50 p-3 text-xs">
              <div className="font-semibold text-slate-800">QUICKI Sensitivity Index</div>
              <div className="mt-1 text-slate-600">
                Score <strong className="font-mono text-slate-900">{metrics?.quicki ?? '—'}</strong> ({metrics?.quicki_status}). Inverse logarithmic transformation providing robust reproducibility.
              </div>
            </div>

            <div className="rounded-lg border border-slate-100 bg-slate-50 p-3 text-xs">
              <div className="font-semibold text-slate-800">TSH / Free T4 Ratio</div>
              <div className="mt-1 text-slate-600">
                Ratio: <strong className="font-mono text-slate-900">{metrics?.tsh_free_t4_ratio ?? '—'}</strong>. Evaluates central hypothalamic-pituitary-thyroid feedback responsiveness.
              </div>
            </div>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
          <h3 className="text-sm font-semibold text-slate-900">
            Endocrinology Quality & Validation Audit
          </h3>
          <div className="mt-4 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2 text-xs">
              <span className="text-slate-600">Data Completeness</span>
              <span className="font-medium text-emerald-700">
                {metrics?.is_complete ? 'All Core Analytes Present' : 'Partial Record'}
              </span>
            </div>

            <div className="flex items-center justify-between border-b border-slate-100 pb-2 text-xs">
              <span className="text-slate-600">Calculated eAG</span>
              <span className="font-mono font-bold text-slate-900 tabular-nums">
                {metrics?.eag_mgdl ? `${metrics.eag_mgdl} mg/dL` : '—'}
              </span>
            </div>

            <div className="flex items-center justify-between border-b border-slate-100 pb-2 text-xs">
              <span className="text-slate-600">Vitamin D Classification</span>
              <span className="font-medium text-slate-900">
                {metrics?.vitamin_d_status}
              </span>
            </div>

            <div className="pt-2 text-xs text-slate-500">
              {metrics?.record_quality_note || 'Record verified: Glucose, Insulin, and HbA1c timestamps synchronized for valid HOMA-IR computation.'}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
