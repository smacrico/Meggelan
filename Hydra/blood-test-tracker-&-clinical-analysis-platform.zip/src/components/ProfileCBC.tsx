import React, { useState } from 'react';
import { ExamRecord } from '../types/clinical';
import { VisualizerChart } from './VisualizerChart';

interface ProfileCBCProps {
  currentExam: ExamRecord;
  allExams: ExamRecord[];
  patientId: string;
}

export const ProfileCBC: React.FC<ProfileCBCProps> = ({
  currentExam,
  allExams,
  patientId,
}) => {
  const [activeSeries, setActiveSeries] = useState('hemoglobin');
  const cbc = currentExam.cbcMetrics;

  const patientExamsSorted = [...allExams]
    .filter((e) => e.patientId === patientId)
    .sort((a, b) => new Date(a.examDate).getTime() - new Date(b.examDate).getTime());

  const chartSeries = [
    {
      id: 'hemoglobin',
      label: 'Hemoglobin',
      color: '#DC2626',
      unit: 'g/dL',
      data: patientExamsSorted.map((e) => ({
        date: e.examDate,
        value: e.cbcMetrics?.hemoglobin ?? null,
      })),
      refLow: 13.5,
      refHigh: 17.5,
      optimalLow: 14.0,
      optimalHigh: 16.5,
    },
    {
      id: 'wbc',
      label: 'WBC Count',
      color: '#2563EB',
      unit: 'K/uL',
      data: patientExamsSorted.map((e) => ({
        date: e.examDate,
        value: e.cbcMetrics?.wbc ?? null,
      })),
      refLow: 4.0,
      refHigh: 11.0,
      optimalLow: 4.5,
      optimalHigh: 7.5,
    },
    {
      id: 'platelets',
      label: 'Platelets',
      color: '#7C3AED',
      unit: 'K/uL',
      data: patientExamsSorted.map((e) => ({
        date: e.examDate,
        value: e.cbcMetrics?.platelets ?? null,
      })),
      refLow: 150,
      refHigh: 450,
      optimalLow: 180,
      optimalHigh: 350,
    },
    {
      id: 'mcv',
      label: 'MCV',
      color: '#059669',
      unit: 'fL',
      data: patientExamsSorted.map((e) => ({
        date: e.examDate,
        value: e.cbcMetrics?.mcv ?? null,
      })),
      refLow: 80,
      refHigh: 100,
      optimalLow: 84,
      optimalHigh: 94,
    },
    {
      id: 'nlr',
      label: 'NLR Ratio',
      color: '#D97706',
      unit: 'ratio',
      data: patientExamsSorted.map((e) => ({
        date: e.examDate,
        value: e.cbcMetrics?.nlr ?? null,
      })),
      refHigh: 3.0,
      optimalHigh: 2.0,
    },
  ];

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="font-mono text-xs uppercase tracking-wider text-slate-400">
              Profile Pipeline: Complete Blood Count & Hematology
            </span>
            <span className="inline-flex items-center gap-1 rounded bg-slate-100 px-2 py-0.5 text-[11px] font-medium text-slate-700">
              Exam: {currentExam.examDate}
            </span>
          </div>
          <h2 className="mt-1 text-lg font-bold tracking-tight text-slate-900">
            Erythrocyte Status: {cbc?.anemia_classification}
          </h2>
          <p className="text-xs text-slate-500">
            Automated red cell indices synthesis, differential leukocyte analysis, and Neutrophil-to-Lymphocyte Ratio (NLR).
          </p>
        </div>

        <div className="flex items-center gap-6">
          <div className="text-right">
            <div className="text-[10px] font-medium uppercase text-slate-400">NLR Ratio</div>
            <div className="font-mono text-2xl font-bold text-slate-900 tabular-nums">
              {cbc?.nlr !== null ? cbc?.nlr : '—'}
            </div>
            <div className="text-[11px] text-slate-500">{cbc?.nlr_status}</div>
          </div>
        </div>
      </div>

      {/* Primary CBC Grid */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
        <div className="rounded-xl border border-slate-200 bg-white p-3.5">
          <div className="text-[11px] font-medium text-slate-500">WBC Count</div>
          <div className="mt-1 font-mono text-xl font-bold text-slate-900 tabular-nums">
            {cbc?.wbc ?? '—'}
          </div>
          <div className="mt-1 text-[10px] text-slate-400">Ref: 4.0–11.0 K/uL</div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-3.5">
          <div className="text-[11px] font-medium text-slate-500">RBC Count</div>
          <div className="mt-1 font-mono text-xl font-bold text-slate-900 tabular-nums">
            {cbc?.rbc ?? '—'}
          </div>
          <div className="mt-1 text-[10px] text-slate-400">Ref: 4.3–5.9 M/uL</div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-3.5">
          <div className="text-[11px] font-medium text-slate-500">Hemoglobin</div>
          <div className="mt-1 font-mono text-xl font-bold text-slate-900 tabular-nums">
            {cbc?.hemoglobin ?? '—'}
          </div>
          <div className="mt-1 text-[10px] text-slate-400">Ref: 13.5–17.5 g/dL</div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-3.5">
          <div className="text-[11px] font-medium text-slate-500">Hematocrit</div>
          <div className="mt-1 font-mono text-xl font-bold text-slate-900 tabular-nums">
            {cbc?.hematocrit ?? '—'}%
          </div>
          <div className="mt-1 text-[10px] text-slate-400">Ref: 38.8–50.0 %</div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-3.5">
          <div className="text-[11px] font-medium text-slate-500">MCV (Volume)</div>
          <div className="mt-1 font-mono text-xl font-bold text-slate-900 tabular-nums">
            {cbc?.mcv ?? '—'}
          </div>
          <div className="mt-1 text-[10px] text-slate-400">Ref: 80–100 fL</div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-3.5">
          <div className="text-[11px] font-medium text-slate-500">Platelet Count</div>
          <div className="mt-1 font-mono text-xl font-bold text-slate-900 tabular-nums">
            {cbc?.platelets ?? '—'}
          </div>
          <div className="mt-1 text-[10px] text-slate-400">Ref: 150–450 K/uL</div>
        </div>
      </div>

      {/* Visualizer Chart */}
      <VisualizerChart
        title="Hematology & Blood Indices Trajectory"
        subtitle="Longitudinal tracking of Hemoglobin, White Blood Count, Platelets, and MCV"
        series={chartSeries}
        activeSeriesId={activeSeries}
        onSelectSeries={setActiveSeries}
        height={320}
      />

      {/* Differential Table & Red Cell Indices */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
          <h3 className="text-sm font-semibold text-slate-900">
            Leukocyte Differential Breakdown
          </h3>
          <div className="mt-4 space-y-2.5">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2 text-xs">
              <span className="text-slate-600">Neutrophils %</span>
              <span className="font-mono font-bold text-slate-900 tabular-nums">
                {cbc?.neutrophils_pct ?? '—'}%
              </span>
            </div>
            <div className="flex items-center justify-between border-b border-slate-100 pb-2 text-xs">
              <span className="text-slate-600">Lymphocytes %</span>
              <span className="font-mono font-bold text-slate-900 tabular-nums">
                {cbc?.lymphocytes_pct ?? '—'}%
              </span>
            </div>
            <div className="flex items-center justify-between border-b border-slate-100 pb-2 text-xs">
              <span className="text-slate-600">Monocytes %</span>
              <span className="font-mono font-bold text-slate-900 tabular-nums">
                {cbc?.monocytes_pct ?? '—'}%
              </span>
            </div>
            <div className="flex items-center justify-between border-b border-slate-100 pb-2 text-xs">
              <span className="text-slate-600">Eosinophils %</span>
              <span className="font-mono font-bold text-slate-900 tabular-nums">
                {cbc?.eosinophils_pct ?? '—'}%
              </span>
            </div>
            <div className="flex items-center justify-between text-xs pt-1">
              <span className="text-slate-600">Basophils %</span>
              <span className="font-mono font-bold text-slate-900 tabular-nums">
                {cbc?.basophils_pct ?? '—'}%
              </span>
            </div>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
          <h3 className="text-sm font-semibold text-slate-900">
            Red Cell Morphologic Indices
          </h3>
          <div className="mt-4 space-y-2.5">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2 text-xs">
              <span className="text-slate-600">MCH (Mean Corpuscular Hemoglobin)</span>
              <span className="font-mono font-bold text-slate-900 tabular-nums">
                {cbc?.mch ?? '—'} pg
              </span>
            </div>
            <div className="flex items-center justify-between border-b border-slate-100 pb-2 text-xs">
              <span className="text-slate-600">MCHC (Cellular Concentration)</span>
              <span className="font-mono font-bold text-slate-900 tabular-nums">
                {cbc?.mchc ?? '—'} g/dL
              </span>
            </div>
            <div className="flex items-center justify-between border-b border-slate-100 pb-2 text-xs">
              <span className="text-slate-600">RDW (Red Cell Width Anisocytosis)</span>
              <span className="font-mono font-bold text-slate-900 tabular-nums">
                {cbc?.rdw ?? '—'}%
              </span>
            </div>
            <div className="flex items-center justify-between text-xs pt-1">
              <span className="text-slate-600">Diagnostic Morphology</span>
              <span className="font-medium text-slate-900">
                {cbc?.anemia_classification}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
