import React, { useState } from 'react';
import { ExamRecord } from '../types/clinical';
import { BIOMARKER_DICTIONARY } from '../lib/biomarkerDictionary';
import { round2 } from '../lib/clinicalCalculations';
import { ArrowDownRight, ArrowUpRight, Minus, Download } from 'lucide-react';

interface ExamComparatorProps {
  allExams: ExamRecord[];
  patientId: string;
}

export const ExamComparator: React.FC<ExamComparatorProps> = ({
  allExams,
  patientId,
}) => {
  const patientExamsSorted = [...allExams]
    .filter((e) => e.patientId === patientId)
    .sort((a, b) => new Date(a.examDate).getTime() - new Date(b.examDate).getTime());

  const [baseExamId, setBaseExamId] = useState(patientExamsSorted[0]?.id || '');
  const [targetExamId, setTargetExamId] = useState(
    patientExamsSorted[patientExamsSorted.length - 1]?.id || ''
  );
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const baseExam = patientExamsSorted.find((e) => e.id === baseExamId) || patientExamsSorted[0];
  const targetExam = patientExamsSorted.find((e) => e.id === targetExamId) || patientExamsSorted[patientExamsSorted.length - 1];

  if (!baseExam || !targetExam) {
    return (
      <div className="rounded-xl border border-slate-200 bg-white p-6 text-center text-xs text-slate-500">
        Requires at least 2 exams to perform comparative analysis.
      </div>
    );
  }

  // Extract all comparable keys across both exams
  const getExamValue = (exam: ExamRecord, code: string): number | null => {
    switch (code) {
      case 'total_cholesterol': return exam.lipidMetrics?.total_cholesterol ?? null;
      case 'hdl': return exam.lipidMetrics?.hdl ?? null;
      case 'ldl': return exam.lipidMetrics?.ldl_final ?? null;
      case 'triglycerides': return exam.lipidMetrics?.triglycerides ?? null;
      case 'non_hdl': return exam.lipidMetrics?.non_hdl_final ?? null;
      case 'aip': return exam.lipidMetrics?.aip ?? null;
      case 'glucose': return exam.endoMetrics?.glucose ?? null;
      case 'fasting_insulin': return exam.endoMetrics?.fasting_insulin ?? null;
      case 'hba1c': return exam.endoMetrics?.hba1c ?? null;
      case 'homa_ir': return exam.endoMetrics?.homa_ir ?? null;
      case 'quicki': return exam.endoMetrics?.quicki ?? null;
      case 'tsh': return exam.endoMetrics?.tsh ?? null;
      case 'free_t4': return exam.endoMetrics?.free_t4 ?? null;
      case 'vitamin_d': return exam.endoMetrics?.vitamin_d ?? null;
      case 'wbc': return exam.cbcMetrics?.wbc ?? null;
      case 'rbc': return exam.cbcMetrics?.rbc ?? null;
      case 'hemoglobin': return exam.cbcMetrics?.hemoglobin ?? null;
      case 'hematocrit': return exam.cbcMetrics?.hematocrit ?? null;
      case 'platelets': return exam.cbcMetrics?.platelets ?? null;
      case 'mcv': return exam.cbcMetrics?.mcv ?? null;
      case 'nlr': return exam.cbcMetrics?.nlr ?? null;
      case 'alt': return exam.liverMetrics?.alt ?? null;
      case 'ast': return exam.liverMetrics?.ast ?? null;
      case 'ggt': return exam.liverMetrics?.ggt ?? null;
      case 'alp': return exam.liverMetrics?.alp ?? null;
      case 'de_ritis': return exam.liverMetrics?.de_ritis_ratio ?? null;
      case 'serum_iron': return exam.ironMetrics?.serum_iron ?? null;
      case 'ferritin': return exam.ironMetrics?.ferritin ?? null;
      case 'tsat': return exam.ironMetrics?.tsat ?? null;
      case 'hs_crp': return exam.inflammationMetrics?.hs_crp ?? null;
      case 'vitamin_b12': return exam.vitaminsMetrics?.vitamin_b12 ?? null;
      case 'magnesium': return exam.vitaminsMetrics?.magnesium ?? null;
      default: return null;
    }
  };

  const comparableList = [
    { code: 'total_cholesterol', name: 'Total Cholesterol', cat: 'lipid', unit: 'mg/dL', lowerIsBetter: true },
    { code: 'ldl', name: 'LDL Cholesterol', cat: 'lipid', unit: 'mg/dL', lowerIsBetter: true },
    { code: 'hdl', name: 'HDL Cholesterol', cat: 'lipid', unit: 'mg/dL', lowerIsBetter: false },
    { code: 'triglycerides', name: 'Triglycerides', cat: 'lipid', unit: 'mg/dL', lowerIsBetter: true },
    { code: 'non_hdl', name: 'Non-HDL Cholesterol', cat: 'lipid', unit: 'mg/dL', lowerIsBetter: true },
    { code: 'aip', name: 'AIP (Atherogenic Index)', cat: 'lipid', unit: 'index', lowerIsBetter: true },
    { code: 'glucose', name: 'Fasting Glucose', cat: 'endocrine', unit: 'mg/dL', lowerIsBetter: true },
    { code: 'fasting_insulin', name: 'Fasting Insulin', cat: 'endocrine', unit: 'uIU/mL', lowerIsBetter: true },
    { code: 'hba1c', name: 'Hemoglobin A1c', cat: 'endocrine', unit: '%', lowerIsBetter: true },
    { code: 'homa_ir', name: 'HOMA-IR Score', cat: 'endocrine', unit: 'index', lowerIsBetter: true },
    { code: 'quicki', name: 'QUICKI Index', cat: 'endocrine', unit: 'index', lowerIsBetter: false },
    { code: 'tsh', name: 'TSH', cat: 'endocrine', unit: 'uIU/mL', lowerIsBetter: null },
    { code: 'free_t4', name: 'Free T4', cat: 'endocrine', unit: 'ng/dL', lowerIsBetter: null },
    { code: 'vitamin_d', name: 'Vitamin D (25-OH)', cat: 'endocrine', unit: 'ng/mL', lowerIsBetter: false },
    { code: 'hemoglobin', name: 'Hemoglobin', cat: 'cbc', unit: 'g/dL', lowerIsBetter: false },
    { code: 'wbc', name: 'WBC Count', cat: 'cbc', unit: 'K/uL', lowerIsBetter: null },
    { code: 'platelets', name: 'Platelets', cat: 'cbc', unit: 'K/uL', lowerIsBetter: null },
    { code: 'mcv', name: 'MCV', cat: 'cbc', unit: 'fL', lowerIsBetter: null },
    { code: 'nlr', name: 'NLR Ratio', cat: 'cbc', unit: 'ratio', lowerIsBetter: true },
    { code: 'alt', name: 'ALT (SGPT)', cat: 'liver', unit: 'U/L', lowerIsBetter: true },
    { code: 'ast', name: 'AST (SGOT)', cat: 'liver', unit: 'U/L', lowerIsBetter: true },
    { code: 'ggt', name: 'GGT', cat: 'liver', unit: 'U/L', lowerIsBetter: true },
    { code: 'de_ritis', name: 'De Ritis (AST/ALT)', cat: 'liver', unit: 'ratio', lowerIsBetter: true },
    { code: 'ferritin', name: 'Ferritin', cat: 'iron', unit: 'ng/mL', lowerIsBetter: null },
    { code: 'tsat', name: 'TSAT (%)', cat: 'iron', unit: '%', lowerIsBetter: false },
    { code: 'hs_crp', name: 'hs-CRP', cat: 'inflammation', unit: 'mg/L', lowerIsBetter: true },
    { code: 'vitamin_b12', name: 'Vitamin B12', cat: 'vitamins', unit: 'pg/mL', lowerIsBetter: false },
    { code: 'magnesium', name: 'Magnesium', cat: 'vitamins', unit: 'mg/dL', lowerIsBetter: false },
  ];

  const filteredList = comparableList.filter((item) => {
    if (selectedCategory === 'all') return true;
    return item.cat === selectedCategory;
  });

  const exportCSV = () => {
    const headers = ['Marker', 'Category', 'Unit', `Base (${baseExam.examDate})`, `Target (${targetExam.examDate})`, 'Delta', 'Pct Change (%)'];
    const rows = filteredList.map((m) => {
      const v1 = getExamValue(baseExam, m.code);
      const v2 = getExamValue(targetExam, m.code);
      const delta = (v1 !== null && v2 !== null) ? round2(v2 - v1) : '';
      const pct = (v1 !== null && v2 !== null && v1 !== 0) ? round2(((v2 - v1) / Math.abs(v1)) * 100) : '';
      return [
        `"${m.name}"`,
        m.cat,
        m.unit,
        v1 ?? '',
        v2 ?? '',
        delta,
        pct
      ].join(',');
    });

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `comparison_${baseExam.examDate}_vs_${targetExam.examDate}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Selector & Controls Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
        <div>
          <h2 className="text-base font-bold text-slate-900">
            Longitudinal Exam Comparison Matrix
          </h2>
          <p className="text-xs text-slate-500">
            Side-by-side delta auditing and percentage trajectory across all 7 clinical profiles.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Base Exam Selector */}
          <div>
            <span className="mr-2 text-[11px] text-slate-400 uppercase">Baseline:</span>
            <select
              value={baseExamId}
              onChange={(e) => setBaseExamId(e.target.value)}
              className="rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 font-mono text-xs text-slate-800 focus:outline-hidden"
            >
              {patientExamsSorted.map((e) => (
                <option key={e.id} value={e.id}>
                  {e.examDate}
                </option>
              ))}
            </select>
          </div>

          <span className="text-slate-400">vs</span>

          {/* Target Exam Selector */}
          <div>
            <span className="mr-2 text-[11px] text-slate-400 uppercase">Comparison:</span>
            <select
              value={targetExamId}
              onChange={(e) => setTargetExamId(e.target.value)}
              className="rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 font-mono text-xs text-slate-800 focus:outline-hidden"
            >
              {patientExamsSorted.map((e) => (
                <option key={e.id} value={e.id}>
                  {e.examDate}
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={exportCSV}
            className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors"
          >
            <Download className="h-3.5 w-3.5" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Category Filter Tabs */}
      <div className="flex flex-wrap items-center gap-1.5">
        {[
          { id: 'all', label: 'All Markers' },
          { id: 'lipid', label: 'Lipidemic' },
          { id: 'endocrine', label: 'Endocrinology' },
          { id: 'cbc', label: 'CBC & Hematology' },
          { id: 'liver', label: 'Liver Function' },
          { id: 'iron', label: 'Iron Kinetics' },
          { id: 'inflammation', label: 'Inflammation' },
          { id: 'vitamins', label: 'Vitamins' },
        ].map((tab) => {
          const active = selectedCategory === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setSelectedCategory(tab.id)}
              className={`rounded-lg px-3 py-1.5 text-xs font-medium transition-colors ${
                active
                  ? 'bg-slate-900 text-white'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Comparison Data Table */}
      <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xs">
        <table className="w-full text-left text-xs">
          <thead className="border-b border-slate-200 bg-slate-50/75 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
            <tr>
              <th className="px-4 py-3">Biomarker & Analyte</th>
              <th className="px-4 py-3">Profile</th>
              <th className="px-4 py-3 font-mono">Base: {baseExam.examDate}</th>
              <th className="px-4 py-3 font-mono">Target: {targetExam.examDate}</th>
              <th className="px-4 py-3 font-mono text-right">Delta (Δ)</th>
              <th className="px-4 py-3 font-mono text-right">Change (%)</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 font-mono">
            {filteredList.map((item) => {
              const v1 = getExamValue(baseExam, item.code);
              const v2 = getExamValue(targetExam, item.code);

              let delta: number | null = null;
              let pct: number | null = null;
              let isImprovement: boolean | null = null;

              if (v1 !== null && v2 !== null) {
                delta = round2(v2 - v1);
                if (v1 !== 0) {
                  pct = round2(((v2 - v1) / Math.abs(v1)) * 100);
                }

                if (delta !== null) {
                  if (item.lowerIsBetter === true) {
                    isImprovement = delta < 0;
                  } else if (item.lowerIsBetter === false) {
                    isImprovement = delta > 0;
                  }
                }
              }

              return (
                <tr key={item.code} className="hover:bg-slate-50/50">
                  <td className="px-4 py-3 font-sans font-medium text-slate-900">
                    {item.name}
                    <span className="ml-1.5 text-[10px] text-slate-400 uppercase">
                      ({item.unit})
                    </span>
                  </td>
                  <td className="px-4 py-3 font-sans text-[11px] uppercase text-slate-400">
                    {item.cat}
                  </td>
                  <td className="px-4 py-3 text-slate-700 tabular-nums">
                    {v1 !== null ? v1 : '—'}
                  </td>
                  <td className="px-4 py-3 font-bold text-slate-900 tabular-nums">
                    {v2 !== null ? v2 : '—'}
                  </td>
                  <td className="px-4 py-3 text-right tabular-nums">
                    {delta !== null ? (
                      <span
                        className={
                          isImprovement === true
                            ? 'text-emerald-700 font-semibold'
                            : isImprovement === false
                            ? 'text-rose-600 font-semibold'
                            : 'text-slate-600'
                        }
                      >
                        {delta > 0 ? `+${delta}` : delta}
                      </span>
                    ) : (
                      '—'
                    )}
                  </td>
                  <td className="px-4 py-3 text-right tabular-nums">
                    {pct !== null ? (
                      <span
                        className={`inline-flex items-center gap-0.5 ${
                          isImprovement === true
                            ? 'text-emerald-700 font-semibold'
                            : isImprovement === false
                            ? 'text-rose-600 font-semibold'
                            : 'text-slate-500'
                        }`}
                      >
                        {pct > 0 ? (
                          <ArrowUpRight className="h-3 w-3" />
                        ) : pct < 0 ? (
                          <ArrowDownRight className="h-3 w-3" />
                        ) : (
                          <Minus className="h-3 w-3" />
                        )}
                        {pct > 0 ? `+${pct}%` : `${pct}%`}
                      </span>
                    ) : (
                      '—'
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
