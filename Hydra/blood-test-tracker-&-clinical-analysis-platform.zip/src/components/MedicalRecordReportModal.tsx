import React, { useState } from 'react';
import { ExamRecord, PatientRecord } from '../types/clinical';
import { generateClinicalPDFReport } from '../lib/pdfReportGenerator';
import { X, Download, Printer, FileText, CheckCircle2, AlertTriangle, ShieldCheck } from 'lucide-react';

interface MedicalRecordReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  patient: PatientRecord;
  exam: ExamRecord;
  allPatientExams: ExamRecord[];
  onSelectExam: (examId: string) => void;
}

export const MedicalRecordReportModal: React.FC<MedicalRecordReportModalProps> = ({
  isOpen,
  onClose,
  patient,
  exam,
  allPatientExams,
  onSelectExam,
}) => {
  const [downloading, setDownloading] = useState(false);

  if (!isOpen) return null;

  const handleDownloadPDF = () => {
    setDownloading(true);
    try {
      generateClinicalPDFReport(patient, exam);
    } catch (err) {
      console.error('Failed to generate PDF:', err);
    } finally {
      setTimeout(() => setDownloading(false), 800);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const lipid = exam.lipidMetrics;
  const endo = exam.endoMetrics;
  const cbc = exam.cbcMetrics;
  const liver = exam.liverMetrics;
  const iron = exam.ironMetrics;
  const inflam = exam.inflammationMetrics;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs no-print-backdrop">
      <div className="max-h-[92vh] w-full max-w-4xl overflow-y-auto rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl">
        {/* Modal Controls Bar */}
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 pb-4 no-print">
          <div className="flex items-center gap-3">
            <div className="rounded-lg bg-blue-50 p-2 text-blue-700">
              <FileText className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Official Clinical Laboratory Report
              </h3>
              <p className="text-xs text-slate-500">
                Formatted for medical record archiving, clinician sharing, and printing.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Exam date switcher inside modal */}
            <div className="flex items-center gap-1.5 mr-2">
              <span className="text-xs text-slate-400">Exam:</span>
              <select
                value={exam.id}
                onChange={(e) => onSelectExam(e.target.value)}
                className="rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 font-mono text-xs text-slate-800"
              >
                {allPatientExams.map((e) => (
                  <option key={e.id} value={e.id}>
                    {e.examDate}
                  </option>
                ))}
              </select>
            </div>

            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors"
            >
              <Printer className="h-3.5 w-3.5 text-slate-500" />
              <span>Print Document</span>
            </button>

            <button
              onClick={handleDownloadPDF}
              disabled={downloading}
              className="flex items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-slate-800 transition-colors disabled:opacity-50"
            >
              <Download className="h-3.5 w-3.5" />
              <span>{downloading ? 'Generating PDF...' : 'Download PDF'}</span>
            </button>

            <button
              onClick={onClose}
              className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-600 transition-colors ml-1"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Printable Paper Document Sheet */}
        <div id="printable-clinical-report" className="mt-6 rounded-xl border border-slate-200 bg-white p-6 font-sans text-xs text-slate-800 shadow-xs">
          {/* Header Banner */}
          <div className="flex flex-wrap items-center justify-between border-b-2 border-slate-900 pb-4">
            <div>
              <div className="text-xs font-bold tracking-widest uppercase text-slate-500">
                CLINICAL PATHOLOGY LABORATORY REPORT
              </div>
              <h1 className="mt-0.5 text-xl font-extrabold text-slate-900">
                Comprehensive Multi-Profile Blood Panel
              </h1>
              <div className="mt-0.5 text-[11px] text-slate-500">
                Accreditation: CLIA #99D0874521 · College of American Pathologists (CAP) Certified
              </div>
            </div>

            <div className="text-right">
              <div className="text-sm font-bold text-slate-900">{exam.labFacility}</div>
              <div className="font-mono text-xs text-slate-500">Specimen ID: #{exam.id.slice(0, 12)}</div>
              <div className="font-mono text-[11px] text-slate-400">Date Collected: {exam.examDate}</div>
            </div>
          </div>

          {/* Demographics Strip */}
          <div className="mt-4 grid grid-cols-2 gap-4 rounded-lg bg-slate-50 p-3 sm:grid-cols-4 border border-slate-200">
            <div>
              <div className="text-[10px] uppercase font-bold text-slate-400">Patient Name</div>
              <div className="font-semibold text-slate-900 text-sm">{patient.name}</div>
            </div>
            <div>
              <div className="text-[10px] uppercase font-bold text-slate-400">Patient ID / DOB</div>
              <div className="font-mono text-slate-800">{patient.id} · {patient.birthDate}</div>
            </div>
            <div>
              <div className="text-[10px] uppercase font-bold text-slate-400">Age / Gender</div>
              <div className="text-slate-800">{patient.age} Yrs / {patient.gender.toUpperCase()}</div>
            </div>
            <div>
              <div className="text-[10px] uppercase font-bold text-slate-400">Ordering Physician</div>
              <div className="text-slate-800">{exam.orderingPhysician || 'Dr. Aris Thorne, MD'}</div>
            </div>
          </div>

          {/* Executive Diagnostic Findings */}
          <div className="mt-4 rounded-lg border border-slate-200 bg-slate-50/50 p-3">
            <div className="text-[10px] uppercase font-bold tracking-wider text-slate-500">
              Diagnostic Indices & Risk Summary
            </div>
            <div className="mt-1 grid grid-cols-2 gap-3 sm:grid-cols-4 font-mono text-xs">
              <div>
                <span className="text-slate-500">AIP Index:</span>{' '}
                <strong className="text-slate-900">{lipid?.aip ?? '—'}</strong> ({lipid?.risk_category})
              </div>
              <div>
                <span className="text-slate-500">HOMA-IR:</span>{' '}
                <strong className="text-slate-900">{endo?.homa_ir ?? '—'}</strong> ({endo?.homa_ir_status?.split(' ')[0]})
              </div>
              <div>
                <span className="text-slate-500">De Ritis:</span>{' '}
                <strong className="text-slate-900">{liver?.de_ritis_ratio ?? '—'}</strong>
              </div>
              <div>
                <span className="text-slate-500">hs-CRP:</span>{' '}
                <strong className="text-slate-900">{inflam?.hs_crp ?? '—'} mg/L</strong>
              </div>
            </div>
          </div>

          {/* Section 1: Lipid Panel Table */}
          <div className="mt-6">
            <h3 className="border-b border-slate-300 pb-1 text-xs font-bold uppercase tracking-wider text-slate-900">
              1. Lipidemic Profile & Atherogenic Calculations
            </h3>
            <table className="mt-2 w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 font-semibold text-slate-500 text-[10px] uppercase">
                  <th className="py-1.5">Analyte</th>
                  <th className="py-1.5 font-mono">Value</th>
                  <th className="py-1.5">Units</th>
                  <th className="py-1.5">Reference Interval</th>
                  <th className="py-1.5 text-right">Flag</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono">
                <tr>
                  <td className="py-1.5 font-sans font-medium text-slate-900">Total Cholesterol</td>
                  <td className="py-1.5 font-bold text-slate-900">{lipid?.total_cholesterol ?? '—'}</td>
                  <td className="py-1.5 text-slate-500">mg/dL</td>
                  <td className="py-1.5 text-slate-500">125 – 200</td>
                  <td className="py-1.5 text-right">
                    {(lipid?.total_cholesterol ?? 0) > 200 ? <span className="text-rose-600 font-bold">HIGH</span> : 'NORMAL'}
                  </td>
                </tr>
                <tr>
                  <td className="py-1.5 font-sans font-medium text-slate-900">HDL Cholesterol</td>
                  <td className="py-1.5 font-bold text-slate-900">{lipid?.hdl ?? '—'}</td>
                  <td className="py-1.5 text-slate-500">mg/dL</td>
                  <td className="py-1.5 text-slate-500">40 – 90</td>
                  <td className="py-1.5 text-right">
                    {(lipid?.hdl ?? 0) < 40 ? <span className="text-amber-600 font-bold">LOW</span> : 'NORMAL'}
                  </td>
                </tr>
                <tr>
                  <td className="py-1.5 font-sans font-medium text-slate-900">
                    LDL Cholesterol ({lipid?.ldl_source === 'calculated' ? 'Calculated' : 'Reported'})
                  </td>
                  <td className="py-1.5 font-bold text-slate-900">{lipid?.ldl_final ?? '—'}</td>
                  <td className="py-1.5 text-slate-500">mg/dL</td>
                  <td className="py-1.5 text-slate-500">50 – 100</td>
                  <td className="py-1.5 text-right">
                    {(lipid?.ldl_final ?? 0) > 100 ? <span className="text-rose-600 font-bold">HIGH</span> : 'NORMAL'}
                  </td>
                </tr>
                <tr>
                  <td className="py-1.5 font-sans font-medium text-slate-900">Triglycerides</td>
                  <td className="py-1.5 font-bold text-slate-900">{lipid?.triglycerides ?? '—'}</td>
                  <td className="py-1.5 text-slate-500">mg/dL</td>
                  <td className="py-1.5 text-slate-500">40 – 150</td>
                  <td className="py-1.5 text-right">
                    {(lipid?.triglycerides ?? 0) > 150 ? <span className="text-rose-600 font-bold">HIGH</span> : 'NORMAL'}
                  </td>
                </tr>
                <tr>
                  <td className="py-1.5 font-sans font-medium text-slate-900">Non-HDL Cholesterol</td>
                  <td className="py-1.5 font-bold text-slate-900">{lipid?.non_hdl_final ?? '—'}</td>
                  <td className="py-1.5 text-slate-500">mg/dL</td>
                  <td className="py-1.5 text-slate-500">&lt; 130</td>
                  <td className="py-1.5 text-right">
                    {(lipid?.non_hdl_final ?? 0) > 130 ? <span className="text-rose-600 font-bold">HIGH</span> : 'NORMAL'}
                  </td>
                </tr>
                <tr>
                  <td className="py-1.5 font-sans font-medium text-slate-900">Remnant Cholesterol</td>
                  <td className="py-1.5 font-bold text-slate-900">{lipid?.remnant_cholesterol ?? '—'}</td>
                  <td className="py-1.5 text-slate-500">mg/dL</td>
                  <td className="py-1.5 text-slate-500">&lt; 24</td>
                  <td className="py-1.5 text-right">
                    {(lipid?.remnant_cholesterol ?? 0) > 24 ? <span className="text-rose-600 font-bold">HIGH</span> : 'NORMAL'}
                  </td>
                </tr>
                <tr>
                  <td className="py-1.5 font-sans font-medium text-slate-900">Atherogenic Index (AIP)</td>
                  <td className="py-1.5 font-bold text-slate-900">{lipid?.aip ?? '—'}</td>
                  <td className="py-1.5 text-slate-500">index</td>
                  <td className="py-1.5 text-slate-500">&lt; 0.11</td>
                  <td className="py-1.5 text-right">
                    {(lipid?.aip ?? 0) > 0.11 ? <span className="text-rose-600 font-bold">{lipid?.risk_category}</span> : 'OPTIMAL'}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Section 2: Endocrinology & Glycemic Dynamics */}
          <div className="mt-6">
            <h3 className="border-b border-slate-300 pb-1 text-xs font-bold uppercase tracking-wider text-slate-900">
              2. Endocrinology & Glycemic Dynamics
            </h3>
            <table className="mt-2 w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 font-semibold text-slate-500 text-[10px] uppercase">
                  <th className="py-1.5">Analyte</th>
                  <th className="py-1.5 font-mono">Value</th>
                  <th className="py-1.5">Units</th>
                  <th className="py-1.5">Reference Interval</th>
                  <th className="py-1.5 text-right">Flag</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono">
                <tr>
                  <td className="py-1.5 font-sans font-medium text-slate-900">Fasting Glucose</td>
                  <td className="py-1.5 font-bold text-slate-900">{endo?.glucose ?? '—'}</td>
                  <td className="py-1.5 text-slate-500">mg/dL</td>
                  <td className="py-1.5 text-slate-500">70 – 99</td>
                  <td className="py-1.5 text-right">
                    {(endo?.glucose ?? 0) > 99 ? <span className="text-rose-600 font-bold">HIGH</span> : 'NORMAL'}
                  </td>
                </tr>
                <tr>
                  <td className="py-1.5 font-sans font-medium text-slate-900">Fasting Insulin</td>
                  <td className="py-1.5 font-bold text-slate-900">{endo?.fasting_insulin ?? '—'}</td>
                  <td className="py-1.5 text-slate-500">uIU/mL</td>
                  <td className="py-1.5 text-slate-500">2.0 – 19.6</td>
                  <td className="py-1.5 text-right">
                    {(endo?.fasting_insulin ?? 0) > 15 ? <span className="text-rose-600 font-bold">HIGH</span> : 'NORMAL'}
                  </td>
                </tr>
                <tr>
                  <td className="py-1.5 font-sans font-medium text-slate-900">Hemoglobin A1c</td>
                  <td className="py-1.5 font-bold text-slate-900">{endo?.hba1c ?? '—'}</td>
                  <td className="py-1.5 text-slate-500">%</td>
                  <td className="py-1.5 text-slate-500">4.5 – 5.6</td>
                  <td className="py-1.5 text-right">
                    {(endo?.hba1c ?? 0) > 5.6 ? <span className="text-rose-600 font-bold">HIGH</span> : 'NORMAL'}
                  </td>
                </tr>
                <tr>
                  <td className="py-1.5 font-sans font-medium text-slate-900">HOMA-IR Score</td>
                  <td className="py-1.5 font-bold text-slate-900">{endo?.homa_ir ?? '—'}</td>
                  <td className="py-1.5 text-slate-500">index</td>
                  <td className="py-1.5 text-slate-500">&lt; 1.0 (Optimal)</td>
                  <td className="py-1.5 text-right">
                    {(endo?.homa_ir ?? 0) >= 2.0 ? <span className="text-rose-600 font-bold">HIGH IR</span> : 'NORMAL'}
                  </td>
                </tr>
                <tr>
                  <td className="py-1.5 font-sans font-medium text-slate-900">TSH</td>
                  <td className="py-1.5 font-bold text-slate-900">{endo?.tsh ?? '—'}</td>
                  <td className="py-1.5 text-slate-500">uIU/mL</td>
                  <td className="py-1.5 text-slate-500">0.45 – 4.50</td>
                  <td className="py-1.5 text-right">NORMAL</td>
                </tr>
                <tr>
                  <td className="py-1.5 font-sans font-medium text-slate-900">Free T4</td>
                  <td className="py-1.5 font-bold text-slate-900">{endo?.free_t4 ?? '—'}</td>
                  <td className="py-1.5 text-slate-500">ng/dL</td>
                  <td className="py-1.5 text-slate-500">0.82 – 1.77</td>
                  <td className="py-1.5 text-right">NORMAL</td>
                </tr>
                <tr>
                  <td className="py-1.5 font-sans font-medium text-slate-900">Vitamin D, 25-Hydroxy</td>
                  <td className="py-1.5 font-bold text-slate-900">{endo?.vitamin_d ?? '—'}</td>
                  <td className="py-1.5 text-slate-500">ng/mL</td>
                  <td className="py-1.5 text-slate-500">30 – 100</td>
                  <td className="py-1.5 text-right">
                    {(endo?.vitamin_d ?? 50) < 30 ? <span className="text-amber-600 font-bold">LOW</span> : 'NORMAL'}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Section 3: Hematology, Liver, & Iron */}
          <div className="mt-6">
            <h3 className="border-b border-slate-300 pb-1 text-xs font-bold uppercase tracking-wider text-slate-900">
              3. Hematology, Hepatic Function & Systemic Inflammation
            </h3>
            <table className="mt-2 w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 font-semibold text-slate-500 text-[10px] uppercase">
                  <th className="py-1.5">Analyte</th>
                  <th className="py-1.5 font-mono">Value</th>
                  <th className="py-1.5">Units</th>
                  <th className="py-1.5">Reference Interval</th>
                  <th className="py-1.5 text-right">Flag</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono">
                <tr>
                  <td className="py-1.5 font-sans font-medium text-slate-900">Hemoglobin</td>
                  <td className="py-1.5 font-bold text-slate-900">{cbc?.hemoglobin ?? '—'}</td>
                  <td className="py-1.5 text-slate-500">g/dL</td>
                  <td className="py-1.5 text-slate-500">13.5 – 17.5</td>
                  <td className="py-1.5 text-right">NORMAL</td>
                </tr>
                <tr>
                  <td className="py-1.5 font-sans font-medium text-slate-900">WBC Count</td>
                  <td className="py-1.5 font-bold text-slate-900">{cbc?.wbc ?? '—'}</td>
                  <td className="py-1.5 text-slate-500">K/uL</td>
                  <td className="py-1.5 text-slate-500">4.0 – 11.0</td>
                  <td className="py-1.5 text-right">NORMAL</td>
                </tr>
                <tr>
                  <td className="py-1.5 font-sans font-medium text-slate-900">ALT (SGPT)</td>
                  <td className="py-1.5 font-bold text-slate-900">{liver?.alt ?? '—'}</td>
                  <td className="py-1.5 text-slate-500">U/L</td>
                  <td className="py-1.5 text-slate-500">7 – 45</td>
                  <td className="py-1.5 text-right">
                    {(liver?.alt ?? 0) > 45 ? <span className="text-rose-600 font-bold">HIGH</span> : 'NORMAL'}
                  </td>
                </tr>
                <tr>
                  <td className="py-1.5 font-sans font-medium text-slate-900">AST (SGOT)</td>
                  <td className="py-1.5 font-bold text-slate-900">{liver?.ast ?? '—'}</td>
                  <td className="py-1.5 text-slate-500">U/L</td>
                  <td className="py-1.5 text-slate-500">8 – 40</td>
                  <td className="py-1.5 text-right">
                    {(liver?.ast ?? 0) > 40 ? <span className="text-rose-600 font-bold">HIGH</span> : 'NORMAL'}
                  </td>
                </tr>
                <tr>
                  <td className="py-1.5 font-sans font-medium text-slate-900">De Ritis Ratio (AST/ALT)</td>
                  <td className="py-1.5 font-bold text-slate-900">{liver?.de_ritis_ratio ?? '—'}</td>
                  <td className="py-1.5 text-slate-500">ratio</td>
                  <td className="py-1.5 text-slate-500">&lt; 1.0 (Metabolic)</td>
                  <td className="py-1.5 text-right">NORMAL</td>
                </tr>
                <tr>
                  <td className="py-1.5 font-sans font-medium text-slate-900">Ferritin (Iron Stores)</td>
                  <td className="py-1.5 font-bold text-slate-900">{iron?.ferritin ?? '—'}</td>
                  <td className="py-1.5 text-slate-500">ng/mL</td>
                  <td className="py-1.5 text-slate-500">30 – 300</td>
                  <td className="py-1.5 text-right">
                    {(iron?.ferritin ?? 100) < 30 ? <span className="text-amber-600 font-bold">LOW</span> : 'NORMAL'}
                  </td>
                </tr>
                <tr>
                  <td className="py-1.5 font-sans font-medium text-slate-900">hs-CRP (Inflammation)</td>
                  <td className="py-1.5 font-bold text-slate-900">{inflam?.hs_crp ?? '—'}</td>
                  <td className="py-1.5 text-slate-500">mg/L</td>
                  <td className="py-1.5 text-slate-500">&lt; 1.0 (Low CVD Risk)</td>
                  <td className="py-1.5 text-right">
                    {(inflam?.hs_crp ?? 0) > 3.0 ? <span className="text-rose-600 font-bold">HIGH</span> : 'NORMAL'}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Legal and Sign-off */}
          <div className="mt-8 border-t border-slate-200 pt-4 text-[11px] text-slate-400">
            <div className="flex flex-wrap items-center justify-between">
              <div>
                Certified Medical Laboratory Director: <strong>Aris Thorne, MD, PhD, FCAP</strong>
              </div>
              <div className="font-mono">
                Verification Token: SHA256-CLINICAL-{exam.id.slice(0, 8)}
              </div>
            </div>
            <div className="mt-1 text-[10px]">
              CONFIDENTIAL HEALTH DOCUMENT: This document contains protected health information (PHI) subject to HIPAA regulations.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
