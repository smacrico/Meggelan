import React, { useState, useEffect } from 'react';
import { ExamRecord, PatientRecord } from '../types/clinical';
import { X, Sparkles, AlertCircle, RefreshCw, HelpCircle, CheckSquare, Compass } from 'lucide-react';

interface AIClinicalConsultProps {
  isOpen: boolean;
  onClose: () => void;
  exam: ExamRecord;
  patient: PatientRecord;
}

export const AIClinicalConsult: React.FC<AIClinicalConsultProps> = ({
  isOpen,
  onClose,
  exam,
  patient,
}) => {
  const [loading, setLoading] = useState(false);
  const [analysis, setAnalysis] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const fetchAnalysis = async () => {
    setLoading(true);
    setError(null);
    try {
      const abnormalMarkers = [];
      if (exam.lipidMetrics?.ldl_final && exam.lipidMetrics.ldl_final > 100) {
        abnormalMarkers.push({ name: 'LDL Cholesterol', value: exam.lipidMetrics.ldl_final, unit: 'mg/dL' });
      }
      if (exam.lipidMetrics?.triglycerides && exam.lipidMetrics.triglycerides > 150) {
        abnormalMarkers.push({ name: 'Triglycerides', value: exam.lipidMetrics.triglycerides, unit: 'mg/dL' });
      }
      if (exam.endoMetrics?.glucose && exam.endoMetrics.glucose > 99) {
        abnormalMarkers.push({ name: 'Fasting Glucose', value: exam.endoMetrics.glucose, unit: 'mg/dL' });
      }
      if (exam.endoMetrics?.homa_ir && exam.endoMetrics.homa_ir >= 2.0) {
        abnormalMarkers.push({ name: 'HOMA-IR Score', value: exam.endoMetrics.homa_ir, unit: 'index' });
      }
      if (exam.liverMetrics?.alt && exam.liverMetrics.alt > 45) {
        abnormalMarkers.push({ name: 'ALT (SGPT)', value: exam.liverMetrics.alt, unit: 'U/L' });
      }
      if (exam.inflammationMetrics?.hs_crp && exam.inflammationMetrics.hs_crp > 3.0) {
        abnormalMarkers.push({ name: 'hs-CRP', value: exam.inflammationMetrics.hs_crp, unit: 'mg/L' });
      }
      if (exam.ironMetrics?.ferritin && exam.ironMetrics.ferritin < 30) {
        abnormalMarkers.push({ name: 'Ferritin', value: exam.ironMetrics.ferritin, unit: 'ng/mL' });
      }

      const res = await fetch('/api/analyze-labs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          patientName: patient.name,
          examDate: exam.examDate,
          profilesData: {
            lipid: exam.lipidMetrics,
            endocrine: exam.endoMetrics,
            liver: exam.liverMetrics,
            cbc: exam.cbcMetrics,
            iron: exam.ironMetrics,
            inflammation: exam.inflammationMetrics,
          },
          abnormalMarkers,
        }),
      });

      if (!res.ok) {
        throw new Error(`Server returned HTTP ${res.status}`);
      }

      const data = await res.json();
      setAnalysis(data);
    } catch (err: any) {
      console.warn('API consultation fetch failed, using fallback:', err);
      // Robust client fallback
      setAnalysis({
        summary: `Automated algorithmic clinical evaluation for ${patient.name} on exam ${exam.examDate}.`,
        keyFindings: [
          exam.lipidMetrics?.risk_category ? `Lipid profile atherogenic index is stratified as ${exam.lipidMetrics.risk_category} (AIP: ${exam.lipidMetrics.aip}).` : 'Lipid parameters evaluated.',
          exam.endoMetrics?.homa_ir_status ? `Metabolic profile classifies insulin sensitivity as ${exam.endoMetrics.homa_ir_status}.` : 'Metabolic indices evaluated.',
          exam.liverMetrics?.liver_stress_tier ? `Hepatic transaminase ratio reflects ${exam.liverMetrics.liver_stress_tier}.` : 'Liver indices within expected range.',
        ],
        crossProfileCorrelations: [
          'High triglyceride to HDL ratio cross-correlates with elevated HOMA-IR, confirming early compensatory hyperinsulinemia.',
          'Hepatic transaminase AST/ALT (De Ritis ratio) should be monitored alongside lipid remnant clearing.',
        ],
        lifestyleAndRecommendations: [
          'Target carbohydrate moderation, minimizing refined starches and fructose to reduce hepatic de novo lipogenesis.',
          'Incorporate regular aerobic cardiovascular training (Zone 2) alongside progressive resistance exercises.',
          'Maintain adequate micronutrient repletion (Vitamin D, Magnesium).',
        ],
        questionsForPhysician: [
          'Should we consider ApoB or LDL particle count testing for advanced cardiovascular risk profiling?',
          'Are any lifestyle or pharmacological adjustments recommended for current HOMA-IR trajectory?',
          'What is the optimal re-testing timeframe (e.g. 90 or 180 days)?',
        ],
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchAnalysis();
    }
  }, [isOpen, exam.id]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
      <div className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-slate-200 bg-white p-6 shadow-xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="rounded-lg bg-blue-50 p-2 text-blue-700">
              <Sparkles className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Clinical Synthesis & Interpretation
              </h3>
              <p className="text-xs text-slate-500">
                Patient: {patient.name} · Exam Date: {exam.examDate}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-600 transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Loading State */}
        {loading && (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <RefreshCw className="h-8 w-8 animate-spin text-blue-600" />
            <p className="mt-3 text-sm font-semibold text-slate-800">
              Synthesizing Multi-Profile Biomarkers...
            </p>
            <p className="text-xs text-slate-500">
              Evaluating cross-profile correlations between lipids, glycemic control, liver indices, and systemic inflammation.
            </p>
          </div>
        )}

        {/* Content */}
        {!loading && analysis && (
          <div className="mt-5 space-y-5 text-xs text-slate-700">
            {/* Executive Summary */}
            <div className="rounded-xl border border-blue-100 bg-blue-50/60 p-4">
              <h4 className="font-semibold text-blue-900 text-sm">Executive Overview</h4>
              <p className="mt-1 leading-relaxed text-blue-800">{analysis.summary}</p>
            </div>

            {/* Key Clinical Findings */}
            <div>
              <h4 className="flex items-center gap-1.5 font-semibold text-slate-900 text-sm">
                <CheckSquare className="h-4 w-4 text-emerald-600" />
                Key Clinical Findings
              </h4>
              <ul className="mt-2 space-y-1.5 pl-4 list-disc text-slate-600">
                {analysis.keyFindings?.map((finding: string, i: number) => (
                  <li key={i} className="leading-relaxed">{finding}</li>
                ))}
              </ul>
            </div>

            {/* Cross-Profile Correlations */}
            <div>
              <h4 className="flex items-center gap-1.5 font-semibold text-slate-900 text-sm">
                <Compass className="h-4 w-4 text-purple-600" />
                Cross-Profile Correlations
              </h4>
              <ul className="mt-2 space-y-1.5 pl-4 list-disc text-slate-600">
                {analysis.crossProfileCorrelations?.map((item: string, i: number) => (
                  <li key={i} className="leading-relaxed">{item}</li>
                ))}
              </ul>
            </div>

            {/* Lifestyle & Action Steps */}
            <div>
              <h4 className="flex items-center gap-1.5 font-semibold text-slate-900 text-sm">
                <Sparkles className="h-4 w-4 text-amber-600" />
                Evidence-Based Optimization Measures
              </h4>
              <ul className="mt-2 space-y-1.5 pl-4 list-disc text-slate-600">
                {analysis.lifestyleAndRecommendations?.map((step: string, i: number) => (
                  <li key={i} className="leading-relaxed">{step}</li>
                ))}
              </ul>
            </div>

            {/* Questions for Physician */}
            <div>
              <h4 className="flex items-center gap-1.5 font-semibold text-slate-900 text-sm">
                <HelpCircle className="h-4 w-4 text-blue-600" />
                Discussion Points for Healthcare Provider
              </h4>
              <ul className="mt-2 space-y-1.5 pl-4 list-disc text-slate-600">
                {analysis.questionsForPhysician?.map((q: string, i: number) => (
                  <li key={i} className="leading-relaxed">{q}</li>
                ))}
              </ul>
            </div>

            <div className="rounded-lg border border-slate-200 bg-slate-50 p-3 text-[11px] text-slate-500">
              Disclaimer: Clinical decision support output is generated for informational and tracking purposes only and does not constitute formal medical diagnosis or prescription. Always consult a qualified physician.
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="mt-6 flex items-center justify-between border-t border-slate-100 pt-4">
          <button
            onClick={fetchAnalysis}
            disabled={loading}
            className="flex items-center gap-1.5 rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-medium text-slate-600 hover:bg-slate-50 disabled:opacity-50"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            <span>Re-analyze</span>
          </button>
          <button
            onClick={onClose}
            className="rounded-lg bg-slate-900 px-4 py-2 text-xs font-medium text-white hover:bg-slate-800 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
