import React from 'react';
import { ExamRecord, PatientRecord } from '../types/clinical';
import { VisualizerChart } from './VisualizerChart';
import { round2 } from '../lib/clinicalCalculations';
import { AlertCircle, TrendingDown, TrendingUp, Sparkles, Calendar, User, FileText, FileDown } from 'lucide-react';

interface ExecutiveSummaryProps {
  currentExam: ExamRecord;
  allExams: ExamRecord[];
  patient: PatientRecord;
  allPatients: PatientRecord[];
  onSelectPatient: (patientId: string) => void;
  onSelectExam: (examId: string) => void;
  onNavigateTab: (tab: string) => void;
  onOpenAIModal: () => void;
  onOpenReportModal: () => void;
}

export const ExecutiveSummary: React.FC<ExecutiveSummaryProps> = ({
  currentExam,
  allExams,
  patient,
  allPatients,
  onSelectPatient,
  onSelectExam,
  onNavigateTab,
  onOpenAIModal,
  onOpenReportModal,
}) => {
  const { lipidMetrics, endoMetrics, liverMetrics, inflammationMetrics, ironMetrics, cbcMetrics } = currentExam;

  // Identify abnormal markers in current exam
  const abnormalAlerts: Array<{
    name: string;
    value: string;
    category: string;
    refRange: string;
    status: string;
    isHigh: boolean;
  }> = [];

  if (lipidMetrics?.total_cholesterol && lipidMetrics.total_cholesterol > 200) {
    abnormalAlerts.push({
      name: 'Total Cholesterol',
      value: `${lipidMetrics.total_cholesterol} mg/dL`,
      category: 'Lipidemic',
      refRange: '125 - 200 mg/dL',
      status: 'High',
      isHigh: true,
    });
  }
  if (lipidMetrics?.ldl_final && lipidMetrics.ldl_final > 100) {
    abnormalAlerts.push({
      name: 'LDL Cholesterol',
      value: `${lipidMetrics.ldl_final} mg/dL`,
      category: 'Lipidemic',
      refRange: '< 100 mg/dL',
      status: 'High',
      isHigh: true,
    });
  }
  if (lipidMetrics?.triglycerides && lipidMetrics.triglycerides > 150) {
    abnormalAlerts.push({
      name: 'Triglycerides',
      value: `${lipidMetrics.triglycerides} mg/dL`,
      category: 'Lipidemic',
      refRange: '< 150 mg/dL',
      status: 'High',
      isHigh: true,
    });
  }
  if (endoMetrics?.glucose && endoMetrics.glucose > 99) {
    abnormalAlerts.push({
      name: 'Fasting Glucose',
      value: `${endoMetrics.glucose} mg/dL`,
      category: 'Endocrinology',
      refRange: '70 - 99 mg/dL',
      status: 'Impaired Fasting',
      isHigh: true,
    });
  }
  if (endoMetrics?.homa_ir && endoMetrics.homa_ir >= 2.0) {
    abnormalAlerts.push({
      name: 'HOMA-IR Insulin Resistance',
      value: `${endoMetrics.homa_ir}`,
      category: 'Endocrinology',
      refRange: '< 1.0 Optimal',
      status: 'Elevated IR',
      isHigh: true,
    });
  }
  if (liverMetrics?.alt && liverMetrics.alt > 45) {
    abnormalAlerts.push({
      name: 'ALT (SGPT)',
      value: `${liverMetrics.alt} U/L`,
      category: 'Liver',
      refRange: '7 - 45 U/L',
      status: 'Elevated',
      isHigh: true,
    });
  }
  if (inflammationMetrics?.hs_crp && inflammationMetrics.hs_crp > 3.0) {
    abnormalAlerts.push({
      name: 'hs-CRP (Inflammation)',
      value: `${inflammationMetrics.hs_crp} mg/L`,
      category: 'Inflammation',
      refRange: '< 1.0 mg/L',
      status: 'High CVD Risk',
      isHigh: true,
    });
  }
  if (ironMetrics?.ferritin && ironMetrics.ferritin < 30) {
    abnormalAlerts.push({
      name: 'Ferritin',
      value: `${ironMetrics.ferritin} ng/mL`,
      category: 'Iron Profile',
      refRange: '30 - 300 ng/mL',
      status: 'Deficient',
      isHigh: false,
    });
  }
  if (endoMetrics?.vitamin_d && endoMetrics.vitamin_d < 30) {
    abnormalAlerts.push({
      name: 'Vitamin D (25-OH)',
      value: `${endoMetrics.vitamin_d} ng/mL`,
      category: 'Nutritional',
      refRange: '30 - 100 ng/mL',
      status: 'Insufficient',
      isHigh: false,
    });
  }

  // Build longitudinal series for summary charts
  const patientExamsSorted = [...allExams]
    .filter((e) => e.patientId === patient.id)
    .sort((a, b) => new Date(a.examDate).getTime() - new Date(b.examDate).getTime());

  const ldlSeries = {
    id: 'ldl',
    label: 'LDL Cholesterol',
    color: '#DC2626',
    unit: 'mg/dL',
    data: patientExamsSorted.map((e) => ({
      date: e.examDate,
      value: e.lipidMetrics?.ldl_final ?? null,
    })),
    refHigh: 100,
    optimalHigh: 70,
  };

  const hdlSeries = {
    id: 'hdl',
    label: 'HDL Cholesterol',
    color: '#059669',
    unit: 'mg/dL',
    data: patientExamsSorted.map((e) => ({
      date: e.examDate,
      value: e.lipidMetrics?.hdl ?? null,
    })),
    refLow: 40,
    optimalLow: 50,
  };

  const homaSeries = {
    id: 'homa',
    label: 'HOMA-IR Score',
    color: '#D97706',
    unit: 'index',
    data: patientExamsSorted.map((e) => ({
      date: e.examDate,
      value: e.endoMetrics?.homa_ir ?? null,
    })),
    refHigh: 2.0,
    optimalHigh: 1.0,
  };

  const glucoseSeries = {
    id: 'glucose',
    label: 'Fasting Glucose',
    color: '#2563EB',
    unit: 'mg/dL',
    data: patientExamsSorted.map((e) => ({
      date: e.examDate,
      value: e.endoMetrics?.glucose ?? null,
    })),
    refHigh: 99,
    optimalHigh: 88,
  };

  return (
    <div className="space-y-6">
      {/* Patient & Exam Selector Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
        <div className="flex flex-wrap items-center gap-6">
          {/* Patient Selector */}
          <div className="flex items-center gap-2.5">
            <User className="h-4 w-4 text-slate-400" />
            <div>
              <div className="text-[10px] font-medium uppercase tracking-wider text-slate-400">
                Active Cohort
              </div>
              <select
                value={patient.id}
                onChange={(e) => onSelectPatient(e.target.value)}
                className="font-medium text-slate-900 bg-transparent text-sm focus:outline-hidden cursor-pointer"
              >
                {allPatients.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.gender}, {p.age}y)
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="hidden h-8 w-px bg-slate-200 sm:block" />

          {/* Exam Date Selector */}
          <div className="flex items-center gap-2.5">
            <Calendar className="h-4 w-4 text-slate-400" />
            <div>
              <div className="text-[10px] font-medium uppercase tracking-wider text-slate-400">
                Exam Record
              </div>
              <select
                value={currentExam.id}
                onChange={(e) => onSelectExam(e.target.value)}
                className="font-mono text-xs font-semibold text-slate-900 bg-transparent focus:outline-hidden cursor-pointer tabular-nums"
              >
                {patientExamsSorted.map((e) => (
                  <option key={e.id} value={e.id}>
                    {e.examDate} · {e.labFacility}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="hidden h-8 w-px bg-slate-200 sm:block" />

          {/* Facility & Metadata */}
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <FileText className="h-4 w-4 text-slate-400" />
            <span>{currentExam.labFacility}</span>
            <span aria-hidden="true">·</span>
            <span>{currentExam.rawTestEntries.length} Ingested Analytes</span>
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={onOpenReportModal}
            className="flex items-center gap-2 rounded-lg bg-slate-900 px-3.5 py-1.5 text-xs font-semibold text-white shadow-2xs hover:bg-slate-800 transition-colors"
          >
            <FileDown className="h-3.5 w-3.5" />
            <span>Generate Clinical PDF</span>
          </button>

          <button
            onClick={onOpenAIModal}
            className="flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-3.5 py-1.5 text-xs font-semibold text-slate-800 shadow-2xs hover:bg-slate-50 hover:border-slate-400 transition-colors"
          >
            <Sparkles className="h-3.5 w-3.5 text-blue-600" />
            <span>Clinical Insights</span>
          </button>
        </div>
      </div>

      {/* 4 Core Clinical Radar Cards */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4">
        {/* CARD 1: Lipid / Cardiovascular */}
        <div
          onClick={() => onNavigateTab('lipid')}
          className="cursor-pointer rounded-xl border border-slate-200 bg-white p-4 transition-all hover:border-slate-300 hover:shadow-sm"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Atherogenic Risk (AIP)</span>
            <span className="font-mono text-[11px] text-slate-400">LIPIDEMIC</span>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="font-mono text-2xl font-bold text-slate-900 tabular-nums">
              {lipidMetrics?.aip !== null ? lipidMetrics?.aip : '—'}
            </span>
            <span className="text-xs font-medium text-slate-500">
              {lipidMetrics?.risk_category}
            </span>
          </div>
          <div className="mt-3 flex items-center justify-between border-t border-slate-100 pt-2 text-xs text-slate-500">
            <span>LDL: <strong className="font-mono text-slate-800">{lipidMetrics?.ldl_final ?? '—'}</strong></span>
            <span>HDL: <strong className="font-mono text-slate-800">{lipidMetrics?.hdl ?? '—'}</strong></span>
            <span>TG: <strong className="font-mono text-slate-800">{lipidMetrics?.triglycerides ?? '—'}</strong></span>
          </div>
        </div>

        {/* CARD 2: Endocrinology / Insulin Resistance */}
        <div
          onClick={() => onNavigateTab('endo')}
          className="cursor-pointer rounded-xl border border-slate-200 bg-white p-4 transition-all hover:border-slate-300 hover:shadow-sm"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">HOMA-IR Score</span>
            <span className="font-mono text-[11px] text-slate-400">METABOLIC</span>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="font-mono text-2xl font-bold text-slate-900 tabular-nums">
              {endoMetrics?.homa_ir !== null ? endoMetrics?.homa_ir : '—'}
            </span>
            <span className="text-xs font-medium text-slate-500">
              {endoMetrics?.homa_ir && endoMetrics.homa_ir < 1.0 ? 'Optimal' : endoMetrics?.homa_ir && endoMetrics.homa_ir < 2.0 ? 'Early IR' : 'Significant IR'}
            </span>
          </div>
          <div className="mt-3 flex items-center justify-between border-t border-slate-100 pt-2 text-xs text-slate-500">
            <span>Glucose: <strong className="font-mono text-slate-800">{endoMetrics?.glucose ?? '—'}</strong></span>
            <span>HbA1c: <strong className="font-mono text-slate-800">{endoMetrics?.hba1c ?? '—'}%</strong></span>
            <span>QUICKI: <strong className="font-mono text-slate-800">{endoMetrics?.quicki ?? '—'}</strong></span>
          </div>
        </div>

        {/* CARD 3: Hepatic & Organ Reserve */}
        <div
          onClick={() => onNavigateTab('organs')}
          className="cursor-pointer rounded-xl border border-slate-200 bg-white p-4 transition-all hover:border-slate-300 hover:shadow-sm"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">De Ritis Ratio (AST/ALT)</span>
            <span className="font-mono text-[11px] text-slate-400">LIVER</span>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="font-mono text-2xl font-bold text-slate-900 tabular-nums">
              {liverMetrics?.de_ritis_ratio !== null ? liverMetrics?.de_ritis_ratio : '—'}
            </span>
            <span className="text-xs font-medium text-slate-500">
              {liverMetrics?.liver_stress_tier}
            </span>
          </div>
          <div className="mt-3 flex items-center justify-between border-t border-slate-100 pt-2 text-xs text-slate-500">
            <span>ALT: <strong className="font-mono text-slate-800">{liverMetrics?.alt ?? '—'}</strong></span>
            <span>AST: <strong className="font-mono text-slate-800">{liverMetrics?.ast ?? '—'}</strong></span>
            <span>GGT: <strong className="font-mono text-slate-800">{liverMetrics?.ggt ?? '—'}</strong></span>
          </div>
        </div>

        {/* CARD 4: Immune & Systemic Inflammation */}
        <div
          onClick={() => onNavigateTab('cbc')}
          className="cursor-pointer rounded-xl border border-slate-200 bg-white p-4 transition-all hover:border-slate-300 hover:shadow-sm"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Inflammation & Immune</span>
            <span className="font-mono text-[11px] text-slate-400">IMMUNE</span>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="font-mono text-2xl font-bold text-slate-900 tabular-nums">
              {inflammationMetrics?.hs_crp !== null ? `${inflammationMetrics?.hs_crp} mg/L` : '—'}
            </span>
            <span className="text-xs font-medium text-slate-500">
              {inflammationMetrics?.cvd_risk_tier?.split(' ')[0] ?? 'Nominal'}
            </span>
          </div>
          <div className="mt-3 flex items-center justify-between border-t border-slate-100 pt-2 text-xs text-slate-500">
            <span>NLR: <strong className="font-mono text-slate-800">{cbcMetrics?.nlr ?? '—'}</strong></span>
            <span>ESR: <strong className="font-mono text-slate-800">{inflammationMetrics?.esr ?? '—'}</strong></span>
            <span>WBC: <strong className="font-mono text-slate-800">{cbcMetrics?.wbc ?? '—'}</strong></span>
          </div>
        </div>
      </div>

      {/* Active Abnormal Alerts List */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertCircle className="h-4 w-4 text-amber-500" />
            <h3 className="text-sm font-semibold text-slate-900">
              Clinical Variance Audit · Exam {currentExam.examDate}
            </h3>
          </div>
          <span className="text-xs text-slate-500">
            {abnormalAlerts.length === 0
              ? 'All target biomarkers within reference limits'
              : `${abnormalAlerts.length} marker(s) outside target ranges`}
          </span>
        </div>

        {abnormalAlerts.length > 0 ? (
          <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {abnormalAlerts.map((alert, i) => (
              <div
                key={i}
                className="flex items-start justify-between rounded-lg border border-slate-200 bg-slate-50/60 p-3"
              >
                <div>
                  <div className="text-xs font-semibold text-slate-900">{alert.name}</div>
                  <div className="text-[11px] text-slate-500">
                    Ref: {alert.refRange} · {alert.category}
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-mono text-xs font-bold text-slate-900 tabular-nums">
                    {alert.value}
                  </div>
                  <div
                    className={`flex items-center justify-end gap-1 text-[10px] font-medium ${
                      alert.isHigh ? 'text-rose-600' : 'text-amber-600'
                    }`}
                  >
                    {alert.isHigh ? (
                      <TrendingUp className="h-3 w-3" />
                    ) : (
                      <TrendingDown className="h-3 w-3" />
                    )}
                    <span>{alert.status}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="mt-4 rounded-lg border border-dashed border-emerald-200 bg-emerald-50/50 p-4 text-center text-xs text-emerald-800">
            Nominal Laboratory Profile: No critical out-of-range deviations detected for this exam date.
          </div>
        )}
      </div>

      {/* Longitudinal Trajectory Charts (Lipid vs Endocrine) */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <VisualizerChart
          title="Longitudinal Lipid Particles & Ratios"
          subtitle="Direct tracking of LDL-C and HDL-C over multiple years"
          series={[ldlSeries, hdlSeries]}
        />
        <VisualizerChart
          title="Longitudinal Glycemic & Insulin Dynamics"
          subtitle="HOMA-IR score and Fasting Blood Glucose trends"
          series={[homaSeries, glucoseSeries]}
        />
      </div>

      {/* Clinical Notes & Legacy Bridge Summary */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
        <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
          Clinical Notes & ETL Audit Summary
        </h4>
        <p className="mt-2 text-sm text-slate-700 leading-relaxed">
          {currentExam.notes || 'No specialized physician comments recorded for this exam.'}
        </p>
        <div className="mt-3 flex flex-wrap items-center gap-4 text-xs text-slate-500 border-t border-slate-100 pt-3">
          <span>Source File: <strong className="font-mono text-slate-700">{currentExam.sourceFile || 'Direct Import'}</strong></span>
          <span aria-hidden="true">·</span>
          <span>Ordering Clinician: <strong className="text-slate-700">{currentExam.orderingPhysician || 'Unspecified'}</strong></span>
          <span aria-hidden="true">·</span>
          <span>ETL Status: <span className="font-medium text-emerald-700">Validated & Computed</span></span>
        </div>
      </div>
    </div>
  );
};
