import React, { useState } from 'react';
import { ExamRecord, PatientRecord } from '../types/clinical';
import { buildExamRecord } from '../lib/sampleData';
import { X, Plus, Calculator, CheckCircle2 } from 'lucide-react';
import { round2 } from '../lib/clinicalCalculations';

interface AddExamModalProps {
  isOpen: boolean;
  onClose: () => void;
  patients: PatientRecord[];
  activePatientId: string;
  onAddSuccess: (newExam: ExamRecord) => void;
}

export const AddExamModal: React.FC<AddExamModalProps> = ({
  isOpen,
  onClose,
  patients,
  activePatientId,
  onAddSuccess,
}) => {
  const [patientId, setPatientId] = useState(activePatientId);
  const [examDate, setExamDate] = useState(new Date().toISOString().split('T')[0]);
  const [labFacility, setLabFacility] = useState('Metro Clinical Lab');
  const [orderingPhysician, setOrderingPhysician] = useState('Dr. Primary Care, MD');
  const [notes, setNotes] = useState('Routine surveillance exam.');

  // Form values
  const [tc, setTc] = useState<string>('180');
  const [hdl, setHdl] = useState<string>('50');
  const [ldl, setLdl] = useState<string>('100');
  const [tg, setTg] = useState<string>('120');

  const [glucose, setGlucose] = useState<string>('90');
  const [insulin, setInsulin] = useState<string>('6.5');
  const [hba1c, setHba1c] = useState<string>('5.2');
  const [tsh, setTsh] = useState<string>('1.8');
  const [ft4, setFt4] = useState<string>('1.3');
  const [vitD, setVitD] = useState<string>('45');

  const [alt, setAlt] = useState<string>('24');
  const [ast, setAst] = useState<string>('22');
  const [ggt, setGgt] = useState<string>('20');

  const [hscrp, setHscrp] = useState<string>('1.0');
  const [ferritin, setFerritin] = useState<string>('140');
  const [hgb, setHgb] = useState<string>('15.2');
  const [wbc, setWbc] = useState<string>('6.2');
  const [plt, setPlt] = useState<string>('240');

  if (!isOpen) return null;

  // Live calculations
  const numTc = parseFloat(tc);
  const numHdl = parseFloat(hdl);
  const numTg = parseFloat(tg);
  const numLdl = parseFloat(ldl);

  const calcLdl = (!isNaN(numTc) && !isNaN(numHdl) && !isNaN(numTg) && numTg < 400)
    ? round2(numTc - numHdl - numTg / 5)
    : null;

  const numGluc = parseFloat(glucose);
  const numIns = parseFloat(insulin);
  const calcHoma = (!isNaN(numGluc) && !isNaN(numIns) && numGluc > 0 && numIns > 0)
    ? round2((numGluc * numIns) / 405)
    : null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const parseOrNull = (v: string) => {
      const n = parseFloat(v);
      return isNaN(n) ? null : n;
    };

    const newRecord = buildExamRecord({
      id: `exam-custom-${Date.now()}`,
      patientId,
      examDate,
      labFacility,
      orderingPhysician,
      sourceType: 'manual',
      sourceFile: 'Manual_Clinical_Entry',
      notes,
      lipid: {
        exam_date: examDate,
        total_cholesterol: parseOrNull(tc),
        hdl: parseOrNull(hdl),
        ldl: parseOrNull(ldl),
        triglycerides: parseOrNull(tg),
      },
      endo: {
        exam_date: examDate,
        glucose_for_calc: parseOrNull(glucose),
        fasting_insulin: parseOrNull(insulin),
        hba1c: parseOrNull(hba1c),
        tsh: parseOrNull(tsh),
        free_t4: parseOrNull(ft4),
        vitamin_d: parseOrNull(vitD),
      },
      cbc: {
        exam_date: examDate,
        wbc: parseOrNull(wbc),
        rbc: 4.8,
        hemoglobin: parseOrNull(hgb),
        hematocrit: 44.0,
        platelets: parseOrNull(plt),
        mcv: 88.0,
        mch: 30.0,
        mchc: 34.0,
        rdw: 12.5,
        neutrophils_pct: 60,
        lymphocytes_pct: 30,
        monocytes_pct: 6,
        eosinophils_pct: 3,
        basophils_pct: 1,
      },
      liver: {
        exam_date: examDate,
        alt: parseOrNull(alt),
        ast: parseOrNull(ast),
        alp: 65,
        ggt: parseOrNull(ggt),
        total_bilirubin: 0.6,
        direct_bilirubin: 0.1,
        albumin: 4.5,
        total_protein: 7.0,
      },
      iron: {
        exam_date: examDate,
        serum_iron: 105,
        ferritin: parseOrNull(ferritin),
        tibc: 330,
        uibc: 225,
      },
      inflammation: {
        exam_date: examDate,
        hs_crp: parseOrNull(hscrp),
        esr: 10,
        ferritin: parseOrNull(ferritin),
      },
      vitamins: {
        exam_date: examDate,
        vitamin_b12: 500,
        folate: 8.0,
        vitamin_d: parseOrNull(vitD),
        magnesium: 2.2,
        zinc: 90,
        calcium: 9.4,
      },
    });

    onAddSuccess(newRecord);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
      <div className="max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-slate-200 bg-white p-6 shadow-xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="rounded-lg bg-emerald-50 p-2 text-emerald-700">
              <Plus className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Record New Blood Test Exam
              </h3>
              <p className="text-xs text-slate-500">
                Enter lab values with real-time recalculation of Friedewald LDL, AIP, and HOMA-IR.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-600 transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-5 space-y-5 text-xs">
          {/* Metadata Row */}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <div>
              <label className="font-medium text-slate-700">Patient</label>
              <select
                value={patientId}
                onChange={(e) => setPatientId(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 bg-white p-2 text-xs"
              >
                {patients.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="font-medium text-slate-700">Exam Date</label>
              <input
                type="date"
                required
                value={examDate}
                onChange={(e) => setExamDate(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 bg-white p-2 font-mono text-xs"
              />
            </div>

            <div>
              <label className="font-medium text-slate-700">Laboratory Facility</label>
              <input
                type="text"
                value={labFacility}
                onChange={(e) => setLabFacility(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 bg-white p-2 text-xs"
              />
            </div>
          </div>

          {/* Section 1: Lipid Panel */}
          <div className="rounded-xl border border-slate-200 bg-slate-50/50 p-4">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-900 text-xs uppercase tracking-wider">
                1. Lipidemic Profile (mg/dL)
              </span>
              {calcLdl !== null && (
                <span className="font-mono text-[11px] text-blue-700">
                  Friedewald Calc LDL: <strong>{calcLdl} mg/dL</strong>
                </span>
              )}
            </div>

            <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-4">
              <div>
                <label className="text-slate-500">Total Chol</label>
                <input
                  type="number"
                  step="any"
                  value={tc}
                  onChange={(e) => setTc(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-slate-200 bg-white p-2 font-mono text-xs"
                />
              </div>
              <div>
                <label className="text-slate-500">HDL Chol</label>
                <input
                  type="number"
                  step="any"
                  value={hdl}
                  onChange={(e) => setHdl(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-slate-200 bg-white p-2 font-mono text-xs"
                />
              </div>
              <div>
                <label className="text-slate-500">LDL Reported</label>
                <input
                  type="number"
                  step="any"
                  value={ldl}
                  onChange={(e) => setLdl(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-slate-200 bg-white p-2 font-mono text-xs"
                />
              </div>
              <div>
                <label className="text-slate-500">Triglycerides</label>
                <input
                  type="number"
                  step="any"
                  value={tg}
                  onChange={(e) => setTg(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-slate-200 bg-white p-2 font-mono text-xs"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Endocrine & Metabolic */}
          <div className="rounded-xl border border-slate-200 bg-slate-50/50 p-4">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-900 text-xs uppercase tracking-wider">
                2. Endocrinology & Glycemic Dynamics
              </span>
              {calcHoma !== null && (
                <span className="font-mono text-[11px] text-amber-700">
                  Calculated HOMA-IR: <strong>{calcHoma}</strong>
                </span>
              )}
            </div>

            <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-3">
              <div>
                <label className="text-slate-500">Fasting Glucose (mg/dL)</label>
                <input
                  type="number"
                  step="any"
                  value={glucose}
                  onChange={(e) => setGlucose(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-slate-200 bg-white p-2 font-mono text-xs"
                />
              </div>
              <div>
                <label className="text-slate-500">Fasting Insulin (uIU/mL)</label>
                <input
                  type="number"
                  step="any"
                  value={insulin}
                  onChange={(e) => setInsulin(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-slate-200 bg-white p-2 font-mono text-xs"
                />
              </div>
              <div>
                <label className="text-slate-500">Hemoglobin A1c (%)</label>
                <input
                  type="number"
                  step="any"
                  value={hba1c}
                  onChange={(e) => setHba1c(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-slate-200 bg-white p-2 font-mono text-xs"
                />
              </div>
              <div>
                <label className="text-slate-500">TSH (uIU/mL)</label>
                <input
                  type="number"
                  step="any"
                  value={tsh}
                  onChange={(e) => setTsh(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-slate-200 bg-white p-2 font-mono text-xs"
                />
              </div>
              <div>
                <label className="text-slate-500">Free T4 (ng/dL)</label>
                <input
                  type="number"
                  step="any"
                  value={ft4}
                  onChange={(e) => setFt4(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-slate-200 bg-white p-2 font-mono text-xs"
                />
              </div>
              <div>
                <label className="text-slate-500">Vitamin D (ng/mL)</label>
                <input
                  type="number"
                  step="any"
                  value={vitD}
                  onChange={(e) => setVitD(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-slate-200 bg-white p-2 font-mono text-xs"
                />
              </div>
            </div>
          </div>

          {/* Section 3: Liver, Iron & Inflammation */}
          <div className="rounded-xl border border-slate-200 bg-slate-50/50 p-4">
            <span className="font-semibold text-slate-900 text-xs uppercase tracking-wider">
              3. Liver Transaminases, Iron & Inflammation
            </span>
            <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-4">
              <div>
                <label className="text-slate-500">ALT (U/L)</label>
                <input
                  type="number"
                  step="any"
                  value={alt}
                  onChange={(e) => setAlt(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-slate-200 bg-white p-2 font-mono text-xs"
                />
              </div>
              <div>
                <label className="text-slate-500">AST (U/L)</label>
                <input
                  type="number"
                  step="any"
                  value={ast}
                  onChange={(e) => setAst(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-slate-200 bg-white p-2 font-mono text-xs"
                />
              </div>
              <div>
                <label className="text-slate-500">hs-CRP (mg/L)</label>
                <input
                  type="number"
                  step="any"
                  value={hscrp}
                  onChange={(e) => setHscrp(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-slate-200 bg-white p-2 font-mono text-xs"
                />
              </div>
              <div>
                <label className="text-slate-500">Ferritin (ng/mL)</label>
                <input
                  type="number"
                  step="any"
                  value={ferritin}
                  onChange={(e) => setFerritin(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-slate-200 bg-white p-2 font-mono text-xs"
                />
              </div>
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="font-medium text-slate-700">Clinical Exam Notes</label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="mt-1 w-full rounded-lg border border-slate-200 bg-white p-2 text-xs"
              placeholder="Observation notes, medication changes, or fasting status..."
            />
          </div>

          {/* Action buttons */}
          <div className="flex items-center justify-end gap-3 border-t border-slate-100 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border border-slate-200 px-4 py-2 font-medium text-slate-600 hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex items-center gap-2 rounded-lg bg-slate-900 px-4 py-2 font-medium text-white hover:bg-slate-800"
            >
              <CheckCircle2 className="h-4 w-4" />
              <span>Save & Compute Pipelines</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
