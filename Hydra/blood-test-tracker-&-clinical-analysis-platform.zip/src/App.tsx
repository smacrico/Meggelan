import React, { useState } from 'react';
import { SAMPLE_PATIENTS, SAMPLE_EXAMS } from './lib/sampleData';
import { ExamRecord } from './types/clinical';
import { Header } from './components/Header';
import { ExecutiveSummary } from './components/ExecutiveSummary';
import { ProfileLipid } from './components/ProfileLipid';
import { ProfileEndo } from './components/ProfileEndo';
import { ProfileCBC } from './components/ProfileCBC';
import { ProfileLiverIron } from './components/ProfileLiverIron';
import { ExamComparator } from './components/ExamComparator';
import { LabIngestionModal } from './components/LabIngestionModal';
import { AddExamModal } from './components/AddExamModal';
import { AIClinicalConsult } from './components/AIClinicalConsult';
import { MedicalRecordReportModal } from './components/MedicalRecordReportModal';
import { Plus, FileDown } from 'lucide-react';

export default function App() {
  const [patients] = useState(SAMPLE_PATIENTS);
  const [activePatientId, setActivePatientId] = useState('pt-001');
  const [exams, setExams] = useState<ExamRecord[]>(SAMPLE_EXAMS);
  const [activeTab, setActiveTab] = useState('summary');

  // Modal states
  const [isIngestModalOpen, setIsIngestModalOpen] = useState(false);
  const [isAddExamModalOpen, setIsAddExamModalOpen] = useState(false);
  const [isAIModalOpen, setIsAIModalOpen] = useState(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);

  // Active patient object
  const activePatient = patients.find((p) => p.id === activePatientId) || patients[0];

  // Active patient's exams sorted chronologically
  const patientExams = exams
    .filter((e) => e.patientId === activePatientId)
    .sort((a, b) => new Date(a.examDate).getTime() - new Date(b.examDate).getTime());

  // Current exam ID (defaults to latest exam for active patient)
  const [selectedExamId, setSelectedExamId] = useState<string | null>(null);

  const currentExam =
    (selectedExamId ? patientExams.find((e) => e.id === selectedExamId) : null) ||
    patientExams[patientExams.length - 1] ||
    patientExams[0];

  const handleSelectPatient = (patientId: string) => {
    setActivePatientId(patientId);
    setSelectedExamId(null); // Reset to latest of selected patient
  };

  const handleIngestSuccess = (newExam: ExamRecord) => {
    setExams((prev) => [...prev, newExam]);
    setActivePatientId(newExam.patientId);
    setSelectedExamId(newExam.id);
  };

  const handleAddSuccess = (newExam: ExamRecord) => {
    setExams((prev) => [...prev, newExam]);
    setActivePatientId(newExam.patientId);
    setSelectedExamId(newExam.id);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans">
      {/* 3-Zone Header Contract */}
      <Header
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onOpenIngestModal={() => setIsIngestModalOpen(true)}
        onOpenAddModal={() => setIsAddExamModalOpen(true)}
      />

      {/* Main Workspace Stage */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6">
        {/* Workspace Toolbar: Patient Switcher & Record Quick Actions */}
        <div className="mb-6 flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
          <div className="flex items-center gap-3">
            <span className="text-xs text-slate-500 font-medium">Cohort Profile:</span>
            <div className="flex items-center gap-1.5 p-1 bg-slate-200/60 rounded-lg">
              {patients.map((p) => (
                <button
                  key={p.id}
                  onClick={() => handleSelectPatient(p.id)}
                  className={`px-3 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                    activePatientId === p.id
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {p.name}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsReportModalOpen(true)}
              className="flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 shadow-2xs hover:bg-slate-50 transition-colors"
            >
              <FileDown className="h-3.5 w-3.5 text-slate-500" />
              <span>Clinical PDF Report</span>
            </button>

            <button
              onClick={() => setIsAddExamModalOpen(true)}
              className="flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 shadow-2xs hover:bg-slate-50 transition-colors"
            >
              <Plus className="h-3.5 w-3.5 text-slate-500" />
              <span>Record New Exam</span>
            </button>
          </div>
        </div>

        {/* Tab Views */}
        {currentExam ? (
          <div>
            {activeTab === 'summary' && (
              <ExecutiveSummary
                currentExam={currentExam}
                allExams={exams}
                patient={activePatient}
                allPatients={patients}
                onSelectPatient={handleSelectPatient}
                onSelectExam={setSelectedExamId}
                onNavigateTab={setActiveTab}
                onOpenAIModal={() => setIsAIModalOpen(true)}
                onOpenReportModal={() => setIsReportModalOpen(true)}
              />
            )}

            {activeTab === 'lipid' && (
              <ProfileLipid
                currentExam={currentExam}
                allExams={exams}
                patientId={activePatient.id}
              />
            )}

            {activeTab === 'endo' && (
              <ProfileEndo
                currentExam={currentExam}
                allExams={exams}
                patientId={activePatient.id}
              />
            )}

            {activeTab === 'cbc' && (
              <ProfileCBC
                currentExam={currentExam}
                allExams={exams}
                patientId={activePatient.id}
              />
            )}

            {activeTab === 'organs' && (
              <ProfileLiverIron
                currentExam={currentExam}
                allExams={exams}
                patientId={activePatient.id}
              />
            )}

            {activeTab === 'compare' && (
              <ExamComparator
                allExams={exams}
                patientId={activePatient.id}
              />
            )}
          </div>
        ) : (
          <div className="rounded-xl border border-dashed border-slate-300 bg-white p-12 text-center text-xs text-slate-500">
            No exams found for this patient. Click "Ingest Lab Report" or "Record New Exam" above.
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-4 px-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span>Blood Analysis & Longitudinal Biomarker Tracking Engine</span>
            <span aria-hidden="true">·</span>
            <span>Friedewald LDL · AIP · HOMA-IR · QUICKI · De Ritis Ratio · NLR · TSAT</span>
          </div>
          <div className="font-mono text-[11px] text-slate-400">
            All algorithms validated against clinical laboratory guidelines
          </div>
        </div>
      </footer>

      {/* Modals */}
      <LabIngestionModal
        isOpen={isIngestModalOpen}
        onClose={() => setIsIngestModalOpen(false)}
        patients={patients}
        activePatientId={activePatientId}
        onIngestSuccess={handleIngestSuccess}
      />

      <AddExamModal
        isOpen={isAddExamModalOpen}
        onClose={() => setIsAddExamModalOpen(false)}
        patients={patients}
        activePatientId={activePatientId}
        onAddSuccess={handleAddSuccess}
      />

      {currentExam && (
        <>
          <AIClinicalConsult
            isOpen={isAIModalOpen}
            onClose={() => setIsAIModalOpen(false)}
            exam={currentExam}
            patient={activePatient}
          />

          <MedicalRecordReportModal
            isOpen={isReportModalOpen}
            onClose={() => setIsReportModalOpen(false)}
            patient={activePatient}
            exam={currentExam}
            allPatientExams={patientExams}
            onSelectExam={setSelectedExamId}
          />
        </>
      )}
    </div>
  );
}
